app.controller('loginCtrl',function($window,$scope,$route,Notification,$location,$http,$localStorage,ngNotify,$sessionStorage,$route){
	 //$scope.checkuser = 'false';
  //==============login =========================
  $scope.login = function(){
    	$http({
		method : 'POST',
		url : "/api/login",
		data : {username:$scope.username, password:$scope.pass}
	}).then(function sucessCallback(response)
	{
		if(response.data.error)
		{
			$scope.error = response.data.error;
			console.log(scope.error);
		}
		else{
			//console.log(response);
		    $scope.user = response.data;
        console.log($scope.user);
        $localStorage.name = true;
        //$sessionStorage.user=$scope.user;
        $scope.loginuser();
		    ngNotify.set('Successfully Login!');
        //Notification.success('Success notification');
			  $location.path('/list');
		}
		//console.log(response);
	}, function errorCallback(response){
		ngNotify.set('Enter correct username and Password !');
	});
	};

  //

  $scope.admin = function(){
      $http({
    method : 'POST',
    url : "/api/login",
    data : {username:$scope.username, password:$scope.pass}
  }).then(function sucessCallback(response)
  {
    if(response.data.error)
    {
      $scope.error = response.data.error;
      console.log(scope.error);
    }
    else{
      //console.log(response);
        $scope.user = response.data;
      // $localStorage.name = true;
      $scope.loginuser();
       ngNotify.set('Successfully Login!');
      $location.path('/view');
    }
    //console.log(response);
  }, function errorCallback(response){
    ngNotify.set('Enter correct username and Password !');
  });
  };

  //======================== signup route calling =================

	$scope.singup = function(){
		$location.path('/signup');
	}

//========================new user signup ===================
	$scope.saveuser = function(){
		var file = $scope.myFile;
 
       var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('username',$scope.username);
        fd.append('email',$scope.email);
        fd.append('password',$scope.pass);
        fd.append('file', file);
       
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			ngNotify.set('Varification Link sent to your Email!\nBefore Login Please vaify your Email' );
			$location.path('/login');

		}
	   //console.log(response);
	}, function errorCallback(response) {
	    console.log('error',response);
	});
    };

	// ===============new product Add=======================
$scope.saveproduct = function(){
   var file = $scope.myFile;
 
       var uploadUrl = "api/product";
        var fd = new FormData();
        fd.append('pname',$scope.pname);
        fd.append('pprice',$scope.pprice);
        fd.append('file', file);
       
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }).then(function successCallback(response) {
    if(response.data.error){
      $scope.error = response.data.error;
    }else{
      
      ngNotify.set('Product Added Successfully');
      $scope.pname  = '';
      $scope.pprice = '';
      $scope.myFile = '';
      //$location.path('/list');

    }
     //console.log(response);
  }, function errorCallback(response) {
      console.log('error',response);
  });
};

//============================= show the all product =============
$scope.showlist = function(){

  $location.path('/list');
}

  $scope.product=$localStorage.data1;
  $scope.single=$localStorage.data2;


angular.element(document).ready(function(){
		 	 	//console.log(email);
	$http({
		method: 'GET',
		url: '/api/list'
		}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			     $scope.products = response.data;
		       $scope.currentPage = 1;
           $scope.totalItems = $scope.products.length;
           $scope.entryLimit = 8; 
           $scope.noOfpages = Math.ceil($scope.totalItems / $scope.entryLimit);

		}
		
	}, function errorCallback(response) {
		console.log('error',response);
	});
});
//==========================================Admin list=========================

$scope.showdata = function(){

  $http({
    method: 'GET',
    url: '/api/list'
    }).then(function successCallback(response) {
    if(response.data.error){
      $scope.error = response.data.error;
    }else{
           $scope.products= response.data;
           //console.log(admindata);
           $location.path('/adminlist');
          
    }
    
  }, function errorCallback(response) {
    console.log('error',response);
  });
};

//==========================add to carts==============
$scope.count1=$localStorage.c;
//$scope.count=0;
$scope.addcart=[];
$scope.buyproduct = function(id){
	console.log(id);
   $http({
   	method:'Post',
   	url:'/api/single/'+id
   	
   }).then(function successCallback(response){
   	if(response.data.error){
   		console.log(response.data.error);
         	}
   	else {
   		
   		$scope.user = response.data;

      //$localStorage.data1.push($scope.user);
      $scope.addcart.push($scope.user);
      
      Notification.success({title:'Cart Item!',message: 'Item Added in Cart!', delay: 1000});
      
      $localStorage.c=$scope.count;

      $localStorage.data1=$scope.addcart; 
      $scope.count=$scope.addcart.length;
      //$route.reload(); 
      $location.path('/list')    
   
   	}
   }, function errorCallback(response){
   	console.log(response);
   });
};



$scope.singleview = function(id){
  //console.log(id);
   $http({
    method:'Post',
    url:'/api/single/'+id
    
   }).then(function successCallback(response){
    if(response.data.error){
      console.log(response.data.error);
          }
    else {
      
      $scope.user = response.data
      $localStorage.data2=$scope.user;
      $location.path('/single')
      $localStorage.data1=$scope.addcart;      
   
    }
   }, function errorCallback(response){
    console.log(response);
   });
};



$scope.remove=function(index)
             {
          $scope.product.splice(index,1);
             }
$scope.del=function(id)
             {
  $http({
    method:'delete',
    url:'/api/del/'+id
    
   }).then(function successCallback(response){
    if(response.data.error){
      console.log(response.data.error);
          }
    else {
      
      $scope.user = response.data
      $localStorage.data2=$scope.user;
      $route.reload();
      //$localStorage.data1=$scope.addcart;      
   
    }
   }, function errorCallback(response){
    console.log(response);
   });

             }


     $scope.total = function() {
     var total = 0;
     angular.forEach($scope.product, function(item, key){
      total += parseInt(item.pprice*item.qty);
    });

     $scope.shipping=0.5*total/100;
     $scope.sub=total;
     $scope.grandtotal=$scope.sub+$scope.shipping;
     $localStorage.aa=$scope.grandtotal1;
     return $scope.grandtotal;
  };
  // $scope.grandtotal = function() {
  //     return $scope.total()+10;
  // }

$scope.paynow = function(){
  alert('hello');
   $http({
   	method:'post',
   	url:'/api/paynow'
   
   }).then(function successCallback(response){
   	if(response.data.error){
   		console.log(response.data.error);
   	}
   	else {
   		console.log(response);

   	}
   }, function errorCallback(response){
   	console.log(response);
    $window.location.href = 'https://www.paypal.com/home';
   });
};

$scope.info = function(){

  $location.path('/userinfo');  
};
// $scope.singleview = function(){
// ;
//   $location.path('/single');  
// };
$scope.local = function(){
  $localStorage.data2='';
  $location.path('/list'); 
    
};
//--------------logout



$scope.bill = $localStorage.bil;
$scope.saveinfo = function(){
  console.log($scope.grandtotal);
  var aaa =$localStorage.aa;
$http({
    method : 'POST',
    url : "/api/info",
    data : {name:$scope.name, email:$scope.email,phone:$scope.phone,address:$scope.add,pincode:$scope.pin,payment:$scope.selected,amount:$scope.grandtotal}
  }).then(function sucessCallback(response)
  {
    if(response.data.error)
    {
      $scope.error = response.data.error;
      console.log(scope.error);
    }
    else{
      //console.log(response);
        $scope.user = response.data;
        console.log($scope.user);
        $localStorage.bil=$scope.user;
        console.log($localStorage.bil);
        ngNotify.set('Thankyou For shopping!\nDetails sent to your Email!');
        
        $location.path('/bil');

    }
    //console.log(response);
  }, function errorCallback(response){
    alert('Enter the All Detail Properly');
  });
  };
  

  //============================

  $scope.contact = function()
    {
  var amount=$localStorage.aa;
  $http({
    method : 'POST',
    url : '/api/billing',
    data : {amount:$scope.grandtotal,name:$scope.name, email:$scope.email,phone:$scope.phone,address:$scope.add,total:amount}
  }).then(function sucessCallback(response)
  {
    if(response.data.error)
    {
      $scope.error = response.data.error;
    }
    else{
      //$location.path('/home');
      console.log(response);
      Notification.success({title:'bil-Info !',message: 'Details sent to your Email! !', delay: 2000});
    }
    
  }, function errorCallback(response){
    console.log(response);
  });
}

$scope.feedback = function()
{
  $scope.error = " ";
  $http({
    method : 'POST',
    url : '/api/feedback',
    data : {name: $scope.name, email: $scope.email,  message : $scope.message}
  }).then(function sucessCallback(response)
  {
    if(response.data.error)
    {
      $scope.error = response.data.error;
    }
    else{
      $scope.name='';
      $scope.email='';
      $scope.message='';
      ngNotify.set('Thankyou for your feedback');

      //$location.path('/feed');
    }
    console.log(response);
  }, function errorCallback(response){
    console.log(response);
  });
}

//===============================Forget Password =============================

$scope.reset = function(){
      $http({
    method : 'POST',
    url : "/api/reset",
    data : {username:$scope.username}
  }).then(function sucessCallback(response)
  {
    if(response.data.error)
    {
      $scope.error = response.data.error;
     //console.log(scope.error);
       ngNotify.set('Error !'+scope.error);
    }
    else{
      //console.log(response);
        $scope.user = response.data;
      $localStorage.userPwdEmail = $scope.username;
      $scope.username='';
       ngNotify.set('Password reset Link  has been sent to your email !');
      //$location.path('/view');
    }
    //console.log(response);
  }, function errorCallback(response){
    //ngNotify.set('Email Not Register !');
    Notification.error({title:'oops !',message: 'Email Not Register !', delay: 1000});
  });
  };
//-----------------------------------------------

$scope.updatePassword = function()
{
  var a = $localStorage.userPwdEmail;

 // $scope.error = " ";
  $http({
    method : 'POST',
    url : '/api/pwd/'+a,
    data : { password: $scope.pass}
  }).then(function sucessCallback(response)
  {
    if(response.data.error)
    {
      $scope.error = response.data.error;
    }
    else{
      
      ngNotify.set('Password Changed Successfully');
      $localStorage.userPwdEmail=" ";
      $location.path('/login');
    }
    console.log(response);
  }, function errorCallback(response){
    console.log(response);
  });
}
//===================================Edit products============
$scope.data = $localStorage.updateProductItem;
$scope.updateproduct=function(id){

  $http.get('/api/edit/' + id).then(function successCallback(response) {
    if(response.data.error){
      $scope.error = response.data.error;
    }else{
      $scope.user1 = response.data;
      //console.log($scope.user1);

             $localStorage.updateProductItem=$scope.user1;
             //console.log($localStorage.user2);
      $location.path('/edit');
    }
    //console.log(response);
  }, function errorCallback(response) {
    console.log('error',response);
  });
};



$scope.updatesave=function(id){
 
  $http({
    method: 'POST',
    url: '/api/edit/'+id ,
    data: {pname:$scope.data.pname,pprice:$scope.data.pprice}
  }).then(function successCallback(response) {
    if(response.data.error){
      $scope.error = response.data.error;
    }else{
      $location.path('/adminlist');
    }
    console.log(response);
  }, function errorCallback(response) {
    console.log('error',response);
  });
};



});
//============================================================
app.controller( 'mainCtrl', function($route, $scope,ngNotify,$location,$localStorage,$sessionStorage,$http) {
         
         $scope.checkuser= $localStorage.check;
        
        console.log($scope.checkuser);
        $scope.loginuser = function(){
          //alert('hello');
        //$scope.checkuser= true;
        $localStorage.check=true;
         $scope.checkuser=$localStorage.check;
          $route.reload();
         console.log($localStorage.check);
         }

        $scope.logout=function(){
        $http({
            method:"get",
            url:'/api/logout',
        }).then(function successCallback(response){
          //$scope.checkuser= false;
          $scope.checkuser=false;
          $localStorage.check= false;
          $route.reload();
          
         // $localStorage.c = '';
          ngNotify.set('You are Logout!');
          $localStorage.data1 = " ";
          $localStorage.c='';
          $scope.count=" ";
          //$scope.product=" ";
          $location.path('/list');
          
        }, function errorCallback(res){
          ngNotify.set("error");
        });

          }


});