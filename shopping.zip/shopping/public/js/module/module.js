var app = angular.module("myapp",['ngRoute','ngMessages','myapp.directives','ui.bootstrap','fileModel','ngStorage','ngNotify','ui-notification']);
app.config(function($routeProvider,$locationProvider,NotificationProvider){
$routeProvider.when('/login',{
	controller:'loginCtrl',
	templateUrl:'js/views/login.html',
  // resolve: {
  //  logedin: checkLoggedin
  //  //logedin:
         
  // }
}).when('/admin',{
  controller:'loginCtrl',
  templateUrl:'js/views/admin.html'
}).when('/signup',{
	controller:'loginCtrl',
	templateUrl:'js/views/singup.html'
}).when('/feed',{
  controller:'loginCtrl',
  templateUrl:'js/views/feedback.html'
}).when('/edit',{
  controller:'loginCtrl',
  templateUrl:'js/views/edit.html'
}).when('/list',{
  controller:'loginCtrl',
  templateUrl:'js/views/cart.html'
}).when('/reset',{
  controller:'loginCtrl',
  templateUrl:'js/views/reset.html'
}).when('/forget',{
  controller:'loginCtrl',
  templateUrl:'js/views/forget.html'
}).when('/single',{
  controller:'loginCtrl',
  templateUrl:'js/views/single.html',
}).when('/cart',{
  controller:'loginCtrl',
  templateUrl:'js/views/cartitem.html'
}).when('/adminlist',{
  controller:'loginCtrl',
  templateUrl:'js/views/alist.html'
}).when('/userinfo',{
  controller:'loginCtrl',
  templateUrl:'js/views/userinfo.html',
  resolve: {
    
        logedin:checkLoggedin
  }
}).when('/bil',{
  controller:'loginCtrl',
  templateUrl:'js/views/bil.html',
  resolve: {
    
        logedin:checkLoggedin
        
  }
}).when('/view',{
controller:'loginCtrl',
  templateUrl:'js/views/view.html',
  resolve: {
    
		    logedin:checkLoggedin
	}
  
}).
otherwise({
redirectTo:'/list'
	});
$locationProvider.html5Mode({
   enabled:true,
   requireBase: false
});

NotificationProvider.setOptions({
            delay: 1000,
            startTop: 85,
            startRight: 5,
            verticalSpacing: 30,
            horizontalSpacing: 10,
            positionX: 'right',
            positionY: 'top'
        });


});
app.run(['ngNotify','$rootScope',function(ngNotify,$rootScope) {
    ngNotify.config({
            theme: 'pitchy',
            position: 'bottom',
            duration: 1000,
            type: 'success',
            sticky: false,
            button: true,
            html: false
                    
                });
            }
        ]);



var app = angular.module('myapp.directives', ['ngMessages']);
app.directive('compareTo', function () {
   return {
      require: "ngModel",
      scope: {
        otherModelValue: "=compareTo"
      },
      link: function(scope, element, attributes, ngModel) {

        ngModel.$validators.compareTo = function(modelValue) {
          return modelValue == scope.otherModelValue;
        };

        scope.$watch("otherModelValue", function() {
          ngModel.$validate();
        });
      }
    };
  });
var app = angular.module('fileModel', []);
app.directive('fileModel',  function ($parse) 
{
return {
    restrict: 'A',
    link: function(scope, element, attrs)
  {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
       
     }
    };
});
// var app = angular.module('notification', []);
// myApp.directive('notification', ['$timeout', function ($timeout) {
//         return {
//             restrict: 'E',
//             template:"<div class='alert alert-{{alertData.type}}' ng-show='alertData.message' role='alert' data-notification='{{alertData.status}}'>{{alertData.message}}</div>",
//             scope:{
//               alertData:"="
//             }
//         };
//     }]);    
app.filter('startFrom', function () {
  return function (input, start) {
    if (input) {
      start = +start;
      return input.slice(start);
    }
    return [];
  };
});


var checkLoggedin = function($q, $timeout, $http, $location, $rootScope,ngNotify){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/api/logged').success(function(user){
       
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          //alert("Please log In First");
            ngNotify.set("Please log In First");
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });

      return deferred.promise;

    };
