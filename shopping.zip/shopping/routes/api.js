var express = require('express');
var router = express.Router();
var model = require('../model/usermodel');
var pmodel = require('../model/productmodel');
var bmodel = require('../model/billingmodel');
var multer = require('multer');
var mime = require('mime-types');
var nodemailer = require('nodemailer');
var paypal = require('paypal-rest-sdk');
var path = require('path');
var transporter = nodemailer.createTransport('smtps://freshervishesh@gmail.com:9991281944@smtp.gmail.com');

var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
//=========================


router.post('/billing',function(req, res) {

    var data = req.body;
 console.log(data);
    transporter.sendMail({
        from: 'Online Shopping',
        to: data.email,       
        name:data.name,
        subject : "Billing Detail",       
        text: 'Hello:'+data.name+'\n'+'Your order is booked\n'+'Amount:'+data.amount+'\n'+'Mobile:'+data.phone+'\n'+'address:'+data.address+'\n'+'Product Deliver within 10 Days'
    });
 
    res.json(data);
});

//===========

  router.post('/feedback',function(req, res) {

      var data = req.body;
   console.log(data.email);
      transporter.sendMail({
          from: 'Customor',
          to:'tanwar.tony136@gmail.com' ,       
          name:data.name,
          subject : "Customer feedback",       
          text: 'FeedBack:'+data.message+'\n'+'From:'+data.email
      });
   
      res.json(data);
  });


//===================
// /var http=require('http');

var config = {
  "port" : 3000,
  "api" : {
  "host" : "api.sandbox.paypal.com",          
  "client_id" : "AYMVRsohzwE6L4bpO-ShS0JOqfdMM40LEMea9qRzOrg3zJFm--LCB4OmVnqTRQkHuBk8mBNH5o9ub-2e",  // your paypal application client id
  "client_secret" : "EArg4GSDaDvO8ExZcgYuzr4SBlgUjYtDN30ytKgy1RVUoE-5pzNZG4Jl9EJe6AGp8WG6dmvc8Mml7a6U" // your paypal application secret id

  }
}
 
paypal.configure(config.api);
 
// Page will display after payment has beed transfered successfully
router.get('/success', function(req, res) {
  res.send("Payment transfered successfully.");
});
 
// Page will display when you canceled the transaction 
router.get('/cancel', function(req, res) {
  res.send("Payment canceled successfully.");
});
 
router.get('/', function(req, res) {
   res.sendFile(__dirname+'/index.html');
});
 
router.post('/paynow', function(req, res) {
   // paypal payment configuration.
  // var payment = {
  // "intent": "sale",
  // "payer": {
  //   "payment_method": "paypal"
  // },
  // "redirect_urls": {
  //   "return_url": "/login",
  //   "cancel_url": "/login"
  // },
  // "transactions": [{
  //   "amount": {
  //     "total":'100',
  //     "currency":  'req.body.currency'
  //   },
  //   "description": 'req.body.description'
  // }]
  //res.send('paypal');
   res.redirect('https://www.paypal.com')
//};
 
//   paypal.payment.create(payment, function (error, payment) {
//   if (error) {
//     console.log(error);
//   } else {
//     if(payment.payer.payment_method === 'paypal') {
//       req.paymentId = payment.id;
//       var redirectUrl;
//       console.log(payment);
//       for(var i=0; i < payment.links.length; i++) {
//         var link = payment.links[i];
//         if (link.method === 'REDIRECT') {
//           redirectUrl = link.href;
//         }
//       }
//       res.redirect(redirectUrl);
//     }
//   }
// });
});
// =====================file uploading ============================
var bcrypt = require('bcrypt-nodejs');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
        console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/upload/')
    },
    filename: function (req, file, cb) {
        console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var upload1 = multer({ storage: storage })



//---------------------------- Local Strategy--------------------------
passport.use(new LocalStrategy(function(username, password, done) {
  	console.log(username);
    console.log(password);
    model.findOne({ 'username': username , status:true}, function (err, person) 
   {
    		if(err){
    			return done(err);
        }
      //   });
          //res.send(err);
    		
    		else 
        {
          if(!person){
            return done(null,false,{message:'User Not found'});
          }
    			else{
    		person.comparePassword(password, function(err, isMatch) {
            if (err) throw err;
            else{
              if(isMatch)
               {
            console.log('password:', isMatch); 
            //res.send(person);
            return done(null,person);
                }
                else {
                   return done(null);
                }

          }

        });
              };
        // 
        // person.comparePassword(password, function(err, isMatch) {
        //     if (err) throw err;
        //     console.log('Password:', isMatch); 
        //     //res.send(person);
        // });
  //  });
 // res.send(person);
        // });
    			
    		};

    });
  }
));
//-----------------------------------
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

 router.get('/logged', function(req, res) {
  res.send(req.isAuthenticated() ? req.user : '0');
});


router.post('/signup',upload.single('file'), function(req, res){
   
   //console.log(req.body.email);
    model.findOne({username:req.body.username},function(err,person){
    	 var user = new model();
    

    	  user.name = req.body.name;
        user.username = req.body.username;
        user.password = req.body.password;
        user.file = req.file.filename;
        user.status=false;
        user.confirm = makeid();
        var token = 'http://localhost:3000/api/verify?token=' + user.confirm;
        console.log(token);
      
           user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    else {
                    var option = {
                    from: 'vishesh',
                    to: user.username,       
                    //name:data.name,
                    subject : "Message Show",       
                    html:' Please confirm your email id <a href='+token+'>link</a>'
              };
              transporter.sendMail(option, function(error,info){
              	if(error){
              		return error;
              	}
              	console.log('msg send'+info.response);
              	

              });
          }
    
       res.send(data);             
             
    });
});
});

//------------------------------------------


router.post('/login',passport.authenticate('local'),function(req,res){
		console.log(req.user);
	res.send(req.user);
	//console.log(req.user);
});

//===========================email - varification ===============================
router.get('/verify',function(req,res){
 console.log('verify token: ',req.query.token);
model.findOne({confirm: req.query.token }, function(err,user) {
  if (err) { return console.error(err); }
    // console.log(user);
     user.status=true;
     console.log(user.status);
      user.save(function (err) {
            if (err) return console.error(err);
            console.log('succesfully updated user');
            //console.log(data);
             res.redirect('/login');
                    });
    });
});

//====================================password reset===================================

router.post('/reset',function(req,res){
 console.log(req.body.username);
 var user = new model();
      user.reset=makeid();
model.findOne({username: req.body.username }, function(err,user) {
          if (err) {
          console.error(err); 
         }
         else{
          
          var token = 'http://localhost:3000/api/password?token=' + user.reset;
        console.log(token);
           
           user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    else {
                    var option = {
                    from: 'Reset Password',
                    to: user.username,       
                    //name:data.name,
                    subject : "Message Show",       
                    html:' This is reset password link change password from here <a href='+token+'>link</a>'
              };
              transporter.sendMail(option, function(error,info){
                if(error){
                  return error;
                }
                console.log('msg send'+info.response);
                

              });
          }
    
          res.send(data);          
             
    });
              //console.log('succesfully find user');
             //res.send(user);
                    
    };
});
});

//--------------------------------------
router.get('/password',function(req,res){
 console.log('verify token: ',req.query.token);
model.findOne({reset: req.query.reset }, function(err,user) {
          if (err)
           { 
            console.error(err); 
           }
            
          else {
             console.log(user);
             //res.redirect('/login');
             //res.sendFile('email/public/views/reset.html');
            // res.sendfile('/home/vishesh/Desktop/email/public/reset.html');
          //  res.sendfile('./public/views/reset.html');
         // res.sendFile('index1.html', { root: path.join(__dirname, '../public') });
        // res.render('/home/vishesh/Desktop/email/public/views/reset');
         return res.redirect('http://localhost:3000/reset');
                    };
    });
});



//==================================

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(id, done) {
 model.findById(id, function (err, user) {
    done(err, user);
  });
});



 function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}


//-------------------------------------------

router.post('/product',upload1.single('file'), function(req, res){
   
  
    pmodel.findOne({pname:req.body.pname},function(err,person){
        var user = new pmodel();
        user.pname = req.body.pname;
        user.pprice = req.body.pprice;
        user.file = req.file.filename;
             user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    else {
                      res.send(data);
                     }
                   });
           });
  });
//----------------------------------------
     router.post('/pwd/:a', function(req, res){
   //var user = new model();
   console.log(req.params.a);
    model.findOne({username:req.params.a},function(err,person){
        
        person.password = req.body.password;
            person.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    else {
                      res.send(data);
                     }
                   });
           });
  });
//------------------------

router.get('/list', function(req, res){

 pmodel.find().sort({'_id':-1}).exec(function(err,person){
      
                    if (err) {
                        res.send(err);
                    }
                    else {
                      res.send(person);
                     }
                   });
          
  });


router.post('/single/:id', function(req, res){

 pmodel.findOne({_id:req.params.id},function(err,person){
      
                    if (err) {
                        res.send(err);
                    }
                    else {
                      res.send(person);
                     }
                   });
          
  });
//======================delete=======
router.delete('/del/:id', function(req, res){

 pmodel.findById(req.params.id,function(err, person){
        person.remove(function(err,person){
            res.send(person);
        });
    });
          
  });
//==================update===============

router.get('/edit/:id', function(req,res){
    var uid=req.params.id;
    console.log(uid);
    pmodel.findById(uid,function(err,data){
        if(err){
            res.send(err);
        }
        else{
            res.send(data);
        }
    });
});
//---------

router.post('/edit/:id', function(req, res){
    var uid = req.params.id; 
          pmodel.findById(uid , function(err ,person){ 
          person.pname= req.body.pname; 
          person.pprice= req.body.pprice; 
          
         
                person.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }else {
                        res.send(data);
                    }
                });
                });
          });

//------------logout------------


router.get('/logout', function(req, res){
  req.logout();
  res.send(req.user)
  console.log("user is logout")
  // res.redirect('/login');
});


//=================================
router.post('/info', function(req, res){
         console.log(req.body.amount);
        var user = new bmodel();
        user.name = req.body.name;
        user.email = req.body.email;
        user.phone = req.body.phone;
        user.address = req.body.address;
        user.pincode = req.body.pincode;
        user.payment = req.body.payment;
        user.amount = req.body.amount;
        
             user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    else {
                      console.log(data);
                      res.send(data);
                     }  
                   });
           });
  









module.exports = router;
