// config/database.js
module.exports = {

	'url' : '@mongo.onmodulus.net:27017/Mikha4ot' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};