var app =angular.module('starter.controllers', [])
// app.constant('api','http://amboff.indiit.com/inventorymanagement/webservice/')
app.constant('api',JSON.parse(window.localStorage.getItem('url_data')));

/*************************** login controller **********************/
app.controller('DashCtrl' ,function($scope,$rootScope, $state ,$location,$ionicPopup,$ionicHistory,LoaderService,LoginService,Auth) {
 
$scope.data={};
$scope.login = function() {
if($scope.data.username === undefined ){
           var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'Please enter your username!'
           });
           return;
       }
       if($scope.data.password === undefined ){
           var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'Please enter your password!'
           });
           return;
       }
       LoaderService.show();
     
       LoginService.loginUser($scope.data.username, $scope.data.password).success(function(response) {
           
           LoaderService.hide();
           console.log(response.data);
           if (response.status == 1) {
                console.log($scope.data.username);
           $ionicHistory.clearCache()
               Auth.setUser(response.data);
  window.localStorage.setItem('user_session',JSON.stringify(response.data));
                   user_detail = response.data;
                   console.log( user_detail);
                   $state.go('app.home');
                   // var alertPopup = $ionicPopup.alert({
                   //     title: 'Success',
                   //     template: 'Successfully loged in!'
                   // }).then(function(){
                   //     $state.go('home');
                   // });
                   
                   return response.data;
               }else if(response.status == 0) {
                   var alertPopup = $ionicPopup.alert({
               title: 'Login failed!',
               template: "Please Check Your Credentials"
           });
               } else {
                   var alertPopup = $ionicPopup.alert({
               title: 'Login failed!',
               template: 'Something went wrong'
           });
       }

       }) .error(function(data){
               LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'Please check your network connection!'
               }).then(function(){
                  });
            });
   }

})

/************************************ URL CONTROLLER ***************************************/
app.controller('Urlctrl', function($scope, $state,$ionicHistory ,$location,$ionicPopup,LoaderService,Auth,$stateParams,$cordovaStatusbar,urlservice) {
 $scope.search = {}
$scope.search.search;


//console.log($scope.search.search);
  $scope.url_data =function(){
    var text= $scope.search.search
     console.log(text);
    if($scope.search.search === undefined ){
           var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'Please enter url'
           });
           return;
       }
    
     urlservice.my_url(text).success(function(response) {
          LoaderService.hide();
        $scope.data = response.data;
       console.log($scope.data);
   $state.go('login');
     if (response.status == 1) {
                console.log($scope.data);
          window.localStorage.setItem('url_data',JSON.stringify(response.data));
          //user_detail = response.data;
                   //console.log(user_detail);
          return response.data;
}else if(response.status == 0) {
                   var alertPopup = $ionicPopup.alert({
               title: 'Login failed!',
               template: "Please Check Your Credentials"
           });
               } 
}).error(function(data){
               LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'wrong Url'
               }).then(function(){
                  });
            });
}
})
/********************************** homectrl Controller *************************************/
app.controller('homectrl', function($scope ,$state) {
  $scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);
   // ionic.Platform.ready(function() { 
   // // hide the status bar using the StatusBar plugin
   //  StatusBar.show();
   //   });
   // $scope.logout = function () {
   //  alert("hiiiiiiiiiiiiii");
   //  $window.localStorage.clear();
   //  $ionicHistory.clearCache();
   //  $ionicHistory.clearHistory();
   //              $state.go('login');
   //          };
  })






//************************************* stockCtrl controller *********************************//
app.controller('productCtrl', function($scope,Auth, $state,$ionicHistory ,$location,$ionicPopup,LoaderService,productService,$filter,$cordovaBarcodeScanner,$timeout) {
$scope.data =[];
$scope.search = {}
$scope.search.search = '';
$scope.search.text = '';
$scope.focus = false;
LoaderService.show();

//alert("hiiiiiiiiiiiiii");
 
console.log(Auth.getUser());
console.log(Auth.getUser().id);
 LoaderService.show();
function get_data(){
productService.panding(Auth.getUser().id).success(function(response) {
          LoaderService.hide();
        $scope.data = response.data;
        console.log($scope.data);
$ionicHistory.clearCache();

                   
})
}
get_data();
         

  $scope.setFocus = function(){
  console.log($scope.search.search);
  $scope.focus = true;
    if ($scope.search.search == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }

  $scope.mysetFocus = function(){
    //alert("hiiiiiiiiiiiiiiiiii");
  console.log($scope.search.text);
  $scope.focus = true;
    if ($scope.search.text == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }


$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);


   $scope.scanBarcode = function() {
    console.log('scanBarcode function got called');
     document.addEventListener("deviceready", function () {
    $cordovaBarcodeScanner.scan().then(function(imageData) {
      console.log(imageData);
      //alert(imageData.text);
      $scope.search.text = imageData.text;

      $timeout(function() {
    var el = document.getElementById('linkid');
            angular.element(el).triggerHandler('click');
            }, 0);

       // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
      console.log("Barcode Format -> " + imageData.format);
      console.log("Cancelled -> " + imageData.cancelled);
    }, function(error) {
      console.log("An error happened -> " + error);
    });
  });
  };
        
 





$scope.doRefresh =function(){
$scope.data="";
$scope.search.search='';
get_data();
$scope.$broadcast('scroll.refreshComplete');
}

})

// //********************************** receive stock controller *******************************/
// app.controller('productCtrl', function($scope, $state,$ionicHistory ,$location,$ionicPopup,$ionicHistory,productService,LoaderService,Auth,singleProductService) {
// $scope.data ={};
// console.log(Auth.getUser());
// console.log(Auth.getUser().id);
//  LoaderService.show();
// function get_data(){
// productService.panding(Auth.getUser().id).success(function(response) {
//           LoaderService.hide();
//         $scope.data = response.data;
//         console.log($scope.data);
// $ionicHistory.clearCache();

                   
// })
// }
// get_data();


// $scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
//   console.log($scope.appData);

// $scope.doRefresh =function(){
// $scope.data="";
// get_data();
// $scope.$broadcast('scroll.refreshComplete');
// }

// })



app.controller('singleproductCtrl', function($scope,$rootScope,Auth,$stateParams,$state,$ionicHistory ,$location,$ionicPopup,LoaderService,singleProductService,$filter,$cordovaBarcodeScanner,$timeout) {
$rootScope.data ={};
$scope.search = {}
$scope.search.search = '';
$scope.search.text = '';
$scope.focus = false;
LoaderService.show();

//alert("hiiiiiiiiiiiiii");

var sale_id= $stateParams.sale_id;
LoaderService.show();
function query_2(){
singleProductService.singleProduct(sale_id).success(function(response) {
          LoaderService.hide();
        $rootScope.data = response.data;

        console.log($rootScope.data);
        $ionicHistory.clearCache();
})
}
query_2();
         

  $scope.setFocus = function(){
  console.log($scope.search.search);
  $scope.focus = true;
    if ($scope.search.search == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }

  $scope.mysetFocus = function(){
    //alert("hiiiiiiiiiiiiiiiiii");
  console.log($scope.search.text);
  $scope.focus = true;
    if ($scope.search.text == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }


$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);


   $scope.scanBarcode = function() {
    console.log('scanBarcode function got called');
     document.addEventListener("deviceready", function () {
    $cordovaBarcodeScanner.scan().then(function(imageData) {
      console.log(imageData);
      //alert(imageData.text);
      $scope.search.text = imageData.text;

      $timeout(function() {
    var el = document.getElementById('linkid');
            angular.element(el).triggerHandler('click');
            }, 0);

       // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
      console.log("Barcode Format -> " + imageData.format);
      console.log("Cancelled -> " + imageData.cancelled);
    }, function(error) {
      console.log("An error happened -> " + error);
    });
  });
  };
        
 





$scope.doRefresh =function(){
$scope.data="";
$scope.search.search='';
query_2();
$scope.$broadcast('scroll.refreshComplete');
}

})


//************************************ singleproductCtrl Controller *******************************//
// app.controller('singleproductCtrl', function($rootScope, $state,$ionicHistory ,$location,$ionicPopup,LoaderService,Auth,singleProductService,$stateParams) {
// $rootScope.data ={};
// var sale_id= $stateParams.sale_id;
// LoaderService.show();
// function query_2(){
// singleProductService.singleProduct(sale_id).success(function(response) {
//           LoaderService.hide();
//         $rootScope.data = response.data;

//         console.log($rootScope.data);
//         $ionicHistory.clearCache();
// })
// }
// query_2();

// $rootScope.appData = JSON.parse( window.localStorage.getItem('user_session'));
//   console.log($rootScope.appData);

// $rootScope.doRefresh =function(){
// $rootScope.data="";
// query_2();
// $rootScope.$broadcast('scroll.refreshComplete');
// }
// })


//************************************  ProductEnquiry controller ***********************//
app.controller('ProductEnquiry', function($http,$scope,$ionicHistory, $timeout, $state ,$location,$ionicPopup,LoaderService,ProductEnquiryService,$stateParams,$filter,$cordovaBarcodeScanner) {
$scope.data =[];
$scope.search = {}
$scope.search.search = '';
$scope.search.text = '';
$scope.focus = false;
LoaderService.show();
function Enquiry_data(){
ProductEnquiryService.EnquiryProduct().success(function(response) {
          LoaderService.hide();
        $scope.data = response.data;
        console.log($scope.data);
         $ionicHistory.clearCache();


$scope.setFocus = function(){
  console.log($scope.search.search);
 // console.log($scope.search.text);
  $scope.focus = true;
    if ($scope.search.search == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    } 
  }

  $scope.mysetFocus = function(){
    //alert("hiiiiiiiiiiiiiiiiii");
  console.log($scope.search.text);
  $scope.focus = true;
    if ($scope.search.text == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }
$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);


  

   $scope.scanBarcode = function() {
    console.log('scanBarcode function got called');
     document.addEventListener("deviceready", function () {
    $cordovaBarcodeScanner.scan().then(function(imageData) {
      console.log(imageData);
      //alert(imageData.text);
      $scope.search.text = imageData.text;

      $timeout(function() {
    var el = document.getElementById('linkid');
            angular.element(el).triggerHandler('click');
            }, 0);

       // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
      console.log("Barcode Format -> " + imageData.format);
      console.log("Cancelled -> " + imageData.cancelled);
    }, function(error) {
      console.log("An error happened -> " + error);
    });
  });
  };
  
})
}

$scope.doRefresh =function(){
$scope.data="";
$scope.search.search="";
 Enquiry_data();
 $scope.$broadcast('scroll.refreshComplete');
}

Enquiry_data();


})

//****************************************** singleProductEnquiry controller *******************************//
app.controller('singleProductEnquiry', function($scope, $ionicHistory, $state ,$location,$ionicPopup,LoaderService,Auth,singleProductEnquiryService,$stateParams) {
$scope.data ={};

var product_id= $stateParams.product_id;
console.log(product_id);
LoaderService.show();
function single_product(){
singleProductEnquiryService.singleEnquiryProduct(product_id).success(function(response) {
          LoaderService.hide();
        $scope.data = response.data;

        console.log($scope.data);
        $ionicHistory.clearCache();
})
}
single_product();

$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);

$scope.doRefresh =function(){
$scope.data="";
single_product();;
$scope.$broadcast('scroll.refreshComplete');
}

 })


//************************************* stockCtrl controller *********************************//
app.controller('stockCtrl', function($scope, $state,$ionicHistory ,$location,$ionicPopup,LoaderService,stockCheckService,$filter,$cordovaBarcodeScanner,$timeout) {
$scope.data =[];
$scope.search = {}
$scope.search.search = '';
$scope.search.text = '';
$scope.focus = false;
LoaderService.show();

//alert("hiiiiiiiiiiiiii");
function check_stock(){
stockCheckService.stockCheck().success(function(response) {
          LoaderService.hide();

        $scope.data = response.data;
        console.log($scope.data);
        $ionicHistory.clearCache();
         

  $scope.setFocus = function(){
  console.log($scope.search.search);
  $scope.focus = true;
    if ($scope.search.search == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }

  $scope.mysetFocus = function(){
    //alert("hiiiiiiiiiiiiiiiiii");
  console.log($scope.search.text);
  $scope.focus = true;
    if ($scope.search.text == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }


$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);


   $scope.scanBarcode = function() {
    console.log('scanBarcode function got called');
     document.addEventListener("deviceready", function () {
    $cordovaBarcodeScanner.scan().then(function(imageData) {
      console.log(imageData);
      //alert(imageData.text);
      $scope.search.text = imageData.text;

      $timeout(function() {
    var el = document.getElementById('linkid');
            angular.element(el).triggerHandler('click');
            }, 0);

       // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
      console.log("Barcode Format -> " + imageData.format);
      console.log("Cancelled -> " + imageData.cancelled);
    }, function(error) {
      console.log("An error happened -> " + error);
    });
  });
  };
        
 })
}



check_stock();

$scope.doRefresh =function(){
$scope.data="";
$scope.search.search='';
check_stock();
$scope.$broadcast('scroll.refreshComplete');
}

})



  

//************************************ quantity update controller *********************************//
app.controller('stockProductCtrl', function($scope, $ionicHistory, $state ,$ionicHistory,$location,$ionicPopup,LoaderService,Auth,$stateParams,QuantityUpdateService,singlestockService) {


var product_id= $stateParams.product_id;
console.log(product_id);
LoaderService.show();
$scope.addquantity =function(params){
var add = parseInt($scope.data1.p_quantity) + parseInt(params.quantity);
console.log(add);
$scope.mydata  =add || 0;
//console.log($scope.mydata);
}

function single_product(){
singlestockService.singlestock(product_id).success(function(response) {
          LoaderService.hide();
            console.log(response.data.id);
            
        $scope.data1 = response.data;

        console.log($scope.data1);
        console.log($scope.data1.quantity);
        $ionicHistory.clearCache();

  })
}
single_product();


$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);

$scope.Quantity_Update = function(params){
  var product_id= $stateParams.product_id;
 var quantity= params.quantity;
  console.log(product_id);
  console.log(quantity);
QuantityUpdateService.Quantity_updated(product_id,quantity).success(function(response) {

          LoaderService.hide();
            console.log(product_id);
            $ionicHistory.clearCache();
       var alertPopup = $ionicPopup.alert({
               template: 'quantity Successfully updated'
            })
           .then(function(){
            
            $state.go('app.stock_check');
              });
         console.log(response);      
      })
   }


$scope.doRefresh =function(){
$scope.data1="";
single_product();
$scope.$broadcast('scroll.refreshComplete');
}
})



//******************** movetransferstock controller ***************************************

app.controller('movetransferstock', function($scope, $state,$ionicHistory ,$location,$ionicPopup,LoaderService,stockCheckService,$filter,$cordovaBarcodeScanner,$timeout) {
$scope.data =[];
$scope.search = {}
$scope.search.search = '';
$scope.search.text = '';
$scope.focus = false;
LoaderService.show();

//alert("hiiiiiiiiiiiiii");
function check_stock(){
stockCheckService.stockCheck().success(function(response) {
          LoaderService.hide();

        $scope.data = response.data;
        console.log($scope.data);
        $ionicHistory.clearCache();
         

  $scope.setFocus = function(){
  console.log($scope.search.search);
  $scope.focus = true;
    if ($scope.search.search == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }

  $scope.mysetFocus = function(){
    //alert("hiiiiiiiiiiiiiiiiii");
  console.log($scope.search.text);
  $scope.focus = true;
    if ($scope.search.text == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }


$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);


   $scope.scanBarcode = function() {
    console.log('scanBarcode function got called');
     document.addEventListener("deviceready", function () {
    $cordovaBarcodeScanner.scan().then(function(imageData) {
      console.log(imageData);
      //alert(imageData.text);
      $scope.search.text = imageData.text;

      $timeout(function() {
    var el = document.getElementById('linkid');
            angular.element(el).triggerHandler('click');
            }, 0);

       // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
      console.log("Barcode Format -> " + imageData.format);
      console.log("Cancelled -> " + imageData.cancelled);
    }, function(error) {
      console.log("An error happened -> " + error);
    });
  });
  };
        
 })
}



check_stock();

$scope.doRefresh =function(){
$scope.data="";
$scope.search.search='';
check_stock();
$scope.$broadcast('scroll.refreshComplete');
}

})




// app.controller('movetransferstock', function($scope, $state,$ionicHistory ,$location,$ionicPopup,LoaderService,moveservice,$stateParams,$filter,$cordovaBarcodeScanner) {
// $scope.data =[];
// $scope.search = {}
// $scope.search.search = '';
// $scope.search.text = '';
// $scope.focus = false;
// LoaderService.show();

// function move_stock(){
// moveservice.move_transfer().success(function(response) {
//           LoaderService.hide();

//         $scope.data = response.data;
//         console.log($scope.data);
//         $ionicHistory.clearCache();
         

//   $scope.setFocus = function(){
//   console.log($scope.search.search);
//   $scope.focus = true;
//     if ($scope.search.search == ""){
//       $scope.focus = false;
//     } else {
//       $scope.focus = true;
//     }
//   }

//   $scope.mysetFocus = function(){
//     //alert("hiiiiiiiiiiiiiiiiii");
//   console.log($scope.search.text);
//   $scope.focus = true;
//     if ($scope.search.text == ""){
//       $scope.focus = false;
//     } else {
//       $scope.focus = true;
//     }
//   }


// $scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
//   console.log($scope.appData);


//    $scope.scanBarcode = function() {
//     console.log('scanBarcode function got called');
//      document.addEventListener("deviceready", function () {
//     $cordovaBarcodeScanner.scan().then(function(imageData) {
//       console.log(imageData);
//       //alert(imageData.text);
//       $scope.search.text = imageData.text;

//       $timeout(function() {
//     var el = document.getElementById('linkid');
//             angular.element(el).triggerHandler('click');
//             }, 0);

//        // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
//       console.log("Barcode Format -> " + imageData.format);
//       console.log("Cancelled -> " + imageData.cancelled);
//     }, function(error) {
//       console.log("An error happened -> " + error);
//     });
//   });
//   };
        
//  })
// }


// move_stock();

// $scope.doRefresh =function(){
// $scope.data="";
// $scope.search.search='';
// move_stock();
// $scope.$broadcast('scroll.refreshComplete');
// }

// })


//******************************** wareHouseCtrl controller ********************************//
app.controller('wareHouseCtrl', function($scope, $state, $ionicHistory,$location,$ionicPopup,LoaderService,Auth,$stateParams,warehouseService,singlestockService,transferstockservice) {
$scope.data ={};
$scope.data1={};
$scope.mydata="";

var product_id= $stateParams.product_id;
console.log(product_id);
 console.log(Auth.getUser());
console.log(Auth.getUser().id);
 LoaderService.show();
function ware_house(){
warehouseService.warehouse_product(Auth.getUser().id).success(function(response) {
          LoaderService.hide();
            console.log(Auth.getUser().id);
        $scope.data = response.data;
        console.log($scope.data);
      
      })
}
ware_house();

$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);

$scope.doRefresh =function(){
$scope.data="";
ware_house();
$scope.$broadcast('scroll.refreshComplete');
}

LoaderService.show();
function single_product(){
singlestockService.singlestock(product_id).success(function(response) {
          LoaderService.hide();
            console.log(response.data.id);
        $scope.data1 = response.data;

        console.log($scope.data1);
        console.log($scope.data1.quantity);

   })
}



single_product();


$scope.comparsion = function(params){
console.log(params.selectedName);
console.log(params.selectedName1);
 if(params.selectedName === params.selectedName1){
           var alertPopup = $ionicPopup.alert({
               template: 'Please select different warehouse'
           });
           params.selectedName ='';
           params.selectedName1 ='';
           return;
       }
}


$scope.exceed = function (params){
total(params)
if(parseInt(params.quantity) > parseInt($scope.data1.p_quantity)){

    var alertPopup = $ionicPopup.alert({
      template: 'limit exceed'
         });
            params.quantity= '';
           return;
         }
 }
 
function total(params){
var data = $scope.data1.cost * params.quantity;
console.log(data);
$scope.mydata = data || 0;
//console.log($scope.mydata);
}


$scope.submit_product =function(params){
 // alert("hpppppppppppp");
var product_id= $stateParams.product_id;
  var quantity= params.quantity;
  var to = params.selectedName;
  var from =params.selectedName1;
  var rack = params.rack;
  console.log(rack);
transferstockservice.trasfer_stock(from,to,product_id ,quantity,rack).success(function(response) {
         

        if (response.status == 1) {
         $ionicHistory.clearCache();
                console.log(response);
                   var alertPopup = $ionicPopup.alert({
                       title: 'Success',
                       template: 'Data Successfully updated'
                   }).then(function(){
                     
                       $state.go('app.move');
                   });
                   
                   return response.data;
               }else if(response.status == 0) {
                   var alertPopup = $ionicPopup.alert({
               title: 'Login failed!',
               template: "Please Check Your Credentials"
           });
               }
      console.log(response);
   })
  }


$scope.reset = function (params) {
  params.quantity ='';
  params.Reference='';
  params.rack='';
  params.selectedName ='';
  params.selectedName1 ='';
    var dropDown3 = document.getElementById("thireddrop");
    dropDown3.selectedIndex = 0;
    
}
})



//******************************* pickorderCtrl Controller ***********************************//
app.controller('pickorderCtrl', function($scope, $state ,$location,$ionicPopup,LoaderService,Auth,pickorderservice,$ionicModal) {
$scope.data ={};
LoaderService.show();
function pick_data(){
pickorderservice.pick_order().success(function(response) {
          LoaderService.hide();
        $scope.data = response.data;
        console.log($scope.data)
                   
})
 }
pick_data();

$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);

$scope.doRefresh =function(){
$scope.data="";
pick_data();
$scope.$broadcast('scroll.refreshComplete');
}
})
  

//********************************singlePickorder Controller *********************************//
app.controller('singlePickorder', function($scope, $state ,$location,$ionicPopup,LoaderService,Auth,singlepickorderservice,$stateParams,$cordovaBarcodeScanner) {
$scope.data =[];
// $scope.mydata={}
$scope.search = {}
$scope.search.search = '';
$scope.search.text = '';
$scope.focus = false;
$scope.focus1 =true;
var id= $stateParams.id;
console.log(id);
LoaderService.show();
function singlepick_product(){
singlepickorderservice.singlepick_order(id).success(function(response) {
          LoaderService.hide();
          console.log(id);
        $scope.data = response.data;

        console.log($scope.data);


 $scope.abc =function(){
    setFocus();
   //alert("hiiiiiiiii");
  console.log($scope.search.search);
    // $scope.focus1 = false;
    if ($scope.search.search ==""){
      $scope.focus1 = true;
    } else {
      $scope.focus1 = false;
    }
  }

    function setFocus(){
         // alert("hello");
  console.log($scope.search.search);
  // $scope.focus = true;
    if ($scope.search.search == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }

$scope.appData = JSON.parse( window.localStorage.getItem('user_session'));
  console.log($scope.appData);

  

 $scope.getTotal = function(){
    var total = 0;
    console.log($scope.data.length);
    for(var i = 0; i < $scope.data.length; i++){
        var product =$scope.data[i];
        total += (product.quantity * product.unit_price);
    }
     $scope.total= total;
     console.log($scope.total);
     // $scope.total='';
//return total;
}
$scope.getTotal();

  $scope.mysetFocus = function(){
    //alert("hiiiiiiiiiiiiiiiiii");
  console.log($scope.search.text);
  $scope.focus = true;
    if ($scope.search.text == ""){
      $scope.focus = false;
    } else {
      $scope.focus = true;
    }
  }

   $scope.scanBarcode = function() {
    console.log('scanBarcode function got called');
     document.addEventListener("deviceready", function () {
    $cordovaBarcodeScanner.scan().then(function(imageData) {
      console.log(imageData);
      //alert(imageData.text);
      $scope.search.text = imageData.text;

      $timeout(function() {
    var el = document.getElementById('linkid');
            angular.element(el).triggerHandler('click');
            }, 0);

       // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
      console.log("Barcode Format -> " + imageData.format);
      console.log("Cancelled -> " + imageData.cancelled);
    }, function(error) {
      console.log("An error happened -> " + error);
    });
  });
  };

})
}
singlepick_product();


$scope.doRefresh =function(){
$scope.data="";
$scope.search.search="";
singlepick_product();
$scope.$broadcast('scroll.refreshComplete');
}
})
//************************* singlereceivectrl controller ******************************//

app.controller('singlereceivectrl', function($rootScope,$scope, $state,$stateParams ,$location,$ionicPopup,LoaderService,Auth,$stateParams,$cordovaBarcodeScanner,receivequantityservice) {
$scope.search = {}
$scope.search.search = 0;
var id= $stateParams.id;
console.log(id);
$scope.key = $stateParams.key;
console.log($scope.key);
var purchase_id= $rootScope.data.products_detail[$scope.key].purchase_id;
  console.log(purchase_id);
  
console.log($scope.data.reference_no);


$scope.receivequantity=function(params){
  var received_quantity = $scope.search.search;
  console.log(received_quantity);
  var id= $stateParams.id;
  console.log(id);
var purchase_id= $rootScope.data.products_detail[$scope.key].purchase_id;
  console.log(purchase_id);
receivequantityservice.receive_qunatity(purchase_id,id,received_quantity).success(function(response) {
          LoaderService.hide();
          console.log(id);
        $scope.data = response;
        console.log($scope.data);
        console.log($scope.data.reference_no);

})
}

//console.log($scope.search.search);

$rootScope.exceed = function (){
  console.log($scope.search.search);

if(parseInt($scope.search.search) > parseInt($rootScope.data.products_detail[$scope.key].quantity)){

    var alertPopup = $ionicPopup.alert({
      template: 'Unexpected Value Provided !'
         });
            $scope.search.search= '';
           return;
         }
 }



 $scope.scanBarcode = function() {
    console.log('scanBarcode function got called');
     document.addEventListener("deviceready", function () {
    $cordovaBarcodeScanner.scan().then(function(imageData) {
       console.log(imageData);
      //alert(imageData.text);

      $scope.search.search = parseInt($scope.search.search) + 1;
    
if(parseInt($scope.search.search) > parseInt($rootScope.data.products_detail[$scope.key].quantity)){

    var alertPopup = $ionicPopup.alert({
      template: 'Unexpected Value Provided !'
         });
            $scope.search.search= '';
           return;
         }

    
    //   $timeout(function() {
    // var el = document.getElementById('linkid');
    //         angular.element(el).triggerHandler('click');
    //         }, 0);

       // document.getElementById('linkid').addEventListener("click", mysetFocus, true);
      console.log("Barcode Format -> " + imageData.format);
      console.log("Cancelled -> " + imageData.cancelled);
    }, function(error) {
      console.log("An error happened -> " + error);
    });
  });
  };

})

// app.controller('AppCtrl', function($scope, $ionicPopup, $filter) {
  
//      $scope.newUser = {};

//   $scope.$watch('newUser.birthDate', function(unformattedDate){
//     $scope.newUser.formattedBirthDate = $filter('date')(unformattedDate, 'dd/MM/yyyy HH:mm');
//   });

//   $scope.createContact = function() {
//     console.log('Create Contact', $scope.newUser);
//     $scope.modal.hide();
//   };
    
//   $scope.openDatePicker = function() {
//     $scope.tmp = {};
//     $scope.tmp.newDate = $scope.newUser.birthDate;
    
//     var birthDatePopup = $ionicPopup.show({
//      template: '<datetimepicker ng-model="tmp.newDate"></datetimepicker>',
//      title: "select date",
//      scope: $scope,
//      buttons: [
//        { text: 'Cancel' },
//        {
//          text: '<b>Save</b>',
//          type: 'button-positive',
//          onTap: function(e) {
//            $scope.newUser.birthDate = $scope.tmp.newDate;
//          }
//        }
//      ]
//     });
//   }
    

// })
 