// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services','ngCordova','ui.bootstrap.datetimepicker'])

.run(function($ionicPlatform,$rootScope,$ionicHistory,$window,$state) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }


  });
//console.log("DFDF");
  $rootScope.myGoBack = function () {
       $ionicHistory.goBack();
       
   };

   $rootScope.logout = function () {
    //alert("hiiiiiiiiiiiiii");
    $window.localStorage.clear();
    $ionicHistory.clearCache();
    $ionicHistory.clearHistory();
                $state.go('login');
            };
})

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

.state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html',
    // controller: 'PlaylistsCtrl'
  })


.state('login', {
    url: '/login',
    // views: {
      // 'menuContent': {
        templateUrl: 'templates/login.html',
        controller: 'DashCtrl'
      // }
    // }
  })


  // .state('login', {
  //   url: '/login',
  //       templateUrl: 'templates/login.html',
  //       controller: 'DashCtrl'
  //     })

 .state('app.home', {
    url: '/home',
    views: {
      'menuContent': {
  templateUrl: 'templates/home.html',
  controller: 'homectrl',
}
}, onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })
 

.state('url', {
    url: '/url',
  
    templateUrl: 'templates/url.html',
     controller: 'Urlctrl'
 
  })



.state('app.scan-code', {
    url: '/scan-code',
     views: {
      'menuContent': {
   templateUrl: 'templates/scan-code.html',
 }
},
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


.state('app.query_2', {
    url: '/query_2/:sale_id',
     views: {
      'menuContent': {
  templateUrl: 'templates/query_2.html',
  controller: 'singleproductCtrl',
  }
},
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('app.lookup', {
    url: '/lookup/:product_id',
     views: {
      'menuContent': {
    templateUrl: 'templates/lookup.html',
     controller: "singleProductEnquiry",
   }
 },
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })



.state('app.lookup_scan', {
        url: '/lookup_scan',
         views: {
      'menuContent': {
        templateUrl: 'templates/lookup_scan.html',
        controller :"ProductEnquiry",
           }
      },
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


.state('app.move', {
    url: '/move',
     views: {
      'menuContent': {
    templateUrl: 'templates/move.html',
    controller:'movetransferstock',
   }
 },
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('app.stock_check', {
    url: '/stock_check',
 views: {
      'menuContent': {
    templateUrl: 'templates/stock_check.html',
    controller:'stockCtrl',
  }
},
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


.state('app.query', {
    url: '/query/:id/:key',
 views: {
      'menuContent': {
    templateUrl: 'templates/query.html',
    controller:'singlereceivectrl'
  }
},
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


// .state('query', {
//     url: '/query',
//     templateUrl: 'templates/query.html'
   
//   })

.state('app.quantity-adjust', {
    url: '/quantity-adjust/:product_id',
     views: {
      'menuContent': {
       templateUrl: 'templates/quantity-adjust.html',
       controller:"stockProductCtrl",
     }
},
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


.state('app.Transfer-stock', {
    url: '/Transfer-stock/:product_id',
     views: {
      'menuContent': {
    templateUrl: 'templates/Transfer-stock.html',
    controller:"wareHouseCtrl",
  }
},
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('home');
       }
   }
  })




.state('app.detail', {
    url: '/detail',
    views: {
      'menuContent': {
     templateUrl: 'templates/detail.html',
     controller: 'productCtrl',
   }
 },
    onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


.state('app.pickorder', {
    url: '/pickorder',
    views: {
      'menuContent': {
     templateUrl: 'templates/pickorder.html', 
     controller: 'pickorderCtrl',
   }
 },
     onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('app.singlepickorder', {
    url: '/singlepickorder/:id',
     views: {
      'menuContent': {
     templateUrl: 'templates/singlepickorder.html', 
     controller: 'singlePickorder',
   }
 },
     onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('app.despatch', {
    url: '/despatch',
     views: {
      'menuContent': {
    templateUrl: 'templates/despatch.html',
  }
},
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

// $urlRouterProvider.otherwise('url');
$urlRouterProvider.otherwise(function ($injector, $location,Auth) {
        var $state = $injector.get('$state');
       var Auth = $injector.get('Auth');
if(!Auth.isLoggedIn()){
           $state.go('url');
        } else {
            $state.go('app.home');
        }
// //        $state.go('defaultLayout.error', {
// //            title: "Page not found",
// //            message: 'Could not find a state associated with url "'+$location.$$url+'"'
       })
     });






//https://github.com/jlinoff/PgBarcodeScanner.git.
//C:\ProgramData\Oracle\Java\javapath;%SystemRoot%\system32;%SystemRoot%;%SystemRoot%\System32\Wbem;%SYSTEMROOT%\System32\WindowsPowerShell\v1.0\;C:\Program Files\Skype\Phone\;C:\Program Files\nodejs\;D:\Xampp\php;C:\ProgramData\ComposerSetup\bin;C:\Program Files\Git\cmd
//C:\Program Files\nodejs\node_modules\npm;C:\Program Files\nodejs