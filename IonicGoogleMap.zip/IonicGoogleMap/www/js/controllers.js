angular.module('starter.controllers', ['uiGmapgoogle-maps'])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {
  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('PlaylistsCtrl', function($scope) {
  $scope.playlists = [
    { title: 'Reggae', id: 1 },
    { title: 'Chill', id: 2 },
    { title: 'Dubstep', id: 3 },
    { title: 'Indie', id: 4 },
    { title: 'Rap', id: 5 },
    { title: 'Cowbell', id: 6 }
  ];
})

.controller('PlaylistCtrl', function($scope, $stateParams) {
})

.controller('BrowseCtrl', function($scope, $ionicSideMenuDelegate, $cordovaGeolocation){
  $ionicSideMenuDelegate.canDragContent(false)

  $scope.map = {center: {latitude: 20.5937, longitude: 78.9629}, zoom: 8 };
  $scope.options = {scrollwheel: true, mapTypeId: "roadmap" };
  $scope.markericon = "img/moose.png"; 
  $scope.markers = []
  // get position of user and then set the center of the map to that position
  $cordovaGeolocation
    .getCurrentPosition()
    .then(function (position) { 
      var lat  = position.coords.latitude
      var long = position.coords.longitude
      $scope.map = {center: {latitude: lat, longitude: long}, zoom: 16 };
      //just want to create this loop to make more markers
     
        $scope.markers.push({
            id: $scope.markers.length,
            latitude: lat ,
            longitude: long ,
            icon: $scope.markericon,
            content: "I am located at" + lat + " ," + long
        });
   
    
  // $scope.onMarkerClick = function(marker, eventName, model) {
      //    //content: "I am located at " + lat + " ," + long
      // }
    }, function(err) {
      // error
    });
});
