app.controller('VisitorCtrl', function($scope,$q,$timeout, $stateParams, Auth,LoaderService,AlertService,$location,$ionicPopup,visitorService,checkoutservice) {
     

    console.log(Auth.getUser());
    var user_detail = Auth.getUser();
    console.log(user_detail.User);

    var limit = 1;
    var offset = 0;
    var isRefreshing = false;
    var dataFetcher = null;
    $scope.visitors = [];
    $scope.hasMore = true;
    
    
    // $scope.loader = true;
    LoaderService.show();
    function fetchData(offset, limit) {
    var received_data = [];
    //isAborted flag
    var isAborted = false;
    var deferred = $q.defer();
    var user_id= user_detail.User.id;
    console.log(user_id);
    //simulate async response
    $timeout(function() {
      if (!isAborted) {
          // get from $HTTP by using service
         visitorService.user_visitor(user_id,limit,offset).success(function (response){
            LoaderService.hide();
            $scope.total_records = response.count;
            console.log($scope.total_records);
            console.log(response);
                   
            LoaderService.hide();
            if (response.status == 1) {
            angular.forEach(response.data.pre_register, function (task, index){
                received_data.push(task);
            });
            deferred.resolve(received_data);
            //console.log(received_data);
            } 
            else{
              $scope.hasMore = false; 
            } 
        }).error(function (response){
            LoaderService.hide();
           AlertService.show("Error","Please check your network connection!","button-assertive");
        });
      } else {
        //when aborted, reject, and don't append the out-dated new data to the list
        deferred.reject();
      }
    }, 1000);
    
    return {
      promise: deferred.promise,
      abort: function() {    
        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
        isAborted = true;
         }
       };
    }

    $scope.doRefresh = function() {
    //resets the flags and counters.
        $scope.hasMore = true;
        offset = 0;
        isRefreshing = true;
        //aborts previous data fetcher
        if(!!dataFetcher) dataFetcher.abort();
        //triggers loadMore()
        $scope.loadMore();
      }

    //fetchData(offset, limit);
    $scope.loadMore = function() {
    //aborts previous data fetcher
     //$scope.hasMore = false;
    if(!!dataFetcher) dataFetcher.abort();
    //fetch new data
    dataFetcher=fetchData(offset, limit);
    dataFetcher.promise.then(function(received_data) {
      if (isRefreshing) {    
        //clear isRefreshing flag
        isRefreshing = false;
        //empty the favouries (delete old data) before appending new data to the end of the favouries.
        $scope.visitors.splice(0); 
        //hide the spin
        $scope.$broadcast('scroll.refreshComplete');
      }
      //Check whether it has reached the end
      if ($scope.total_records < offset || $scope.total_records == offset) $scope.hasMore = false;
      //append new data to the favouries
      $scope.visitors = $scope.visitors.concat(received_data);
      console.log($scope.visitors);
      window.localStorage.setItem('visitor_data1',JSON.stringify($scope.visitors));
      $scope.$broadcast('scroll.infiniteScrollComplete');
    
      //notify ion-content to resize after inner height has changed.
      //so that it will trigger infinite scroll again if needed.
      $timeout(function(){
      // $ionicScrollDelegate.$getByHandle('mainScroll').resize();
        });
      });
      //update itemOffset
        offset += limit; 
      };


       $scope.checkout =function(){
         $scope.visitor_data = JSON.parse(window.localStorage.getItem('visitor_data1'));
         console.log($scope.visitor_data);
         var id = $scope.visitor_data[0].Pre_register.id;
         console.log(id);
         // get from $HTTP by using service
         checkoutservice.check_out(id).success(function (response) {
         console.log(response);
       })
      }
})