app.controller('LoginCtrl', function($scope,$timeout,LoaderService,$location,$state,$ionicPopup,Auth,AlertService,$ionicHistory, $stateParams, LoginService) {
    $scope.user = {};
    $scope.login = function(user){
       // $timeout(function() { 
       //check username
    if ($scope.user.username === undefined) {
        AlertService.show("Error","Invalid username!","button-assertive");
        return;
    }
    if($scope.user.username == '') {
        AlertService.show("Error","Please enter your username!","button-assertive");
        return;
    }
    if($scope.user.password === undefined) {
        AlertService.show("Error","Please enter your password!","button-assertive");
        return;
    }
        LoaderService.show();
        // get from $HTTP by using service
        LoginService.post(user).success(function (response) {
                console.log(response);
                    LoaderService.hide();
                    if (response.status == 1) {
                        Auth.setUser(response.data);
                        $ionicHistory.clearCache();
                        var alertPopup = $ionicPopup.alert({
                        title: 'Success',
                        template: 'Successfully Logged in!'
                        }).then(function () {
                        $location.path('tab/terminal');
                        });
                    } 
                    else 
                    {
                        AlertService.show("Error","Wrong Credentials!","button-assertive");
                    } 
        }).error(function (response) {
                    LoaderService.hide();
                    AlertService.show("Error","Please check your network connection!","button-assertive");
                });
        console.log(user);
        // }, 6000);
    }
    
})