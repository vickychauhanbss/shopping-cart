// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services', 'ngCordova'])

.run(function($ionicPlatform,$rootScope,$ionicHistory,$window,$state) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
     }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }
     $rootScope.base_url ='http://amboff.indiit.com/vms/';
  });
$rootScope.myGoBack = function(){
  $ionicHistory.goBack();
}
$rootScope.logout = function(){
  $window.localStorage.clear();
  $ionicHistory.clearCache();
  $ionicHistory.clearHistory();
  $state.go('login');
}
})

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

  // setup an abstract state for the tabs directive
.state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
})

.state('login', {
    url: '/login',
        templateUrl: 'templates/login.html',
        controller: 'LoginCtrl'
})

.state('tab.terminal', {
    url: '/terminal',
    views: {
      'tab-dash': {
        templateUrl: 'templates/terminal.html',
        controller: 'terminal'
      }
    }
})

.state('tab.index', {
    url: '/index/:id',
    views: {
      'tab-dash': {
        templateUrl: 'templates/index.html',
        controller: 'singleTerminalCtrl'
     }
   }
})

.state('tab.register', {
    url: '/register',
    views: {
      'tab-dash': {
        templateUrl: 'templates/register.html',
        controller: 'RegisterCtrl'
     }
   }
})

.state('tab.add-host', {
    url: '/host/:id',
    views: {
      'tab-dash': {
        templateUrl: 'templates/add-host.html',
        controller: 'HostCtrl'
      }
    }
})

.state('tab.agreement', {
    url: '/agreement',
    views: {
      'tab-dash': {
        templateUrl: 'templates/agreement.html',
        controller: 'AgreementCtrl'
      }
    }
})

.state('tab.scan-barcode', {
    url: '/scan',
    views: {
      'tab-dash': {
        templateUrl: 'templates/scan-barcode.html',
        controller: 'ScanCtrl'
      }
    }
})

.state('tab.visitor', {
    url: '/visitor',
    views: {
      'tab-dash': {
        templateUrl: 'templates/visitor.html',
        controller: 'VisitorCtrl'
      }
    }
});

  // if none of the above states are matched, use this as the fallback
$urlRouterProvider.otherwise('/login');
});
//AIzaSyA2E305IZmuDz6f2Ig_lccb6099SK3VwIo
//https://awcdev.com/a-simple-example-of-how-to-take-credit-card-purchases-using-node-js-express-and-stripe/