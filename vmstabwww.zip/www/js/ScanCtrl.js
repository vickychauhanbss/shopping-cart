app.controller('ScanCtrl', function($scope, $stateParams) {
})

