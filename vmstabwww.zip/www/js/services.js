angular.module('starter.services', [])

/*************************** Auth_Service **********************************/
.factory('Auth', ['$state', function($state) { 
   if (window.localStorage['user_session']) {
      var _user = JSON.parse(window.localStorage['user_session']);
   }
   var setUser = function (user_session1) {
      _user = user_session1;
      window.localStorage['user_session'] = JSON.stringify(_user);
   }
   return {
           setUser: setUser,
           isLoggedIn: function () {
           return _user ? true : false;
           },
           getUser: function () {
           return _user;
           },
           logout: function () {
           window.localStorage.removeItem("user_session"); 
           window.localStorage.removeItem("list_dependents");
           _user = null;
           $state.go('index');
           }
         }
}])

/**************************** Login_Service ******************************/
.factory("LoginService",["$state","$http","api","$httpParamSerializer",function($state,$http,api,$httpParamSerializer){
console.log(api);
  return {
          post : function (data){
          return $http({
          method: 'post',
          url: api+'login',
          data: $httpParamSerializer(data),
          headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          },
          timeout : 60000
          }).success(function(response) {
          return response;
          }).error(function(response){
          return response;
          });
          return;
          }
        } 
}])

/************************************ HostTerminal_Service ***************************/

.factory("HostTerminalService",["$state","$http","api","$httpParamSerializer",function($state,$http,api,$httpParamSerializer){
  console.log(api);
    return {
        get : function (host_id,admin_id,offset, limit){
              return $http({
                method: 'get',
                url: api+'get_host_terminal/'+host_id+'/'+admin_id+'?offset='+offset+'&limit='+limit,
                //data: $httpParamSerializer(data),
                headers: {
                    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
                }).success(function(response) {
                return response;
                }).error(function(response){
                return response;
                });
                return;
                }
           } 
}])

/***********************************Loader_Service *************************************************/
.service('LoaderService', ['$ionicLoading',function($ionicLoading){
        return { 
                show : function(){
                       $ionicLoading.show({
                       template:'\
                       <ion-spinner icon="lines" class="spinner spinner-ripple"></ion-spinner>\
                       <div style="margin:auto;text-align:center">Please wait!!!</div>\
                       ',
                       content: 'Loading',
                       animation: 'fade-in',
                       showBackdrop: false,
                       maxWidth: 200,
                       showDelay: 0,
                       buttons: [{
                       text:'Okff',
                       type: 'button-assertive'
                       }]
                       }); 
                },
                hide:function(){
                       $ionicLoading.hide();
                 }
               }
}])
/************************* Alert_Service ***************************************/
.service('AlertService', ['$ionicPopup',function($ionicPopup){
        return { 
            show : function(title,content,buttonClass){
                $ionicPopup.alert({
                title: title,
                template: content,
                buttons: [{
                text:'Ok',
                type: buttonClass
                }]
                }).then(function () {
                // $ionicHistory.getBackView();
                });
            },
            hide:function(){
                       $ionicPopup.hide();
            }
        }
}])

/****************************** Register_Service *************************************/
.service('RegisterService',['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {

return{
       register : function(mergedObject) {

       return $http({
          method: 'POST',
          url: api+'register_user',
          data: $httpParamSerializer(mergedObject),
          headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
          }).success(function(response) {
          return response;
          });
          // return nukeService.data;
        }
      }
  }])




/************************** singleterminal_service ****************************************/
.service('singleterminalservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return{
       single_terminal: function(terminal_id) {
       
       return $http({
       method: 'get',
       url: api+'get_terminal_settings/'+terminal_id,
            
       headers: {
           'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
       timeout : 60000
                }).success(function(response) {
                return response;
                }).error(function(response){
                return response;
                });
                return;
       }
      }
}])

/***************************** visitor_Service ***************************************/
.service('visitorService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return{
       user_visitor: function(user_id, limit,offset) {
       
       return $http({

       method: 'get',

       url: api+'activity_report/'+user_id+'?limit='+limit+'&offset='+offset,
            
       headers: {
           'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
       timeout : 60000
                }).success(function(response) {
                return response;
                }).error(function(response){
                return response;
                });
                return;
       }
      }
}])


/********************************visitor_registor_service*************************************************/
.service('visitorregistorservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {

return{
       visitor_registor: function(id) {
       return $http({
       method: 'get',
       url: api+'visitor_form/'+id,
          
       headers: {
           'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
       timeout : 60000
                }).success(function(response) {
                return response;
                }).error(function(response){
                return response;
                });
                return;
       }
      }
}])

/**********************************Host_service*****************************************************/
.service('Hostservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {

return{
       host_user: function(admin_id,host_id,offset,limit) {
       return $http({
       method: 'get',
       url: api+'get_hosts/'+admin_id+'/'+host_id+'?offset='+offset+'&limit='+limit,
          
       headers: {
           'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
       timeout : 60000
                }).success(function(response) {
                return response;
                }).error(function(response){
                return response;
                });
                return;
       }
      }
}])

/**********************************visitor_Host_id_Service*****************************************************/
.service('visitorHostService',['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {

return{
       visitor_host : function(host_id,visitor_id) {
       return $http({
          method: 'POST',
          url: api+'update_host_id/'+host_id+'/'+visitor_id,
          data: $httpParamSerializer(),
          headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
          }).success(function(response) {
          return response;
          });
          
        }
      }
  }])

.service('checkoutservice',['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {

return{
       check_out : function(id) {
       return $http({
          method: 'get',
          url: api+'checkout/'+id,
          data: $httpParamSerializer(),
          headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
          }).success(function(response) {
          return response;
          });
          // return nukeService.data;
        }
      }
  }])

//**************************************** imageTake service **************************//
.service('imageTakeService',['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {

return{
       image_Take : function(imgURI) {

       return $http({
          method: 'POST',
          url: api+'upload_image',
          data: $httpParamSerializer(imgURI),
          headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
          }).success(function(response) {
          return response;
          });
          // return nukeService.data;
        }
      }
  }])
// var url = api+'get_hosts/'+admin_id+'/'+host_id+"?offset="+offset+"&limit="+limit