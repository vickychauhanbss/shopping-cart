app.controller('HostCtrl', function($scope,$q,$timeout,$state, $stateParams,Auth,LoaderService,AlertService,$location,$ionicPopup,Hostservice,visitorHostService) {
     

    console.log(Auth.getUser());
    var user_detail = Auth.getUser();
    console.log(user_detail.User);

    var limit = 1;
    var offset = 0;
    var isRefreshing = false;
    var dataFetcher = null;
    $scope.terminals = [];
    $scope.hasMore = true;
    $scope.visitor_host_id ={};
    var admin_id= user_detail.User.admin_id;
    var host_id= user_detail.User.id;
    var visitor_id =$stateParams.id;
   
    LoaderService.show();
    function fetchData(offset, limit) {
    var received_data = [];
    //isAborted flag
    var isAborted = false;
    var deferred = $q.defer();
    //simulate async response
     $timeout(function() {
       if (!isAborted) {
            // get from $HTTP by using service
            Hostservice.host_user(Auth.getUser().User.admin_id,Auth.getUser().User.id,offset,limit).success(function (response) {
            LoaderService.hide();
            $scope.total_records = response.count;
            console.log($scope.total_records);
           if (response.status == 1) {
             angular.forEach(response.data, function (task, index) {
                 received_data.push(task);
            });
            deferred.resolve(received_data);
            
             } else {
                AlertService.show("Error","Wrong Credentials!","button-assertive");
             } 
           }).error(function (response) {
            LoaderService.hide();
           AlertService.show("Error","Please check your network connection!","button-assertive");
            
           });
        } else {
        //when aborted, reject, and don't append the out-dated new data to the list
         deferred.reject();
      }
    }, 1000);
    
    return {
      promise: deferred.promise,
      abort: function() {    
        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
        isAborted = true;
         }
       };
    } 
   
    $scope.doRefresh = function() {  
    //resets the flags and counters.
        $scope.hasMore = true;
        offset = 0;
        isRefreshing = true;
        //aborts previous data fetcher
        if(!!dataFetcher) dataFetcher.abort();
        //triggers loadMore()
        $scope.loadMore();
     }
    $scope.loadMore = function() {
    //aborts previous data fetcher
    if(!!dataFetcher) dataFetcher.abort();
    //fetch new data
    dataFetcher=fetchData(offset, limit);
    dataFetcher.promise.then(function(received_data) {
      if (isRefreshing) {    
        //clear isRefreshing flag
        isRefreshing = false;
        //empty the favouries (delete old data) before appending new data to the end of the favouries.
        $scope.terminals.splice(0);
        //hide the spin
        $scope.$broadcast('scroll.refreshComplete');
      }
      //Check whether it has reached the end
      if ($scope.total_records < offset || $scope.total_records == offset) $scope.hasMore = false;
      //append new data to the favouries
      $scope.terminals = $scope.terminals.concat(received_data);
      console.log($scope.terminals);
      $scope.$broadcast('scroll.infiniteScrollComplete');
    
      //notify ion-content to resize after inner height has changed.
      //so that it will trigger infinite scroll again if needed.
      $timeout(function(){
      // $ionicScrollDelegate.$getByHandle('mainScroll').resize();
      });
      });
      //update itemOffset
        offset += limit; 
      };


$scope.visitor_host_id =function (){
    // get from $HTTP by using service
    visitorHostService.visitor_host(host_id,visitor_id).success(function(response){
    console.log(response);
    //if (response.status == 1) {
   
     var myPopup = $ionicPopup.show({
     template: ' Registation  Successfully !',
     scope: $scope,
     buttons: [
       {
         text: '<b>signup</b>',
         type: 'button-positive',
         onTap: function() {
            $state.go('tab.index');
            $timeout.cancel(time_out);
         }
       },
     ]
    })
      var time_out= $timeout(function() {
      //close the popup after 5 seconds for some reason
      $state.go('tab.register');
      myPopup.close();
      }, 5000);
  //}        
    }).error(function (response) {
           AlertService.show("Error","Please check your network connection!","button-assertive");
  });
  }
})

