app.controller('RegisterCtrl', function($scope,Auth,$state,$timeout,$stateParams, AlertService,$ionicPopup,LoaderService,visitorregistorservice,RegisterService,imageTakeService,$cordovaCamera) {
	  //$scope.phoneNumbr = /^\+?\d{4}[- ]?\d{4}[- ]?\d{2}$/;
    $scope.data ={};
    $scope.val ={};
    $scope.userdata =[];
    $scope.newarray =[];
    $scope.newfields =[];
    $scope.dyanmicdata =[];
    $scope.mergedObject =[];
    $scope.imgURI =[];

     
    console.log(Auth.getUser());
    var user_detail = Auth.getUser();
    console.log(user_detail.User);
   

function register_fields () {
  
    var id= user_detail.User.admin_id;
    LoaderService.show();
    $timeout(function() {
    visitorregistorservice.visitor_registor(id).success(function(response){
    LoaderService.hide();
    $scope.data = response.data;
    angular.forEach($scope.data, function(value, key){
    $scope.val = $scope.data[key].Visitor_form;
    $scope.newarray.push($scope.val);
    })
    $scope.firstfour = $scope.newarray.slice(0,4);
    //console.log($scope.firstfour);
    $scope.newfields = $scope.newarray.slice(4,8);
    angular.forEach($scope.newfields, function(value, key){
   // console.log(value);
    if($scope.newfields[key].type == "dropdown"){
      $scope.newfields[key]["html_field"] = $scope.newfields[key].meta_value.split(",");
    }
    if($scope.newfields[key].type == "yes/no"){
      $scope.newfields[key]["html_field"] =$scope.newfields[key].type.split("/");
    }    
    })    
  }).error(function (response) {
            LoaderService.hide();
           AlertService.show("Error","Please check your network connection!","button-assertive");
     });

  }, 1000);   
}
register_fields();


$scope.doRefresh =function(){
$scope.data="";
register_fields();
$scope.$broadcast('scroll.refreshComplete');
}

$scope.register_user= function () {
  console.log($scope.userdata);
    var first_name = $scope.userdata.first_name;
    var email = $scope.userdata.email;
    var mobile_number = $scope.userdata.mobile_number;
    var company = $scope.userdata.business_or_organisation;
    // console.log($scope.dyanmicdata);
    var admin_id= user_detail.User.admin_id;
    var user_id= user_detail.User.id;
    var terminal_id = JSON.parse(window.localStorage.getItem('user_terminal_id'));

    $scope.mergedObject = angular.extend($scope.userdata, $scope.dyanmicdata);
    $scope.mergedObject.admin_id = admin_id;
    $scope.mergedObject.user_id = user_id;
    $scope.mergedObject.terminal_id =terminal_id;
    // console.log($scope.mergedObject)



RegisterService.register($scope.mergedObject).success(function(response){
     console.log(response);
     var visitor_id =response.data.visitor_id;

          if (response.status == 1) {
                var alertPopup = $ionicPopup.alert({
                title: 'Success',
                template: ' Registation  Successfully !'
                }).then(function () {
                        $state.go('tab.add-host' ,{"id": visitor_id});
                });
           } 
          else {
               AlertService.show("Error","Wrong Credentials!","button-assertive");
          }
          }).error(function (response) {
               AlertService.show("Error","Please check your network connection!","button-assertive");
          });
}
     // angular.forEach($scope.dyanmicdata, function(value, key){
     // $scope.mydropdown=$scope.dyanmicdata;
     //console.log($scope.mydropdown);
     // var $tem_array = [];
     // var count = 0;
     // $tem_array['field_name'] = $scope.newfields[key].field_name;
     // $tem_array['value'] = value;
  
     // $scope.myfield=$tem_array;
     //  console.log($scope.myfield);
     // $scope.myfield[count]=$tem_array;
     // console.log($scope.myfield[count]);
     //count =count +1;
     //})
    
    $scope.submit =function(){
        //console.log($scope.firstfour[0].field_name);
        if($scope.userdata.first_name  === undefined || $scope.userdata.first_name.trim() == ''){
               AlertService.show("Info","first_name is required!","button-assertive");
               return;
        }
        if($scope.userdata.email  === undefined || $scope.userdata.email.trim() == ''){
               AlertService.show("Info","email is required!","button-assertive");
               return;
        }
        if($scope.userdata.mobile_number  === undefined || $scope.userdata.mobile_number.trim() == ''){
               AlertService.show("Info", "mobile_number is required!","button-assertive");
               return;
        }
        if($scope.userdata.business_or_organisation   === undefined || $scope.userdata.mobile_number.trim() == ''){
               AlertService.show("Info", "business_or_organisation is required!","button-assertive");
               return;
        }

        var keepGoing = true;
        angular.forEach($scope.newfields, function(value, key){
      
        if(keepGoing){
          if(value.required  == 1 && value.visible == 1 && $scope.dyanmicdata[value.field_name] === undefined){
                AlertService.show("Info", value.field_name +" "+ "is required!","button-assertive");
                keepGoing = false;
          }
        }
      })
      if(keepGoing == false){
          return;
      }
      $scope.register_user();   
    }




     $scope.takePhoto = function () {
    document.addEventListener("deviceready", function () {
                  var options = {
                    quality: 75,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 300,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
   
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                         $scope.imgURI  = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
      
                       }, false);

    imageTakeService.image_Take($scope.imgURI).success(function(response){
        console.log(response);
       $scope.imagedatashow= response;
         console.log($scope.imagedatashow);
            })
       
                }
              
                
                $scope.choosePhoto = function () {

                  document.addEventListener("deviceready", function () {
                  var options = {
                    quality: 75,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 300,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                }; 
   
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
                    }, false);
                }

//console.log($scope.imgURI);


})