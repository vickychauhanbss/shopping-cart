var app =angular.module('starter.services', [])
app.constant('api','http://amboff.indiit.com/inventorymanagement/webservice/')

/*********************** Loader Service  *******************************/
app.service('LoaderService', ['$ionicLoading',function($ionicLoading){
       return {
           show : function(){
               $ionicLoading.show({
                       template:'\
                <ion-spinner icon="ripple" class="spinner spinner-ripple"></ion-spinner> \
                   <div style="margin:auto;text-align:center">Please wait!!!</div>\
                   ',
               content: 'Loading',
               animation: 'fade-in',
               showBackdrop: false,
               maxWidth: 200,
               showDelay: 0
             }); 
           },
           hide:function(){
               $ionicLoading.hide();
           }
       }
}])


/****************************** Auth factory *****************************/
.factory('Auth', ['$state', function($state) {

  if (window.localStorage['user_session']) {
     var _user = JSON.parse(window.localStorage['user_session']);
  }
  var setUser = function (user_session1) {
     _user = user_session1;
     window.localStorage['user_session'] = JSON.stringify(_user);
     user_detail = JSON.stringify(_user);
  }
  return {
     setUser: setUser,
     isLoggedIn: function () {
        return _user ? true : false;
     },
     getUser: function () {
        return _user;
     },
     logout: function () {
        window.localStorage.removeItem("user_session");
        window.localStorage.removeItem("list_dependents");
        user_detail = {};
        _user = null;
        $state.go('login');
     }
  }
}])

/******************************** Login Service **********************************/
.service('LoginService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
   return {
       loginUser: function(username, password) {
        console.log(username);
        console.log(password);
           
           return $http({
               method: 'get',
               url: api+'login?username='+username+"&password="+password,
      
                headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
           
           }).success(function(response) {
               return response;
               console.log(response);
               if (response.data.status == 1) {
                   return response.data;
               } else {
                   return false;
               }
           }).error(function(response){
            return response;
           });
       }
   }
}])

/*********************** product Service ***********************/
.service('productService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       panding: function(id) {
        console.log(id);
 return $http({
  method: 'get',
  url: api+'get_pending_purchase_product?user_id='+id,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);

           });
       }
   }


}])
/******************** singleProductService *******************/
.service('singleProductService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       singleProduct: function(id) {
        console.log(id);
 return $http({
  method: 'get',
  url: api+'get_pending_purchase_product?sale_id='+id,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
               if (response.data.status == 1) {
                   return response.data;

               } else {
                   return false;
               }
           });
       }
   }


}])


/************************* ProductEnquiry Service ************************/
 .service('ProductEnquiryService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
 return {
       EnquiryProduct : function(){
        // console.log(id);
 return $http({
  method: 'get',
  url: api+'get_products',
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
               
                   return response.data;
           });
       }
   }

}])
 


/*************** singleProductEnquiry Service ******************************/
.service('singleProductEnquiryService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       singleEnquiryProduct: function(id) {
        console.log(id);
 return $http({
  method: 'get',
  url: api+'get_product?product_id='+id,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);

           });
       }
   }


}])


/****************** stockCheck Service ***************************/
.service('stockCheckService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
 return {
       stockCheck : function(){
        // console.log(id);
 return $http({
  method: 'get',
  url: api+'get_products',
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
                   return response.data;

           });
       }
   }

}])


//************************ move /transfer service *********************************//


// .service('moveservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
//  return {
//        move_transfer : function(){
//         // console.log(id);
//  return $http({
//   method: 'get',
//   url: api+'get_products',
            
// headers: {
//    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
// }).success(function(response) {
//                return response;
//                console.log(response);
//                    return response.data;

//            });
//        }
//    }

// }])

/**************************** singlestock Service *********************************/
.service('singlestockService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       singlestock: function(id) {
        console.log(id);
 return $http({
  method: 'get',
  url: api+'get_product?product_id='+id,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
           });
       }
   }


}])


/*************** QuantityUpdate Service **************************/
.service('QuantityUpdateService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       Quantity_updated: function(id ,quantity) {
        console.log(id);
         console.log(quantity);
 return $http({
  method: 'get',
  url: api+'update_stock?product_id='+id+'&quantity='+quantity,                                
  // url: api+'update_stock?product_id='+id +'&quantity='+quantity,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);

           }).error(function(response){
            return response;
           });
       }
   }


}])


/****************************** warehouse Service **********************************/
.service('warehouseService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       warehouse_product: function(id) {
        console.log(id);
 return $http({
  method: 'get',
  url: api+'get_warehouses?user_id='+id,
  // url: api+'update_stock?product_id='+id +'&quantity='+quantity,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);

           });
       }
   }


}])

/********************************** pickorder service  ********************************************/
.service('pickorderservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
 return {
       pick_order : function(id){
        // console.log(id);
 return $http({
  method: 'get',
  url: api+'get_sale_orders',
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
                   return response.data;

           });
       }
   }

}])

/****************************** singlepickorder service ***********************************/
.service('singlepickorderservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
 return {
       singlepick_order : function(id){
         console.log(id);
 return $http({
  method: 'get',
  url: api+'get_sale_orders/'+id,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
                   return response.data;

           });
       }
   }

}])


/*********************************** transferstock service ***************************/
.service('transferstockservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       trasfer_stock: function(from,to,id ,quantity) {
        console.log(id);
         console.log(quantity);
         console.log(from);
         console.log(to);
 return $http({
  method: 'get',
  url: api+'update_warehouse_stock?from='+id+'&to='+id+'&product_id='+id+'&quantity='+quantity,                                
  // url: api+'update_stock?product_id='+id +'&quantity='+quantity,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);

           }).error(function(response){
            console.log(response);
            return response;
           });
       }
   }


}])



//******************************** url service *****************************************//
.service('urlservice', ['$http',"$timeout","$location","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
 return {
       my_url : function(text){
         console.log(text);
 return $http({
  method: 'get',
  url: text+'updateapiurl?apiurl='+text,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
                   return response.data;

           });
       }
   }

}])


//**************************** receive quantity service *************************************//
.service('receivequantityservice', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
return {
       receive_qunatity: function(purchase_id,id,received_quantity) {
        console.log(purchase_id);
        console.log(id);
        console.log(received_quantity);
 return $http({
  method: 'get',
  url: api+'received_product_quantity?purchase_id='+purchase_id+'&product_id='+id+'&received_quantity='+received_quantity,                                
  // url: api+'update_stock?product_id='+id +'&quantity='+quantity,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);

           }).error(function(response){
            return response;
           });
       }
   }


}])

