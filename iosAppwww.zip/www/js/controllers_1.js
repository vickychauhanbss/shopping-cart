

function get_location(cityname) {
    console.log(cityname);
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({'address': cityname + ', us'}, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            console.log(results[0].geometry.location);
            var return_obj = {};
            return_obj["lat"] = results[0].geometry.location.lat();
            return_obj["lng"] = results[0].geometry.location.lng();
            console.log(return_obj);
            return return_obj;
//            alert("location : " + results[0].geometry.location.lat() + " " +results[0].geometry.location.lng()); 
        } else {

            return false;
        }
    });
}

var cities = [
    {
        city: 'ldh',
        desc: 'This is the best city in the world!',
        lat: 33.58,
        long: 85.85
    },
    {
        city: 'chandigarh',
        desc: 'This city is aiiiiite!',
        lat: 51.88,
        long: 176.65
    },
    {
        city: 'shimla',
        desc: 'This is the second best city in the world!',
        lat: 32.17,
        long: 110.88
    },
    {
        city: 'Arkansas',
        desc: 'This city is live!',
        lat: 35.97,
        long: 89.95
    },
    {
        city: 'California',
        desc: 'Sin City...\'nuff said!',
        lat: 37.78,
        long: 122.32
    }
];
var cities1 = [
    {
        city: 'Alabama',
        desc: 'This is the best city in the world!',
        lat: 33.58,
        long: 85.85
    },
    {
        city: 'Alaska',
        desc: 'This city is aiiiiite!',
        lat: 51.88,
        long: 176.65
    },
    {
        city: 'Arizona',
        desc: 'This is the second best city in the world!',
        lat: 32.17,
        long: 110.88
    },
    {
        city: 'Arkansas',
        desc: 'This city is live!',
        lat: 35.97,
        long: 89.95
    },
    {
        city: 'California',
        desc: 'Sin City...\'nuff said!',
        lat: 37.78,
        long: 122.32
    }
];

angularmodule = angular.module('starter.controllers', ["angularFileUpload", "ionic.rating"]);

angularmodule.constant('api', 'http://amboff.indiit.com/boozy/webservices/').run(function ($ionicHistory, $location, $rootScope, $state) {
    user_detail = {};
    if (localStorage.getItem('user_session') != null) {
        user_detail = JSON.parse(localStorage.getItem('user_session'));
    } else {

    }

    $rootScope.myGoBack = function () {
        console.log("back");
        $ionicHistory.goBack();
    };
    $rootScope.setItemsGlobal = function (items) {
        var get_comments = [];
        angular.forEach(items, function (task, index) {
            get_comments.push(task)
        });
        return get_comments;
    }
})

        .controller("LogoutCtrl", function ($state, Auth) {
            Auth.logout();
            alert("hello");
            console.log("logout");
            $state.go('index');
        }).controller("IndexCtrl", function ($state, Auth, $scope) {


})
.controller('SharingCtrl', function($scope, $cordovaSocialSharing) {

  $scope.share = function () {
    $cordovaSocialSharing.share('This is my message', 'Subject string', null, 'http://www.mylink.com');
}

// Share via email. Can be used for feedback
$scope.sendFeedback = function () {
    $cordovaSocialSharing
            .shareViaEmail('Some message', 'Some Subject', 'to_address@gmail.com');
}

// Share via SMS. Access multiple numbers in a string like: '0612345678,0687654321'
$scope.sendSMS = function (message, number) {
    $cordovaSocialSharing.shareViaSMS(message, number);
}
})
        .controller("FavouritesdetailCtrl", function ($scope, $location, $ionicHistory, $stateParams, LoaderService, $ionicPopup, $state, RestaurantService, AddloveService) {


            var limit = 1;
            var offset = 0;
            var type = 1;
            var check_url = $location.url().split('/');
            switch (check_url[2]) {
                case 'dash-favourites-detail':
                    $scope.tab_suffix = "dash-";
                    break;
                case 'fav-favourites-detail':
                    $scope.tab_suffix = "fav-";
                    break;
                case 'fav-favourites-detail-brunches':
                    type = 2;
                break;
                default:
                    $scope.tab_suffix = '';
                    break;
            }
            if ($stateParams.cityID !== undefined) {
                var cityID = $stateParams.cityID;
                var cities = JSON.parse(localStorage.getItem('cities'));
                angular.forEach(cities, function (value, key) {
                    if (value['id'] == parseInt(cityID)) {
                        $scope.city_name = value.city;
                    }
                });
                $scope.cityID = "/" + cityID;
            } else {
                $scope.cityID = '';
            }
            $scope.loader = false;

            $scope.advertisements = [];
            function setItems(items) {
                angular.forEach(items, function (task, index) {
                    $scope.advertisements.push(task)
                });
            }
            function get_advertisement() {
//                
                RestaurantService.get(offset, limit,type, cityID).success(function (response) {
                    console.log(response);
                    LoaderService.hide();
                    $scope.loader = true;
                    if (response.status == 1) {
                        offset = offset + limit;
                        setItems(response.data);
                    } else {
                        $scope.loader = false;
                    }
                    if (offset >= response.count) {
                        $scope.loader = false;
                    } else {
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            LoaderService.show();
            get_advertisement(offset, limit);

            $scope.doRefresh = function () {
                LoaderService.show();
                offset = 0;
                $scope.advertisements = [];
//                $scope.loader = true;
                get_advertisement(offset, limit);
                $scope.$broadcast('scroll.refreshComplete');
            }
            $scope.loadMore = function () {
//        offset  = offset + limit;
                get_advertisement(offset, limit);
            }
            $scope.add_love = function (id, key) {
                if ($scope.advertisements[key]["love"] == false) {
                    $scope.advertisements[key]["love"] = true;
                } else {
                    $scope.advertisements[key]["love"] = false;
                }
                var data_obj = {};
                if (localStorage.getItem('user_session') != null) {
                    $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                    $scope.user_login = true;

                }
                data_obj["user_id"] = $scope.user_detail.id;
                data_obj["ad_id"] = id;
                data_obj["meta_key"] = "love_advertisement";
                console.log(data_obj);
                AddloveService.get(data_obj).success(function (response) {
                    LoaderService.hide();
                    console.log(response);
                    if (response.status == 1) {

                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
        })
        .controller('FavouritesCtrl', function (LoaderService, $scope, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, FavouriteService) {
            var limit = 3;
            $scope.loader = false;
            var offset = 0;
            $scope.favouries = [];
            function setItems(items) {
                var return_data = [];
                angular.forEach(items, function (task, index) {
                    $scope.favouries.push(task)
                });
            }
            function favourites() {
//        user_detail.id= 1;
$scope.loader = false;
                FavouriteService.get(user_detail.id, offset, limit).success(function (response) {
                    LoaderService.hide();
                    
                    console.log(response);
                    if (response.status == 1) {
                        offset = offset + limit;
                        setItems(response.data);
//               console.log(response.data);
                        console.log(response.data);
                    }
                    $scope.loader = true;
                    if (offset >= response.count) {
                        $scope.loader = false;
                    }

                    $scope.$broadcast('scroll.refreshComplete');
                }).error(function () {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                });
            }
            $scope.loadMore = function () {
//        offset  = offset + limit;
                favourites();
            }
            $scope.doRefresh = function () {
                LoaderService.show();
                offset = 0;
                $scope.favouries = [];
                $scope.loader = true;
                favourites();
                $scope.$broadcast('scroll.refreshComplete');
            }
            LoaderService.show();
//        LoaderService.hide();

            favourites();
        })
        .controller('StatelistingCtrl', function (LoaderService, $scope, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, StateListingService) {
            var limit = 9;
             var offset = 0;
            $scope.loader = false;
           
            $scope.favouries = [];
            function setItems(items) {
                var return_data = [];
                angular.forEach(items, function (task, index) {
                    $scope.favouries.push(task)
                });
            }
            function get_listing() {
//        user_detail.id= 1;
$scope.loader = false;
                StateListingService.get(offset, limit).success(function (response) {
                    LoaderService.hide();
                    
                    console.log(response);
                    if (response.status == 1) {
                        offset = offset + limit;
                        setItems(response.data);
//               console.log(response.data);
                        console.log(response.data);
                    }
                    $scope.loader = true;
                    if (offset >= response.count) {
                        $scope.loader = false;
                    }

//                    $scope.$broadcast('scroll.refreshComplete');
                }).error(function () {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                });
            }
            $scope.loadMore = function () {
//        offset  = offset + limit;
                get_listing();
            }
            $scope.doRefresh = function () {
                LoaderService.show();
                offset = 0;
                $scope.favouries = [];
                $scope.loader = true;
                get_listing();
//                $scope.$broadcast('scroll.refreshComplete');
            }
            LoaderService.show();
//        LoaderService.hide();

            get_listing();
        })
        .controller('StateCitylistingCtrl', function (LoaderService,$stateParams, $scope, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, StateCityListingService) {
            var limit = 9;
             var offset = 0;
            $scope.loader = false;
            var stateID = $stateParams.stateID;
            $scope.favouries = [];
            function setItems(items) {
                var return_data = [];
                angular.forEach(items, function (task, index) {
                    $scope.favouries.push(task)
                });
            }
            function get_listing() {
//        user_detail.id= 1;
$scope.loader = false;
                StateCityListingService.get(stateID,offset, limit).success(function (response) {
                    LoaderService.hide();
                    
                    console.log(response);
                    if (response.status == 1) {
                        offset = offset + limit;
                        setItems(response.data);
//               console.log(response.data);
                        console.log(response.data);
                    }
                    $scope.loader = true;
                    if (offset >= response.count) {
                        $scope.loader = false;
                    }

//                    $scope.$broadcast('scroll.refreshComplete');
                }).error(function () {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                });
            }
            $scope.loadMore = function () {
//        offset  = offset + limit;
                get_listing();
            }
            $scope.doRefresh = function () {
                LoaderService.show();
                offset = 0;
                $scope.favouries = [];
                $scope.loader = true;
                get_listing();
//                $scope.$broadcast('scroll.refreshComplete');
            }
            LoaderService.show();
//        LoaderService.hide();

            get_listing();
        })
        
        .controller("BlogdetailCtrl", function ($scope, $ionicHistory, LoaderService, $location, $ionicHistory, FlashService, $ionicPopup, $state, $stateParams, BlogService, SubmitcommentService) {
            $scope.loader = true;
            $scope.user_login = false;
            $scope.comments = {};
            $scope.user_detail = {};

            if (localStorage.getItem('user_session') != null) {
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;

            }
            var blogId = $stateParams.blogId
            LoaderService.show({
//        template:"Loading..."
            });
            $scope.get_comments = [];
            function setItems(items) {
                angular.forEach(items, function (task, index) {
                    $scope.get_comments.push(task)
                });
            }
            $scope.blog = {};
            function get_blogs() {
                BlogService.getsingleBlog(blogId).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 0) {

                    } else {
                        $scope.blog = response.data;
                        if (response.data.comments) {
                            setItems(response.data.comments);
                        }
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        $scope.$broadcast('scroll.refreshComplete');
                    }
//        localStorage.setItem('cities', JSON.stringify($scope.cities));
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                    ;
                });

            }
            get_blogs();
            $scope.doRefresh = function () {
                $scope.get_comments = [];
                get_blogs();
//             $scope.$broadcast('scroll.refreshComplete');
            }
            // submit form
//         $ionicPopup.alert({
//            title: 'Password Check',
//            template: 'Enter your secret password',
////            inputType: 'password',
////            inputPlaceholder: 'Your password'
//          }).then(function(res) {
//              $ionicHistory.getBackView();
//            console.log('Your password is', res);
//          });

            $scope.submitmessage = function () {
                $scope.comments.user_id = $scope.user_detail.id;
                $scope.comments.template = "blogs";
                $scope.comments.template_id = blogId;
                LoaderService.show();
                SubmitcommentService.register($scope.comments).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {
                        $scope.comments.comment = "";
                        $scope.get_comments.push(response.data);
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                        $scope.success = true;
                    } else {
                        LoaderService.hide();
                        var alertPopup = $ionicPopup.alert({
                            title: 'Error',
                            template: 'Error while posting your comment!'
                        });
                    }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());


                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
                    });

                });
            }
        }).controller('BrunchmapCtrl', function ($scope,ionicLoading, $compile, $window, $ionicHistory, LoaderService, $compile) {
    function google_map(cities){
    var mapOptions = {
        zoom: 4,
        center: new google.maps.LatLng(25, 80),
        mapTypeId: google.maps.MapTypeId.TERRAIN
    }

    $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);

    $scope.markers = [];

    var infoWindow = new google.maps.InfoWindow();

    var createMarker = function (info) {

        var marker = new google.maps.Marker({
            map: $scope.map,
            position: new google.maps.LatLng(info.lat, info.long),
            title: info.city
        });
        marker.content = '<div class="infoWindowContent">' + info.desc + '</div>';

        google.maps.event.addListener(marker, 'click', function () {
            infoWindow.setContent('<h2>' + marker.title + '</h2>' + marker.content);
            infoWindow.open($scope.map, marker);
        });

        $scope.markers.push(marker);

    }

    for (i = 0; i < cities.length; i++) {
        createMarker(cities[i]);
    }

    $scope.openInfoWindow = function (e, selectedMarker) {
        e.preventDefault();
        google.maps.event.trigger(selectedMarker, 'click');
    }
}
//google_map(cities1);


function initialize() {
        google.maps.event.addDomListener(window, 'load');

        var myLatlng = new google.maps.LatLng(43.07493, -89.381388);

        var mapOptions = {
            center: myLatlng,
            zoom: 16,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"),
        mapOptions);

        //Marker + infowindow + angularjs compiled ng-click
        var contentString = "<div><a ng-click='clickTest()'>Click me!</a></div>";
        var compiled = $compile(contentString)($scope);

        var infowindow = new google.maps.InfoWindow({
            content: compiled[0]
        });

        var marker = new google.maps.Marker({
            //your random marker generation code
        });

        google.maps.event.addListener(marker, 'click', function () {
            infowindow.open(map, marker);
        });

        $scope.map = map;
    }

    






}).controller('HappyhourmapCtrl', function ($scope, $ionicHistory, LoaderService, $compile) {
function pinSymbol(color) {
    return {
        path: 'M 0,0 C -2,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z M -2,-30 a 2,2 0 1,1 4,0 2,2 0 1,1 -4,0',
        fillColor: color,
        fillOpacity: 1,
        strokeColor: '#000',
        strokeWeight: 2,
        scale: 1,
   };
}
//    $ionicHistory.clearCache();
function google_map(cities,IconColor){
    var mapOptions = {
        zoom: 4,
        center: new google.maps.LatLng(25, 80),
        mapTypeId: google.maps.MapTypeId.TERRAIN,
    }
    $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);
    $scope.markers = [];
    var infoWindow = new google.maps.InfoWindow();
    var createMarker = function (info) {
        var marker = new google.maps.Marker({
            map: $scope.map,
            position: new google.maps.LatLng(info.lat, info.long),
            title: info.city,
            icon: {url:  IconColor}
        });
        marker.content = '<div class="infoWindowContent"><a href="#/tab/map-brunch-listing-detail/3"> ' + info.desc + '</a></div>';
        google.maps.event.addListener(marker, 'click', function () {
            infoWindow.setContent('<h2 class="my-map-add">' + marker.title + '</h2>' + marker.content);
            infoWindow.open($scope.map, marker);
        });
        $scope.markers.push(marker);
    }
    for (i = 0; i < cities.length; i++) {
        createMarker(cities[i]);
    }
    $scope.openInfoWindow = function (e, selectedMarker) {
        e.preventDefault();
        google.maps.event.trigger(selectedMarker, 'click');
    }
}
google_map(cities,  "img/map-marker-icon-happy.png" );
$scope.brunches = function (){
    google_map(cities1,  "img/map-marker-icon-brunch.png" );
}
$scope.happyHours = function (){
    google_map(cities,  "img/map-marker-icon-happy.png" );
}

//initMap(latlng,cities,  "img/map-marker-icon-brunch.png");

}).controller('BrunchlstCtrl', function ($scope, $location, $ionicHistory, $stateParams, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService) {
    var limit = 3;
    var offset = 0;
    
    if ($stateParams.cityId !== undefined) {
        var cityID = $stateParams.cityId;
    } else {
        var cityID = null;
    }


    var check_url = $location.url().split('/');
    switch (check_url[2]) {
        case 'dash-brunch-listing':
            $scope.tab_suffix = "dash-";
            break;
        case 'fav-brunch-listing':
            $scope.tab_suffix = "fav-";
            break;
        default:
            $scope.tab_suffix = '';
            break;
    }


    $scope.advertisements = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $scope.advertisements.push(task)
        });
    }
    function get_advertisement() {
        RestaurantService.get(offset, limit, 2, cityID).success(function (response) {
            LoaderService.hide();
            $scope.loader = true;
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    LoaderService.show();
    get_advertisement(offset, limit);

    $scope.doRefresh = function () {
        LoaderService.show();
        offset = 0;
        $scope.advertisements = [];
        get_advertisement(offset, limit);
        $scope.$broadcast('scroll.refreshComplete');
    }
    $scope.loadMore = function () {
//        offset  = offset + limit;
        get_advertisement(offset, limit);
    }
    $scope.add_love = function (id, key) {
        if ($scope.advertisements[key]["love"] == false) {
            $scope.advertisements[key]["love"] = true;
        } else {
            $scope.advertisements[key]["love"] = false;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;

        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {

            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
}).controller('imageloader', function ($scope) {
    // don't be scared by the image value, its just datauri

    $scope.items = [
        {id: 1, name: 'Cat 1', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 2, name: 'Cat 2', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 3, name: 'Cat 3', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 4, name: 'Cat 4', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 5, name: 'Cat 5', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 6, name: 'Cat 6', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 7, name: 'Cat 7', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 8, name: 'Cat 8', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 9, name: 'Cat 9', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'}

    ];

}).controller('BrunchlstCtrl', function ($scope, $location, $ionicHistory, $stateParams, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService, CountClickService) {
    var limit = 3;
    var offset = 0;
    $scope.loader = true;
    var cityID = $stateParams.cityID;
    if ($stateParams.cityID !== undefined) {
        var cities = JSON.parse(localStorage.getItem('cities'));
        angular.forEach(cities, function (value, key) {
            if (value['id'] == parseInt(cityID)) {
                $scope.city_name = value.city;
            }
        });

        $scope.cityID = "/" + cityID;
    } else {
        $scope.cityID = '';
    }
    var check_url = $location.url().split('/');
    switch (check_url[2]) {
        case 'dash-brunch-listing':
            $scope.tab_suffix = "dash-";
            break;
        case 'fav-brunch-listing':
            $scope.tab_suffix = "fav-";
            break;
        default:
            $scope.tab_suffix = '';
            break;
    }


    $scope.advertisements = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $scope.advertisements.push(task)
        });
    }

    $scope.focus = function (ad_id, key) {

        if ($scope.advertisements[key]["view"] === false) {
            return;
        }
        $scope.advertisements[key]["view"] = false;
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_detail.id;
        click_detail["type"] = "view";
        CountClickService.add(click_detail).success(function (response) {
        }).error(function (response) {
        });
    }

    function get_advertisement() {
        RestaurantService.get(offset, limit, 2, cityID,"alldata").success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    LoaderService.show();
    get_advertisement(offset, limit);

    $scope.doRefresh = function () {
        LoaderService.show();
        offset = 0;
        $scope.advertisements = [];
        $scope.loader = true;
        get_advertisement(offset, limit);
        $scope.$broadcast('scroll.refreshComplete');
    }
    $scope.loadMore = function () {
//        offset  = offset + limit;
        get_advertisement(offset, limit);
    }
    $scope.add_love = function (id, key) {
        if ($scope.advertisements[key]["love"] == false) {
            $scope.advertisements[key]["love"] = true;
        } else {
            $scope.advertisements[key]["love"] = false;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;

        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {

            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
}).controller("MapCtrl", function ($scope) {
    google.maps.event.addDomListener(window, "load", function () {
        var myLatLng = new google.maps.LatLng(37.00, -120.4833);
        var mapOptions = {
            center: myLatLng,
            zoom: 18,
            myTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
        $scope.map = map;


    })
}).controller('HappyhourdetailCtrl', function ($scope, CountClickService, $stateParams, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService, SubmitcommentService, $ionicModal) {
    var ad_id = $stateParams.ad_id;
    $scope.advertisement = {}; 
    $scope.comments = {};
    if (localStorage.getItem('user_session') != null) {
        $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
        $scope.user_login = true;
    }
//            rating

    $scope.comments.rating = 3;
    $scope.commentmax = 5;

    $scope.get_comments = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $scope.get_comments.push(task)
        });
    }
    function add_click(ad_id, user_id) {
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_id;
        CountClickService.add(click_detail).success(function (response) {
        }).error(function (response) {
        });
    }

    function get_advertisement(ad_id) {
        RestaurantService.getsingle(ad_id, $scope.user_detail.id).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                $scope.advertisement = response.data;
                if (response.data.comments) {
                    setItems(response.data.comments);
                }
            } else {
                $scope.loader = false;
            }
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
            $ionicPopup.hide();
            $scope.$broadcast('scroll.refreshComplete');
        });
    }
    LoaderService.show();
    get_advertisement(ad_id);
    // add click
    add_click(ad_id, user_detail.id);
    $scope.doRefresh = function () {
        $scope.get_comments = [];
        get_advertisement(ad_id);
    }
    $scope.submitmessage = function () {
        $scope.comments.user_id = $scope.user_detail.id;
        $scope.comments.template = "advertisement";
//             $scope.comments.rating = "advertisement";
        console.log($scope.comments);
        $scope.comments.template_id = ad_id;
        LoaderService.show();
        SubmitcommentService.register($scope.comments).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                $scope.comments.comment = "";
                $scope.get_comments.push(response.data);
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                $scope.success = true;
            } else {
                LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Error while posting your comment!'
                });
            }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());


        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });

        });
        
   
    }
    // modal code
     // modal
    $ionicModal.fromTemplateUrl('templates/comment_modal.html', {
      scope: $scope,
      animation: 'slide-in-top'
   }).then(function(modal) {
      $scope.modal = modal;
   });
    $scope.getAllComments = {};
   $scope.openModal = function() {
      LoaderService.show();
      RestaurantService.getComments(ad_id,"advertisement").success(function (response) {
          LoaderService.hide();
          $scope.getAllComments = response.data;
      }).error(function(response){
          LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });
      });
      $scope.modal.show();
   };
	
   $scope.closeModal = function() {
      $scope.modal.hide();
   };
	
   //Cleanup the modal when we're done with it!
   $scope.$on('$destroy', function() {
      $scope.modal.remove();
   });
	
   // Execute action on hide modal
   $scope.$on('modal.hidden', function() {
      // Execute action
   });
	
   // Execute action on remove modal
   $scope.$on('modal.removed', function() {
      // Execute action
   });
    $scope.add_love = function (id) {
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;

        }
        if ($scope.advertisement.love == false) {
            $scope.advertisement.love = true;
        } else {
            $scope.advertisement.love = false;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {

            LoaderService.hide();
            console.log(response);
            if (response.status == 1) {

            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }


}).controller('BrunchdetailCtrl', function ($scope, CountClickService,$ionicModal, $stateParams, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService, SubmitcommentService) {
//alert("hello");
$scope.show = false;
    var ad_id = $stateParams.ad_id;
    $scope.advertisement = {};
    $scope.comments = {};
    if (localStorage.getItem('user_session') != null) {
        $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
        $scope.user_login = true;
    }
//            rating

    $scope.comments.rating = 3;
    $scope.commentmax = 5;
    function add_click(ad_id, user_id) {
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_id;
        CountClickService.add(click_detail).success(function (response) {
        }).error(function (response) {
        });
    }
    add_click(ad_id, user_detail.id);
    $scope.get_comments = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $scope.get_comments.push(task)
        });
    } 
    // google map

function google_map(cities,IconColor){
    var mapOptions = {
        zoom: 4,
        dragging : false,
        center: new google.maps.LatLng(25, 80),
        mapTypeId: google.maps.MapTypeId.TERRAIN,
    }
    $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);
    $scope.markers = [];
    var infoWindow = new google.maps.InfoWindow();
    var createMarker = function (info) {
        var marker = new google.maps.Marker({
            map: $scope.map,
            position: new google.maps.LatLng(info.lat, info.long),
            title: info.city,
            icon: {url:  IconColor}
        });
        marker.content = '<div class="infoWindowContent"><a href="#/tab/map-brunch-listing-detail/3"> ' + info.desc + '</a></div>';
        google.maps.event.addListener(marker, 'click', function () {
            infoWindow.setContent('<h2 class="my-map-add">' + marker.title + '</h2>' + marker.content);
            infoWindow.open($scope.map, marker);
        });
        $scope.markers.push(marker);
    }
    for (i = 0; i < cities.length; i++) {
        createMarker(cities[i]);
    }
    $scope.openInfoWindow = function (e, selectedMarker) {
        e.preventDefault();
        google.maps.event.trigger(selectedMarker, 'click');
    }
}
    function get_advertisement(ad_id) {
        RestaurantService.getsingle(ad_id, user_detail.id).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                $scope.show = true;
                $scope.advertisement = response.data;
               
               
               if($scope.advertisement.lat){
    
} else {
   $scope.advertisement['lat'] = 33.58;
   $scope.advertisement['lng'] = 85.85;
   
}
var brunch = [
    {
        city: $scope.advertisement.title,
        desc: $scope.advertisement.detail,
        lat: $scope.advertisement.lat,
        long: $scope.advertisement.lng
    }
]
google_map(brunch,  "img/map-marker-icon-brunch.png");
                console.log(response);
                if (response.data.love == false) {
                    response.data.love = "2";
                } else {
                    response.data.love = "1";
                }
                if (response.data.comments) {
                    setItems(response.data.comments);
                }
            } else {
                $scope.loader = false;
            }
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
            $ionicPopup.hide();
            $scope.$broadcast('scroll.refreshComplete');
        });
    }
    LoaderService.show();
    get_advertisement(ad_id);
    $scope.doRefresh = function () {
        $scope.get_comments = [];
        get_advertisement(ad_id);
    }
    $scope.submitmessage = function () {
        $scope.comments.user_id = $scope.user_detail.id;
        $scope.comments.template = "advertisement";
//             $scope.comments.rating = "advertisement";
        console.log($scope.comments);
        $scope.comments.template_id = ad_id;
        LoaderService.show();
        SubmitcommentService.register($scope.comments).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                $scope.comments.comment = "";

                $scope.get_comments.push(response.data);
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                $scope.success = true;
            } else {
                LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Error while posting your comment!'
                });
            }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());


        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });

        });
    }
    // modal code
     // modal
    $ionicModal.fromTemplateUrl('templates/comment_modal.html', {
      scope: $scope,
      animation: 'slide-in-top'
   }).then(function(modal) {
      $scope.modal = modal;
   });
    $scope.getAllComments = {};
   $scope.openModal = function() {
      LoaderService.show();
      RestaurantService.getComments(ad_id,"advertisement").success(function (response) {
          LoaderService.hide();
          $scope.getAllComments = response.data;
      }).error(function(response){
          LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });
      });
      $scope.modal.show();
   };
	
   $scope.closeModal = function() {
      $scope.modal.hide();
   };
	
   //Cleanup the modal when we're done with it!
   $scope.$on('$destroy', function() {
      $scope.modal.remove();
   });
	
   // Execute action on hide modal
   $scope.$on('modal.hidden', function() {
      // Execute action
   });
	
   // Execute action on remove modal
   $scope.$on('modal.removed', function() {
      // Execute action
   });
    $scope.add_love = function (id) {
        if ($scope.advertisement.love == "2") {
            $scope.advertisement.love = "1";

        } else if ($scope.advertisement.love == "1") {
            $scope.advertisement.love = "2";
        }

        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;

        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            console.log(response);
            if (response.status == 1) {

            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
   







}).controller('HappyhourCtrl', function ($location, $timeout, $q, $ionicScrollDelegate,CountClickService, $stateParams, $scope, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService) {
//    if(user_detail == null){
//         
//    } else {
//        $location.path('tab/index');
//    }

    var check_url = $location.url().split('/');
    switch (check_url[2]) {
        case 'dash-happy-hour-listing':
            $scope.tab_suffix = "dash-";
            break;
        case 'fav-happy-hour-listing':
            $scope.tab_suffix = "fav-";
            break;
        default:
            $scope.tab_suffix = '';
            break;
    }
    if ($stateParams.cityID !== undefined) {
        var cityID = $stateParams.cityID;
        var cities = JSON.parse(localStorage.getItem('cities'));
        angular.forEach(cities, function (value, key) {
            if (value['id'] == parseInt(cityID)) {
                $scope.city_name = value.city;
            }
        });
        $scope.cityID = "/" + cityID;
    } else {
        $scope.cityID = '';
    }
    var limit =3;
    var offset = 0;
    $scope.loader = true;
    var isRefreshing = false;
    var dataFetcher = null;
    
    
    
    $scope.advertisements = [];
//    function setItems(items) {
//        angular.forEach(items, function (task, index) {
//            $scope.advertisements.push(task)
//        });
//    }
    
    
    // new code
    $scope.hasMore = true;
  
  /*
    isRefreshing flag.
    When set to true, on data arrive
    it first empties the list 
    then appends new data to the list.
  */
  var isRefreshing = false;
  
  /* 
    introduce a custom dataFetcher instance
    so that the old fetch process can be aborted
    when the user refreshes the page.
  */
  var dataFetcher=null;
    
    function fetchData(offset, limit) {
    var advertisements = [];
    //isAborted flag
    var isAborted = false;
    var deferred = $q.defer();
    //simulate async response
    $timeout(function() {
      if (!isAborted) {
        RestaurantService.get(offset, limit, 1,cityID,"happyhour").success(function (response) {
            $scope.loader = true;
            LoaderService.hide();
            if (response.status == 1) {
                    angular.forEach(response.data, function (task, index) {
                        advertisements.push(task);
                    });
                    LoaderService.hide()
               deferred.resolve(advertisements);
            } else {
                $scope.loader = false;
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
//        
        
      } else {
        //when aborted, reject, and don't append the out-dated new data to the list
        deferred.reject();
      }
    }, 10000);
    
    return {
      promise: deferred.promise,
      abort: function() {    
        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
        isAborted = true;
      }
    };
  }
    
    
    
    
    
    

    function get_advertisement() {
        RestaurantService.get(offset, limit, 1,cityID,"happyhour").success(function (response) {
            console.log(response);
            console.log(offset);
            $scope.loader = true;
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                console.log("false");
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    $scope.focus = function (ad_id, key) {

        if ($scope.advertisements[key]["view"] === false) {
            return;

        }
        $scope.advertisements[key]["view"] = false;
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_detail.id;
        click_detail["type"] = "view";
        CountClickService.add(click_detail).success(function (response) {
        }).error(function (response) {
        });
    }
LoaderService.show();
//    LoaderService.show();
//    LoaderService.show();
//fetchData(offset, limit);
//    get_advertisement(offset, limit); 
$scope.doRefresh = function() {
    //resets the flags and counters.
    $scope.hasMore = true;
    offset = 0;
    isRefreshing = true;
    //aborts previous data fetcher
    if(!!dataFetcher) dataFetcher.abort();
    //triggers loadMore()
    $scope.loadMore();
  }



$scope.loadMore = function() {
    
    //aborts previous data fetcher
    if(!!dataFetcher) dataFetcher.abort();
    
    //fetch new data
    dataFetcher=fetchData(offset, limit);
    
    dataFetcher.promise.then(function(advertisements) {
      if (isRefreshing) {    
        //clear isRefreshing flag
        isRefreshing = false;
        //empty the advertisements (delete old data) before appending new data to the end of the advertisements.
        $scope.advertisements.splice(0);
        //hide the spin
        $scope.$broadcast('scroll.refreshComplete');
      }
      
      //Check whether it has reached the end
      if (advertisements.length < advertisements) $scope.hasMore = false;
      
      //append new data to the advertisements
      $scope.advertisements = $scope.advertisements.concat(advertisements);
      console.log($scope.advertisements);
      //hides the spin
      $scope.$broadcast('scroll.infiniteScrollComplete');
    
      //notify ion-content to resize after inner height has changed.
      //so that it will trigger infinite scroll again if needed.
      $timeout(function(){
        $ionicScrollDelegate.$getByHandle('mainScroll').resize();
      });
    });
    
    //update itemOffset
    offset += limit;
  };

    $scope.add_love = function (id, key) {
        var meta_value;
        if ($scope.advertisements[key]["love"] == false) {
            $scope.advertisements[key]["love"] = true;
            meta_value = 1;
        } else {
            $scope.advertisements[key]["love"] = false;
            meta_value = 0;
        } 
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;

        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
//        data_obj["meta_value"] = meta_value;
        data_obj["meta_key"] = "love_advertisement";
        console.log(data_obj);
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            console.log(response);
            console.log("controller");
            if (response.status == 1) {

            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
})
        .controller('BlogCtrl', function ($scope, $ionicHistory, LoaderService, $ionicHistory, FlashService, $ionicPopup, $state, BlogService) {

            var limit = 3;
            var offset = 0;
            $scope.blogs = [];
            function setItems(items) {
                angular.forEach(items, function (task, index) {
                    $scope.blogs.push(task)
                });
            }
            $scope.loader = true;
            LoaderService.show({
//        template:"Loading..."
            });
            function get_blogs() {
                BlogService.get(offset, limit).success(function (response) {
                    offset = offset + limit;
                   
                    LoaderService.hide();
                    if (response.status == 0) {
                        $scope.loader = false;
                    } else {
                        setItems(response.data)
                        if (offset >= response.count) {
                            $scope.loader = false;
                        }

                        $scope.$broadcast('scroll.infiniteScrollComplete');

                    }
//        localStorage.setItem('cities', JSON.stringify($scope.cities));
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });

            }
            get_blogs();
            $scope.load_blogs = function () {
                get_blogs(limit, offset);
            }
            $scope.$on('$stateChangeSuccess', function () {
                get_blogs(limit, offset);
            });
            $scope.doRefresh = function () {
                offset = 0;
                $scope.blogs = [];
                $scope.loader = true;
                get_blogs(limit, offset);
                $scope.$broadcast('scroll.refreshComplete');
            }



        })
        
        .controller('LoginCtrl', function ($scope, $location, $ionicHistory, LoaderService, $ionicHistory, FlashService, $ionicPopup, $state, LoginService, Auth, FacebookService, $cordovaOauth,$http) {

            if (localStorage.getItem('success') !== null) {
                $scope.success = true;
                localStorage.removeItem('success');

            }
            $scope.BackButton = function () {
//        $ionicHistory.getBackView();
                $ionicHistory.backView();
            }
            // login code
            $scope.data = {};
            $scope.login = function () {
                console.log($scope.data.username);
                if ($scope.data.username === undefined) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Invalid username!'
                    });
                    return;
                }
                if ($scope.data.username == '') {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please enter your username!'
                    });
                    return;
                }
                if ($scope.data.password === undefined) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please enter your password!'
                    });
                    return;
                }
                LoaderService.show();

                LoginService.loginUser($scope.data.username, $scope.data.password).success(function (response) {

                    LoaderService.hide();
                    if (response.status === 1) {
//                console.log(response.data);
                        $ionicHistory.clearCache()
                        Auth.setUser(response.data);
                        window.localStorage.setItem('user_session', JSON.stringify(response.data));
                        user_detail = response.data;
                        var alertPopup = $ionicPopup.alert({
                            title: 'Success',
                            template: 'Successfully loged in!'
                        }).then(function () {
                            $state.go('tab.dashboard');
                        });

                        return response.data;
//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                        // success
                    } else if (response.status == 0) {
                        var alertPopup = $ionicPopup.alert({
                            title: 'Login failed!',
                            template: "Please check your credentials"
                        });
                    } else {
                        var alertPopup = $ionicPopup.alert({
                            title: 'Login failed!',
                            template: 'Something went wrong'
                        });
                    }
//            $state.go('tab.dash');
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
//                .error(function(data) {
//            var alertPopup = $ionicPopup.alert({
//                title: 'Login failed!',
//                template: 'Please check your credentials!'
//            });
//        });
            }
            $scope.successMessage = FlashService.getMessage();
            // facebook login
            
            
            
            $scope.loginFb = function () {
                LoaderService.show();
                $cordovaOauth.facebook("1048311051927168", ["email", "public_profile"]).then(function(result) {
                    console.log(angular.toJson(result, true));
                   
                    $http.get("https://graph.facebook.com/v2.2/me", {params: {access_token: result.access_token, fields: "id,email,first_name,last_name,gender,picture" , format: "json"}}).then(function (result) {

//                         console.log(angular.toJson(result, true));   

                        var fb_object = {};
                            fb_object["name"] = result.data.first_name + " " + result.data.last_name;
                            fb_object["gender"] = result.data.gender;
                            fb_object["fb_id"] = result.data.id;
                            fb_object["email"] = result.data.email;
                            fb_object["image"] = result.data.picture.data.url;
                            FacebookService.register(fb_object).success(function (response) {
                                Auth.setUser(response.data);
                                user_detail = response.data;
                                window.localStorage.setItem('user_session', JSON.stringify(response.data));
                                var alertPopup = $ionicPopup.alert({
                                    title: 'Success',
                                    template: 'Successfully loged in!'
                                }).then(function () {
                                    $state.go('tab.dashboard');
                                });
                                return response.data;

                            }).error(function (response) {
                                LoaderService.hide();
                                var alertPopup = $ionicPopup.alert({
                                    title: 'Error',
                                    template: 'Please check your network connection!'
                                }).then(function (res) {
                                    $ionicHistory.getBackView();
                                });
                            });



                    }, function (error) {
                        alert("There was a problem getting your profile.  Check the logs for details.");
                        LoaderService.hide();
                    });
                   
                    
                    
                    
                    LoaderService.hide();
                    // results
                }, function(error) {
                    // error
                    LoaderService.hide();
                });
                
            };
            
            
            
//            $scope.loginFb = function () {
//                FB.login(function (response) {
//                    if (response.authResponse) {
//                        FB.api('/me', {
//                            fields: ["email", "first_name", "last_name", "gender", "picture"]
//                        }, function (response) {
//                            var fb_object = {};
//                            fb_object["name"] = response.first_name + " " + response.last_name;
//                            fb_object["gender"] = response.gender;
//                            fb_object["fb_id"] = response.id;
//                            fb_object["email"] = response.email;
//                            fb_object["image"] = response.picture.data.url;
//                            FacebookService.register(fb_object).success(function (response) {
//                                Auth.setUser(response.data);
//                                user_detail = response.data;
//                                window.localStorage.setItem('user_session', JSON.stringify(response.data));
//                                var alertPopup = $ionicPopup.alert({
//                                    title: 'Success',
//                                    template: 'Successfully loged in!'
//                                }).then(function () {
//                                    $state.go('tab.dashboard');
//                                });
//                                return response.data;
//
//                            }).error(function (response) {
//                                LoaderService.hide();
//                                var alertPopup = $ionicPopup.alert({
//                                    title: 'Error',
//                                    template: 'Please check your network connection!'
//                                }).then(function (res) {
//                                    $ionicHistory.getBackView();
//                                });
//                            });
//
//
//
//                            console.log('Good to see you ' + response.first_name + " " + response.last_name + '.');
//
//
//                            var token = FB.getAuthResponse();
//                            console.log(token);
//
//                        });
//                    } else {
//                        console.log('User cancelled login or did not fully authorize.');
//                    }
//                });
//            };






        })

        .controller('ChatsCtrl', function ($scope, Chats) {
            // With the new view caching in Ionic, Controllers are only called
            // when they are recreated or on app start, instead of every page change.
            // To listen for when this page is active (for example, to refresh data),
            // listen for the $ionicView.enter event:
            //
            //$scope.$on('$ionicView.enter', function(e) {
            //});

            $scope.chats = Chats.all();
            $scope.remove = function (chat) {
                Chats.remove(chat);
            };
        })

        .controller('ChatDetailCtrl', function ($scope, $stateParams, Chats) {
            $scope.chat = Chats.get($stateParams.chatId);
        })


        .controller('AccountCtrl', function ($scope) {
            $scope.settings = {
                enableFriends: true
            };
        })
        .controller("DashCtrl", function ($location,$timeout,$ionicPopover, $scope, Auth, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, DashboardService, $state, AddloveService,RestaurantService) {
            $scope.user_detail = user_detail;
    $scope.show = false;
                LoaderService.show();
        
            $scope.loader = true
            $scope.data = [];
            function setItems(items) { 
                angular.forEach(items, function (task, index) {
                    $scope.advertisements.push(task)
                });
            }
            // action sheet
            // modal
    $ionicPopover.fromTemplateUrl('templates/popover.html', {
      scope: $scope
   }).then(function(popover) {
      $scope.popover = popover;
   });
   $scope.new_data = {};
   $scope.hide_popup = function(){
      console.log($scope.new_data.searchvalue);
      if($scope.new_data.searchvalue == ''){
          $scope.searchvalue = '';
          $scope.showPopUpData = false;
          $scope.popover.hide();
      }
   }
$scope.showPopUpData = false;
   $scope.openPopover = function($event) {
       LoaderService.show();
      $scope.Popadvertisements = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $scope.Popadvertisements.push(task)
        });
    }
    function get_advertisement() {
        
        var offset = 0;
        var limit = 100;
        RestaurantService.get(offset, limit, 2).success(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
            
            
            
        }).error(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    get_advertisement();
      
      
      
      $scope.popover.show($event);
      
   };

   $scope.closePopover = function() {
      $scope.popover.hide();
   };
   //Cleanup the popover when we're done with it!
   $scope.$on('$destroy', function() {
      $scope.popover.remove();
   });

   // Execute action on hide popover
   $scope.$on('popover.hidden', function() {
      // Execute action
   });

   // Execute action on remove popover
   $scope.$on('popover.removed', function() {
      // Execute action
   });
// popover show search
$scope.Dashadd_love = function (id, key) {
        if ($scope.Popadvertisements[key]["love"] == false) {
            $scope.Popadvertisements[key]["love"] = true;
        } else {
            $scope.Popadvertisements[key]["love"] = false;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;

        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {

            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
            
           
            
            
            
            function get_dashboard_data() {
                DashboardService.get(user_detail.id).success(function (response) {
                    LoaderService.hide();
                    $scope.show = true;
                    console.log(response);
                    $scope.data = response.data;
                    console.log($scope.data);
                }).error(function (response) {
                    LoaderService.hide();
                    
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            $scope.doRefresh = function () {
                $scope.data = {};
                LoaderService.show();
                get_dashboard_data();
                $scope.$broadcast('scroll.refreshComplete');
            }
            LoaderService.show();
            get_dashboard_data();
            $scope.add_love = function (id, key, main_key) {
                
                if ($scope.data[main_key][key]["love"] == false) {
                    $scope.data[main_key][key]["love"] = true;
                } else {
                    $scope.data[main_key][key]["love"] = false;
                }
                var data_obj = {};
                if (localStorage.getItem('user_session') != null) {
//                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                    $scope.user_login = true;

                }
                data_obj["user_id"] = $scope.user_detail.id;
                data_obj["ad_id"] = id;
                data_obj["meta_key"] = "love_advertisement";
                AddloveService.get(data_obj).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {

                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            
            
            
            
            
            $scope.ShowDashboard = true;
            $scope.search = {};
            $scope.showadds = false;
    // fired on search
    $scope.showadd = function(){
                if($scope.search.value == ''){
                   $scope.showadds = false;
                $scope.ShowDashboard = true; 
                } else {
                if($scope.showadds == true){
                    return;
                }
                $scope.showadds = true;
                $scope.ShowDashboard = false;
                LoaderService.show();
            }
            
                 // functions
        $scope.Popadvertisements = [];
        function setItems(items) {
            angular.forEach(items, function (task, index) {
                $scope.Popadvertisements.push(task)
            });
        }
                
               var offset = 0;
        var limit = 100;
        RestaurantService.get(offset, limit, 2).success(function (response) {
                $scope.showPopUpData = true;
                LoaderService.hide();
                if (response.status == 1) {
                    offset = offset + limit;
                    setItems(response.data);
                } else {
                    $scope.loader = false;
                }
                if (offset >= response.count) {
                    $scope.loader = false;
                } else {
                }



            }).error(function (response) {
                $scope.showPopUpData = true;
                LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Please check your network connection!'
                }).then(function () {
    //                       $ionicHistory.getBackView();
                });
                ;
            });
            $scope.showHappyHours = false;
            $scope.showBrunches = true;
            // get happy hours
            $scope.HappyHoursadvertisements = [];
        function setItemsHappy(items) {
            angular.forEach(items, function (task, index) {
                $scope.HappyHoursadvertisements.push(task)
            });
        }
            
            
            RestaurantService.get(offset, limit).success(function (response) {
                $scope.showPopUpData = true;
                LoaderService.hide();
                if (response.status == 1) {
                    offset = offset + limit;
                    setItemsHappy(response.data);
                } else {
                    $scope.loader = false;
                }
                if (offset >= response.count) {
                    $scope.loader = false;
                } else {
                }



            }).error(function (response) {
                $scope.showPopUpData = true;
                LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Please check your network connection!'
                }).then(function () {
    //                       $ionicHistory.getBackView();
                });
                ;
            });
            
            
            }
            
            // happy hour and brunch bottons click event
            $scope.showHappyHoursFunction = function(){
                $scope.showHappyHours = true;
                $scope.showBrunches = false;
            }
            $scope.showBrunchesFunction = function(){
                $scope.showHappyHours = false;
                $scope.showBrunches = true;
            }
            
            
            
            
            

        }).controller('LoaderCtrl', function ($scope, LoaderService) {
    $scope.showLoadingProperTimes = function () {
        LoaderService.show({
            templateUrl: "templates/loading.html"
        });
    };

    $scope.hideLoadingProperTimes = function () {
        //LoaderService.hide();
    };

    $scope.showLoadingProperTimes();
})

        .controller("EdituserCtrl", function ($scope, $timeout,LoaderService, $ionicPopup, $state, $stateParams, $http, $location, RegisterService, FlashService, UserService, CityService, StateService, FileuploadService, GetUserService) {
            $scope.user = {};
    $scope.show = false;
                LoaderService.show();
        $timeout(function () {
                LoaderService.hide();
                $scope.show = true;
            }, 100);
            var user_id = user_detail.id;
            // get user
            GetUserService.get(user_id).success(function (response) {
                $scope.user = response.data;
                console.log($scope.user);
            }).error(function (response) {
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'very Slow network!'
                });
            });
            $scope.FlashService = FlashService;
            $scope.successMessage = FlashService.getMessage();
            $scope.cities = {};
            if (localStorage.getItem('cities') == null) {
                CityService.get().success(function (response) {
                    $scope.cities = response.data;
                    localStorage.setItem('cities', JSON.stringify($scope.cities));
                });
            } else {
                $scope.cities = JSON.parse(localStorage.getItem('cities'));
            }

            $scope.states = {};
            if (localStorage.getItem('states') == null) {
                StateService.get().success(function (response) {
                    $scope.states = response.data;
                    localStorage.setItem('states', JSON.stringify($scope.states));
                });
            } else {
                $scope.states = JSON.parse(localStorage.getItem('states'));
            }

            $scope.success = false;
            $scope.error = false;
            $scope.register = function () {
                LoaderService.show();
                console.log($scope.user);
                var post_user_array = null;
                angular.forEach($scope.user, function (task, index) {
                    if (post_user_array == null) {
                        post_user_array = index + "=" + task;
                    } else {
                        post_user_array = post_user_array + '&' + index + "=" + task;
                    }
                });
                console.log(post_user_array);
                RegisterService.update($scope.user).success(function (response) {
                    if (response) {
                        LoaderService.hide();
                        if (response.status == 1) {
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
                            var alertPopup = $ionicPopup.alert({
                                title: 'Success',
                                template: 'Successfully Updated!'
                            }).then(function () {
                                $state.go('tab.edituser');
                            });
//                            $location.path("/login"); 
                            $scope.success = true;
                        } else {
//                            $scope.error = true;
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    } else {

                    }

                });
                
            }
            
            
            $scope.interests = {};
            if (localStorage.getItem('interests') == null) {
                 UserinfoService.get(1).success(function (response) {
                    $scope.interests = response.data;
                    localStorage.setItem('interests', JSON.stringify($scope.interests));
                });
            } else {
                $scope.interests = JSON.parse(localStorage.getItem('interests'));
            }
            //
            $scope.occupations = {};
            if (localStorage.getItem('occupations') == null) {
                 UserinfoService.get(2).success(function (response) {
                    $scope.occupations = response.data;
                    localStorage.setItem('occupations', JSON.stringify($scope.occupations));
                });
            } else {
                $scope.occupations = JSON.parse(localStorage.getItem('occupations'));
            }
             $scope.educations = {};
            if (localStorage.getItem('educations') == null) {
                 UserinfoService.get(3).success(function (response) {
                    $scope.educations = response.data;
                    localStorage.setItem('educations', JSON.stringify($scope.educations));
                });
            } else {
                $scope.educations = JSON.parse(localStorage.getItem('educations'));
            }
            
            $scope.uploadResult = [];
            $scope.onFileSelect = function ($files) {
//             console.log($files);
                FileuploadService.uploadImage($files).success(function (response) {
                    if (response.data.status == 1) {
                        $scope.user.userfile = response.data.data;
                    } else {
                        console.log("error while uploading image");
                    }
                }).error(function (data) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Password',
                        template: 'very Slow network!'
                    });
                    return;
                });
//                     .success(function(response){
//                 console.log(response);
//             });
                //$files: an array of files selected, each file has name, size, and type.

            };
        })
        .controller("RegisterCtrl", function ($scope,$timeout, LoaderService, $ionicPopup, $state, $stateParams, $http, $location, RegisterService, FlashService, UserService, CityService, StateService, FileuploadService,UserinfoService) {

        $scope.show = false;
                LoaderService.show();
        $timeout(function () {
                LoaderService.hide();
                $scope.show = true;
            }, 100);
            $scope.user = {};
            $scope.FlashService = FlashService;
            $scope.successMessage = FlashService.getMessage();
            $scope.cities = {};
            if (localStorage.getItem('cities') == null) {
                CityService.get().success(function (response) {
                    $scope.cities = response.data;
                    localStorage.setItem('cities', JSON.stringify($scope.cities));
                });
            } else {
                $scope.cities = JSON.parse(localStorage.getItem('cities'));
            }

            $scope.states = {};
            if (localStorage.getItem('states') == null) {
                StateService.get().success(function (response) {
                    $scope.states = response.data;
                    localStorage.setItem('states', JSON.stringify($scope.states));
                });
            } else {
                $scope.states = JSON.parse(localStorage.getItem('states'));
            }
            $scope.interests = {};
            if (localStorage.getItem('interests') == null) {
                 UserinfoService.get(1).success(function (response) {
                    $scope.interests = response.data;
                    localStorage.setItem('interests', JSON.stringify($scope.interests));
                });
            } else {
                $scope.interests = JSON.parse(localStorage.getItem('interests'));
            }
            //
            $scope.occupations = {};
            if (localStorage.getItem('occupations') == null) {
                 UserinfoService.get(2).success(function (response) {
                    $scope.occupations = response.data;
                    localStorage.setItem('occupations', JSON.stringify($scope.occupations));
                });
            } else {
                $scope.occupations = JSON.parse(localStorage.getItem('occupations'));
            }
             $scope.educations = {};
            if (localStorage.getItem('educations') == null) {
                 UserinfoService.get(3).success(function (response) {
                    $scope.educations = response.data;
                    localStorage.setItem('educations', JSON.stringify($scope.educations));
                });
            } else {
                $scope.educations = JSON.parse(localStorage.getItem('educations'));
            }
           
            $scope.success = false;
            $scope.error = false;
            $scope.register = function () {
                console.log($scope.user);

                LoaderService.show();
                RegisterService.register($scope.user).success(function (response) {
//                    $scope.response = response;
                    console.log(response);
                    if (response) {
                        LoaderService.hide();
                        if (response.status == 1) {
//                            $scope.user = {};
                            var alertPopup = $ionicPopup.alert({
                                title: 'Success',
                                template: 'Successfully Registered!'
                            }).then(function () {
                                $state.go('login');
                            });
//                            localStorage.setItem('success',"true");
//                            $location.path("/login");
//                            $scope.success = true;
                        } else {
//                            $scope.error = true;
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    } else {

                    }

                }).error(function(response){
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                });
            }
            $scope.uploadResult = [];
            $scope.onFileSelect = function ($files) {
//             console.log($files);
                FileuploadService.uploadImage($files).success(function (response) {
                    if (response.data.status == 1) {
                        $scope.user.userfile = response.data.data;
                    } else {
                        console.log("error while uploading image");
                    }
                }).error(function (data) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Password',
                        template: 'very Slow network!'
                    });
                    return;
                });
//                     .success(function(response){
//                 console.log(response);
//             });
                //$files: an array of files selected, each file has name, size, and type.

            };
            LoaderService.hide();
        })
.controller('TestingCtrl', function($scope, $timeout, $q, $ionicScrollDelegate) {
  /*
    list of items, used by ng-repeat
  */
  $scope.list = [];

  var itemOffset = 0,
    itemsPerPage = 5;

  /*
    used by ng-if on ion-infinite-scroll
  */
  $scope.hasMore = true;
  
  /*
    isRefreshing flag.
    When set to true, on data arrive
    it first empties the list 
    then appends new data to the list.
  */
  var isRefreshing = false;
  
  /* 
    introduce a custom dataFetcher instance
    so that the old fetch process can be aborted
    when the user refreshes the page.
  */
  var dataFetcher=null;
  
  /*
    returns a "dataFetcher" object
    with a promise and an abort() method
    
    when abort() is called, the promise will be rejected.
  */
  function fetchData(itemOffset, itemsPerPage) {
    var list = [];
    //isAborted flag
    var isAborted = false;
    var deferred = $q.defer();
    //simulate async response
    $timeout(function() {
      if (!isAborted) {
        //if not aborted
        
        //assume there are 22 items in all
        for (var i = itemOffset; i < itemOffset + itemsPerPage && i < 22; i++) {
          list.push("Item " + (i + 1) + "/22");
        }
        
        deferred.resolve(list);
      } else {
        //when aborted, reject, and don't append the out-dated new data to the list
        deferred.reject();
      }
    }, 1000);
    
    return {
      promise: deferred.promise,
      abort: function() {    
        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
        isAborted = true;
      }
    };
  }
  fetchData(itemOffset, itemsPerPage);

  $scope.doRefresh = function() {
    //resets the flags and counters.
    $scope.hasMore = true;
    itemOffset = 0;
    isRefreshing = true;
    //aborts previous data fetcher
    if(!!dataFetcher) dataFetcher.abort();
    //triggers loadMore()
    $scope.loadMore();
  }

  $scope.loadMore = function() {
    
    //aborts previous data fetcher
    if(!!dataFetcher) dataFetcher.abort();
    
    //fetch new data
    dataFetcher=fetchData(itemOffset, itemsPerPage);
    console.log(dataFetcher);
    
     dataFetcher.promise.then(function(list) {
        console.log(list);
      if (isRefreshing) {    
        //clear isRefreshing flag
        isRefreshing = false;
        //empty the list (delete old data) before appending new data to the end of the list.
        $scope.list.splice(0);
        //hide the spin
        $scope.$broadcast('scroll.refreshComplete');
      }
      
      //Check whether it has reached the end
      if (list.length < itemsPerPage) $scope.hasMore = false;
      
      //append new data to the list
      $scope.list = $scope.list.concat(list);
      console.log($scope.list);
      //hides the spin
      $scope.$broadcast('scroll.infiniteScrollComplete');
    
      //notify ion-content to resize after inner height has changed.
      //so that it will trigger infinite scroll again if needed.
      $timeout(function(){
        $ionicScrollDelegate.$getByHandle('mainScroll').resize();
      });
    });
    
    //update itemOffset
    itemOffset += itemsPerPage;
  };

})
        // social sharing
        