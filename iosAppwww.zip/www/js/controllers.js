
function get_location(cityname) {
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({'address': cityname + ', us'}, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            var return_obj = {};
            return_obj["lat"] = results[0].geometry.location.lat();
            return_obj["lng"] = results[0].geometry.location.lng();
            return return_obj;
        } else {
            return false;
        }
    });
}
angularmodule = angular.module('starter.controllers', ["angularFileUpload", "ionic.rating"]);
angularmodule.constant('api', 'http://boozyadguru.com/webservices/').run(function ($ionicHistory, $cordovaSocialSharing, $location, $rootScope, $state) {
    user_detail = {};
    if (localStorage.getItem('user_session') != null) {
        user_detail = JSON.parse(localStorage.getItem('user_session'));
    } else {
    }
    // share data
    $rootScope.doShare = function (title, message, image, link) {
        var link = "";
//            $scope.main_url = ""; //put your url here
        if (image) {
//                image = $scope.main_url+image;
        } else {
            image = '';//$scope.main_url+"/uploads/misc/1465787842-x-pligis.png";
        }
        $cordovaSocialSharing
                .share(message, title, image, link) // Share via native share sheet
                .then(function (result) {
                    // Success!
                }, function (err) {
                    // An error occured. Show a message to the user
                });
    };
    $rootScope.myGoBack = function () {
        $ionicHistory.goBack();
    };
    $rootScope.setItemsGlobal = function (items) {
        var get_comments = [];
        angular.forEach(items, function (task, index) {
            get_comments.push(task)
        });
        return get_comments;
    }
})
        .controller("LogoutCtrl", function ($state, Auth) {
        }).controller("IndexCtrl", function ($state, Auth, $scope) {
})
        .controller('SharingCtrl', function ($scope, $cordovaSocialSharing) {
            $scope.doShare = function (title, message, image) {
                var link = "";
                $scope.main_url = ""; //put your url here
                if (image) {
                    image = $scope.main_url + image;
                } else {
                    image = '';//$scope.main_url+"/uploads/misc/1465787842-x-pligis.png";
                }
                $cordovaSocialSharing
                        .share(message, title, image, link) // Share via native share sheet
                        .then(function (result) {
                            // Success!
                        }, function (err) {
                            // An error occured. Show a message to the user
                        });
            };
            $scope.share = function () {
//    window.plugins.socialsharing.shareViaFacebook("hello",'',"http://www.casinobonustips.com/a-kitchen-fitter-turns-millionaire-with-betvictor-casino");
                window.plugins.socialsharing.shareViaWhatsApp("hello", null, "http://iamboozin.com/index.php/2016/08/07/nyc-wine-bar-find-wine-5-less/");
//    $cordovaSocialSharing.share('This is my message', 'Subject string', null, 'http://www.casinobonustips.com/a-kitchen-fitter-turns-millionaire-with-betvictor-casino');
            }
// Share via email. Can be used for feedback
            $scope.sendFeedback = function () {
//    $cordovaSocialSharing
//            .shareViaEmail('Some message', 'Some Subject', 'to_address@gmail.com');
//    $cordovaSocialSharing
//            .shareViaEmail('Some message', 'Some Subject', 'to_address@gmail.com');
            }
            $scope.shareAnywhere = function () {
                $cordovaSocialSharing.share("This is your message", "This is your subject", "www/imagefile.png", "http://blog.nraboy.com");
            };
            $scope.shareByWhatsApp = function () {
                $cordovaSocialSharing
                        .shareViaWhatsApp('sharedMsg', "", '')
                        .then(function (result) {
                        }, function (err) {
                            // An error occurred. Show a message to the user
                            alert("error : " + err);
                        });
            }
// Share via SMS. Access multiple numbers in a string like: '0612345678,0687654321'
            $scope.sendSMS = function (message, number) {
                $cordovaSocialSharing.shareViaSMS(message, number);
            }
        })
        .controller("FavouritesdetailCtrl", function ($scope, $timeout, $q, $ionicScrollDelegate, $location, $ionicHistory, $stateParams, LoaderService, $ionicPopup, $state, RestaurantService, AddloveService) {
            var limit = 5;
            var offset = 0;
            var type = 1;
            var check_url = $location.url().split('/');
            switch (check_url[2]) {
                case 'dash-favourites-detail':
                    $scope.tab_suffix = "dash-";
                    break;
                case 'fav-favourites-detail':
                    $scope.tab_suffix = "fav-";
                    break;
                case 'fav-favourites-detail-brunches':
                    type = 2;
                    break;
                default:
                    $scope.tab_suffix = '';
                    break;
            }
            if ($stateParams.cityID !== undefined) {
                var cityID = $stateParams.cityID;
                var cities = JSON.parse(localStorage.getItem('cities'));
                angular.forEach(cities, function (value, key) {
                    if (value['id'] == parseInt(cityID)) {
                        $scope.city_name = value.city;
                    }
                });
                $scope.cityID = "/" + cityID;
            } else {
                $scope.cityID = '';
            }
            $scope.loader = false;
            $scope.advertisements = [];
            // new code
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.advertisements = [];
            $scope.hasMore = true;
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.showdata = false;
            function fetchData(offset, limit) {
                var advertisements = [];
                //isAborted flag
                var isAborted = false;
                var deferred = $q.defer();
                //simulate async response
                $timeout(function () {
                    if (!isAborted) {
                        RestaurantService.get(offset, limit, type, cityID).success(function (response) {
                            $scope.total_records = response.count;
                            LoaderService.hide();
                            if (response.status == 1) {
                                angular.forEach(response.data, function (task, index) {
                                    advertisements.push(task);
                                });
                            } else {
                                $scope.loader = false;
                                $scope.hasMore = false;
                            }
                            deferred.resolve(advertisements);
                        }).error(function (response) {
                            LoaderService.hide();
                            var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Please check your network connection!'
                            }).then(function () {
//                       $ionicHistory.getBackView();
                            });
                            ;
                        });
                    } else {
                        //when aborted, reject, and don't append the out-dated new data to the list
                        deferred.reject();
                    }
                }, 6000);
                return {
                    promise: deferred.promise,
                    abort: function () {
                        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                        isAborted = true;
                    }
                };
            }
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
            $scope.loadMore = function () {
//aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
//fetch new data
                dataFetcher = fetchData(offset, limit);
                dataFetcher.promise.then(function (advertisements) {
                    if (isRefreshing) {
                        //clear isRefreshing flag
                        isRefreshing = false;
                        //empty the advertisements (delete old data) before appending new data to the end of the advertisements.
                        $scope.advertisements.splice(0);
                        //hide the spin
                        $scope.$broadcast('scroll.refreshComplete');
                    }
//Check whether it has reached the end
                    if ($scope.total_records < offset || $scope.total_records == offset)
                        $scope.hasMore = false;
//append new data to the advertisements
                    $scope.advertisements = $scope.advertisements.concat(advertisements);
//hides the spin
                    $scope.$broadcast('scroll.infiniteScrollComplete');
//notify ion-content to resize after inner height has changed.
//so that it will trigger infinite scroll again if needed.
                    $timeout(function () {
// $ionicScrollDelegate.$getByHandle('mainScroll').resize();
                    });
                });
//update itemOffset
                offset += limit;
            };
            
//            get_advertisement(offset, limit);
            $scope.add_love = function (id, key) {
                if ($scope.advertisements[key]["love"] == false) {
                    $scope.advertisements[key]["love"] = true;
                } else {
                    $scope.advertisements[key]["love"] = false;
                }
                var data_obj = {};
                if (localStorage.getItem('user_session') != null) {
                    $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                    $scope.user_login = true;
                }
                data_obj["user_id"] = $scope.user_detail.id;
                data_obj["ad_id"] = id;
                data_obj["meta_key"] = "love_advertisement";
                AddloveService.get(data_obj).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
        })
        .controller('FavouritesCtrl', function (LoaderService, $timeout, $q, $ionicScrollDelegate, $scope, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, FavouriteService) {
            var limit = 5;
            $scope.loader = false;
            var offset = 0;
            $scope.favouries = [];
            function setItems(items) {
                var return_data = [];
                angular.forEach(items, function (task, index) {
                    $scope.favouries.push(task)
                });
            }
            // new code
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.advertisements = [];
            // new code
            $scope.hasMore = true;
            /*
             isRefreshing flag.
             When set to true, on data arrive
             it first empties the list 
             then appends new data to the list.
             */
            var isRefreshing = false;
            /* 
             introduce a custom dataFetcher instance
             so that the old fetch process can be aborted
             when the user refreshes the page.
             */
            var dataFetcher = null;
            $scope.showdata = false;
            function fetchData(offset, limit) {
                var favouries = [];
                //isAborted flag
                var isAborted = false;
                var deferred = $q.defer();
                //simulate async response
                $timeout(function () {
                    if (!isAborted) {
                        FavouriteService.get(user_detail.id, offset, limit).success(function (response) {
                            $scope.total_records = response.count;
                            LoaderService.hide();
                            $scope.showdata = true;
                            if (response.status == 1) {
                                angular.forEach(response.data, function (task, index) {
                                    favouries.push(task);
                                });
                                LoaderService.hide()
                                deferred.resolve(favouries);
                            } else {
                                $scope.hasMore = false;
                            }
                        }).error(function () {
                            LoaderService.hide();
                            var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Please check your network connection!'
                            }).then(function (res) {
                                $ionicHistory.getBackView();
                            });
                        });
//        
                    } else {
                        //when aborted, reject, and don't append the out-dated new data to the list
                        deferred.reject();
                    }
                }, 6000);
                return {
                    promise: deferred.promise,
                    abort: function () {
                        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                        isAborted = true;
                    }
                };
            }

//            function favourites() {
////        user_detail.id= 1;
//                $scope.loader = false;
//                FavouriteService.get(user_detail.id, offset, limit).success(function (response) {
//                    LoaderService.hide();
//                    if (response.status == 1) {
//                        offset = offset + limit;
//                        setItems(response.data);
//                    }
//                    $scope.loader = true;
//                    if (offset >= response.count) {
//                        $scope.loader = false;
//                    }
//                    $scope.$broadcast('scroll.refreshComplete');
//                }).error(function () {
//                    LoaderService.hide();
//                    var alertPopup = $ionicPopup.alert({
//                        title: 'Error',
//                        template: 'Please check your network connection!'
//                    }).then(function (res) {
//                        $ionicHistory.getBackView();
//                    });
//                });
//            }
//            $scope.loadMore = function () {
////        offset  = offset + limit;
//                favourites();
//            }
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
            $scope.loadMore = function () {
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //fetch new data
                dataFetcher = fetchData(offset, limit);
                dataFetcher.promise.then(function (favouries) {
                    if (isRefreshing) {
                        //clear isRefreshing flag
                        isRefreshing = false;
                        //empty the favouries (delete old data) before appending new data to the end of the favouries.
                        $scope.favouries.splice(0);
                        //hide the spin
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                    //Check whether it has reached the end
                    if ($scope.total_records < offset || $scope.total_records == offset)
                        $scope.hasMore = false;
                    //append new data to the favouries
                    $scope.favouries = $scope.favouries.concat(favouries);
                    //hides the spin
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    //notify ion-content to resize after inner height has changed.
                    //so that it will trigger infinite scroll again if needed.
                    $timeout(function () {
//        $ionicScrollDelegate.$getByHandle('mainScroll').resize();
                    });
                });
                //update itemOffset
                offset += limit;
            };
//            LoaderService.show();
//        LoaderService.hide();
//            favourites();
        })
        .controller('StatelistingCtrl', function (LoaderService, $timeout, CountClickService, $q, $ionicScrollDelegate, $scope, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, StateListingService) {
            var limit = 6;
            var offset = 0;
            $scope.loader = false;
            $scope.favouries = [];
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.advertisements = [];
            // new code
            $scope.hasMore = true;
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.showdata = false;
            function fetchData(offset, limit) {
                var favouries = [];
                //isAborted flag
                var isAborted = false;
                var deferred = $q.defer();
                //simulate async response
                $timeout(function () {
                    if (!isAborted) {
                        StateListingService.get(offset, limit).success(function (response) {
                            $scope.total_records = response.count;
                            LoaderService.hide();
                            $scope.showdata = true;
                            angular.forEach(response.data, function (task, index) {
                                favouries.push(task);
                            });
                            LoaderService.hide()
                            deferred.resolve(favouries);
//                    $scope.$broadcast('scroll.refreshComplete');
                        }).error(function () {
                            LoaderService.hide();
                            var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Please check your network connection!'
                            }).then(function (res) {
                                $ionicHistory.getBackView();
                            });
                        });
                    } else {
                        //when aborted, reject, and don't append the out-dated new data to the list
                        deferred.reject();
                    }
                }, 6000);
                return {
                    promise: deferred.promise,
                    abort: function () {
                        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                        isAborted = true;
                    }
                };
            }
            $scope.focus = function (ad_id, key) {
                if ($scope.advertisements[key]["view"] === false) {
                    return;
                }
                $scope.advertisements[key]["view"] = false;
                var click_detail = {};
                click_detail["ad_id"] = ad_id;
                click_detail["user_id"] = user_detail.id;
                click_detail["type"] = "view";
                CountClickService.add(click_detail).success(function (response) {
                }).error(function (response) {
                });
            }
//            LoaderService.show();
           
            $scope.loadMore = function () {
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //fetch new data
                dataFetcher = fetchData(offset, limit);
                dataFetcher.promise.then(function (advertisements) {
                    if (isRefreshing) {
                        //clear isRefreshing flag
                        isRefreshing = false;
                        //empty the advertisements (delete old data) before appending new data to the end of the advertisements.
                        $scope.advertisements.splice(0);
                        //hide the spin
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                    //Check whether it has reached the end
                    if ($scope.total_records < offset || $scope.total_records == offset)
                        $scope.hasMore = false;
                    //append new data to the advertisements
                    $scope.favouries = $scope.favouries.concat(advertisements);
                    //hides the spin
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    //notify ion-content to resize after inner height has changed.
                    //so that it will trigger infinite scroll again if needed.
                    $timeout(function () {
//        $ionicScrollDelegate.$getByHandle('mainScroll').resize();
                    });
                });
                //update itemOffset
                offset += limit;
            };
//            LoaderService.show();
//        LoaderService.hide();
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
//            get_listing();
        })
        .controller('StateTownlistingCtrl', function (LoaderService, $stateParams, $scope, $timeout, $q, $ionicScrollDelegate, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, StateTownListingService) {
            // new code
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.favouries = [];
            $scope.hasMore = true;
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.showdata = false;
            var stateID = $stateParams.stateID;
            var limit = 6;
            var offset = 0;
            $scope.loader = false;
            function fetchData(offset, limit) {
                var favouries = [];
                //isAborted flag
                var isAborted = false;
                var deferred = $q.defer();
                //simulate async response
                $timeout(function () {
                    if (!isAborted) {
                        StateTownListingService.get(stateID, offset, limit).success(function (response) {
                            $scope.total_records = response.count;
                            LoaderService.hide();
                            if (response.status == 1) {
                                angular.forEach(response.data, function (task, index) {
                                    favouries.push(task);
                                });
                            } else {
                                $scope.loader = false;
                            }
                            deferred.resolve(favouries);
                        }).error(function (response) {
                            LoaderService.hide();
                            $scope.showdata = true;
                            var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Please check your network connection!'
                            }).then(function () {
//                       $ionicHistory.getBackView();
                            });
                            ;
                        });
                    } else {
                        //when aborted, reject, and don't append the out-dated new data to the list
                        deferred.reject();
                    }
                }, 6000);
                return {
                    promise: deferred.promise,
                    abort: function () {
                        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                        isAborted = true;
                    }
                };
            }
            $scope.loadMore = function () {
//aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
//fetch new data
                dataFetcher = fetchData(offset, limit);
                dataFetcher.promise.then(function (favouries) {
                    if (isRefreshing) {
                        //clear isRefreshing flag
                        isRefreshing = false;
                        //empty the favouries (delete old data) before appending new data to the end of the favouries.
                        $scope.favouries.splice(0);
                        //hide the spin
                        $scope.$broadcast('scroll.refreshComplete');
                    }
//Check whether it has reached the end
                    if ($scope.total_records < offset || $scope.total_records == offset)
                        $scope.hasMore = false;
//append new data to the favouries
                    $scope.favouries = $scope.favouries.concat(favouries);
//hides the spin
                    $scope.$broadcast('scroll.infiniteScrollComplete');
//notify ion-content to resize after inner height has changed.
//so that it will trigger infinite scroll again if needed.
                    $timeout(function () {
// $ionicScrollDelegate.$getByHandle('mainScroll').resize();
                    });
                });
//update itemOffset
                offset += limit;
            };
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
//            $scope.favouries = [];
            function setItems(items) {
                var return_data = [];
                angular.forEach(items, function (task, index) {
                    $scope.favouries.push(task)
                });
            }
            $scope.showdata = false;
           
//            $scope.loadMore = function () {
////        offset  = offset + limit;
//                get_listing();
//            }
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
//            LoaderService.show();
//        LoaderService.hide();
//            get_listing();
        })
        .controller('StateCitylistingCtrl', function (LoaderService, $stateParams, $scope, $timeout, $q, $ionicScrollDelegate, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, StateCityListingService) {
            // new code
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.favouries = [];
            $scope.hasMore = true;
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.showdata = false;
            var stateID = $stateParams.stateID;
            var limit = 9;
            var offset = 0;
            $scope.loader = false;
            function fetchData(offset, limit) {
                var favouries = [];
                //isAborted flag
                var isAborted = false;
                var deferred = $q.defer();
                //simulate async response
                $timeout(function () {
                    if (!isAborted) {
                        StateCityListingService.get(stateID, offset, limit).success(function (response) {
                            $scope.total_records = response.count;
                            LoaderService.hide();
                            console.log(response);
                            if (response.status == 1) {
                                angular.forEach(response.data, function (task, index) {
                                    favouries.push(task);
                                });
                            } else {
                                $scope.loader = false;
                            }
                            deferred.resolve(favouries);
                        }).error(function (response) {
                            LoaderService.hide();
                            $scope.showdata = true;
                            var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Please check your network connection!'
                            }).then(function () {
//                       $ionicHistory.getBackView();
                            });
                            ;
                        });
                    } else {
                        //when aborted, reject, and don't append the out-dated new data to the list
                        deferred.reject();
                    }
                }, 6000);
                return {
                    promise: deferred.promise,
                    abort: function () {
                        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                        isAborted = true;
                    }
                };
            }
            $scope.loadMore = function () {
//aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
//fetch new data
                dataFetcher = fetchData(offset, limit);
                dataFetcher.promise.then(function (favouries) {
                    if (isRefreshing) {
                        //clear isRefreshing flag
                        isRefreshing = false;
                        //empty the favouries (delete old data) before appending new data to the end of the favouries.
                        $scope.favouries.splice(0);
                        //hide the spin
                        $scope.$broadcast('scroll.refreshComplete');
                    }
//Check whether it has reached the end
                    if ($scope.total_records < offset || $scope.total_records == offset)
                        $scope.hasMore = false;
//append new data to the favouries
                    $scope.favouries = $scope.favouries.concat(favouries);
//hides the spin
                    $scope.$broadcast('scroll.infiniteScrollComplete');
//notify ion-content to resize after inner height has changed.
//so that it will trigger infinite scroll again if needed.
                    $timeout(function () {
// $ionicScrollDelegate.$getByHandle('mainScroll').resize();
                    });
                });
//update itemOffset
                offset += limit;
            };
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
//            $scope.favouries = [];
            function setItems(items) {
                var return_data = [];
                angular.forEach(items, function (task, index) {
                    $scope.favouries.push(task)
                });
            }
            $scope.showdata = false;
//            function get_listing() {
////        user_detail.id= 1;
//                $scope.loader = false;
//                StateCityListingService.get(stateID, offset, limit).success(function (response) {
//                    $scope.showdata = true;
//                    LoaderService.hide();
//                    if (response.status == 1) {
//                        offset = offset + limit;
//                        setItems(response.data);
//                    }
//                    $scope.loader = true;
//                    if (offset >= response.count) {
//                        $scope.loader = false;
//                    }
////                    $scope.$broadcast('scroll.refreshComplete');
//                }).error(function () {
//                    LoaderService.hide();
//                    var alertPopup = $ionicPopup.alert({
//                        title: 'Error',
//                        template: 'Please check your network connection!'
//                    }).then(function (res) {
//                        $ionicHistory.getBackView();
//                    });
//                });
//            }
//            $scope.loadMore = function () {
////        offset  = offset + limit;
//                get_listing();
//            }
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
//            LoaderService.show();
//        LoaderService.hide();
//            get_listing();
        })
        .controller("BlogdetailCtrl", function ($scope, $rootScope, $cordovaSocialSharing, LikeService, $ionicHistory, $ionicModal, LoaderService, $location, $ionicHistory, FlashService, $ionicPopup, $state, $stateParams, BlogService, SubmitcommentService, GetCommentsService) {
            $scope.loader = true;
            $scope.user_login = false;
            $scope.comments = {};
            $scope.comments.rating = 3;
            $scope.commentmax = 5;
            $scope.user_detail = {};
            if (localStorage.getItem('user_session') != null) {
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
            }
            var blogId = $stateParams.blogId;
            var key = $stateParams.key;
            LoaderService.show({
//        template:"Loading..."
            });
            $scope.get_comments = [];
            function setItems(items) {
                angular.forEach(items, function (task, index) {
                    $scope.get_comments.push(task)
                });
            }
            $scope.blog = {};
            function get_blogs() {
                BlogService.getsingleBlog(blogId).success(function (response) {
                    console.log(response);
                    LoaderService.hide();
                    if (response.status == 0) {
                    } else {
                        $scope.blog = response.data;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            $scope.counts = 0;
            function get_comments() {
                GetCommentsService.get('blogs', blogId, 3).success(function (response) {
                    console.log(response);
                    LoaderService.hide();
                    if (response.status == 0) {
                    } else {
                        $scope.counts = response.count;
//                        $scope.blog = response.data;
                        setItems(response.data);
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            // 
            $scope.submitLike = function (post_id) {
                LikeService.post(user_detail.id, post_id, "blogs").success(function (response) {
                    console.log(response);
                    LoaderService.hide();
                    if (response.status == 0) {
                    } else {
                        $scope.counts = response.count;
//                        $scope.blog = response.data;
                        setItems(response.data);
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            // comments popup
            // modal
            $ionicModal.fromTemplateUrl('templates/comment_modal.html', {
                scope: $scope,
                animation: 'slide-in-top'
            }).then(function (modal) {
                $scope.modal = modal;
            });
            $scope.getAllComments = [];
            $scope.openModal = function () {
                LoaderService.show();
                GetCommentsService.get('blogs', blogId).success(function (response) {
                    LoaderService.hide();
                    console.log(response.data);
                    $scope.getAllComments = response.data;
//          $scope.counts = response.data
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
                    });
                });
                $scope.modal.show();
            };
            $scope.closeModal = function () {
                $scope.modal.hide();
            };
            //Cleanup the modal when we're done with it!
            $scope.$on('$destroy', function () {
                $scope.modal.remove();
            });
            // Execute action on hide modal
            $scope.$on('modal.hidden', function () {
                // Execute action
            });
            // Execute action on remove modal
            $scope.$on('modal.removed', function () {
                // Execute action
            });
            get_comments();
            get_blogs();
            $scope.doRefresh = function () {
                $scope.get_comments = [];
                get_comments();
                get_blogs();
            }
            $scope.submitmessage = function () {
                $scope.comments.user_id = $scope.user_detail.id;
                $scope.comments.template = "blogs";
                $scope.comments.template_id = blogId;
                LoaderService.show();
                SubmitcommentService.register($scope.comments).success(function (response) {
                    LoaderService.hide();
                    console.log(response);
                    $rootScope.blogs[key]['total_comments'] = parseInt($rootScope.blogs[key]['total_comments']) + 1;
                    if (response.status == 1) {
                        $scope.comments.comment = "";
                        $scope.get_comments.push(response.data);
                        $scope.counts = $scope.counts + 1;
                        $scope.getAllComments.push(response.data);
                        $scope.success = true;
                    } else {
                        LoaderService.hide();
                        var alertPopup = $ionicPopup.alert({
                            title: 'Error',
                            template: 'Error while posting your comment!'
                        });
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
                    });
                });
            }
            // sharing
            $scope.doShare = function () {
                // var link = "";
                var title = $scope.blog.title;
                var message = $scope.blog.content;
                var image = $scope.blog.image;
                var link = $scope.blog.post_url;
                // alert(link);
                // if (image) {
                //     image = $scope.main_url+image;
                // } else {
                //     image = '';//$scope.main_url+"/uploads/misc/1465787842-x-pligis.png";
                // }
                $cordovaSocialSharing
                        .share(null, null, null, link) // Share via native share sheet
                        .then(function (result) {
                            // Success!
                        }, function (err) {
                            alert()
                            // An error occured. Show a message to the user
                        });
            };
        }).controller('BrunchmapCtrl', function ($scope, ionicLoading, $compile, $window, $ionicHistory, LoaderService, $compile) {
    function google_map(cities) {
        var mapOptions = {
            zoom: 4,
            center: new google.maps.LatLng(25, 80),
            mapTypeId: google.maps.MapTypeId.TERRAIN
        }
        $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);
        $scope.markers = [];
        var infoWindow = new google.maps.InfoWindow();
        var createMarker = function (info) {
            var marker = new google.maps.Marker({
                map: $scope.map,
                position: new google.maps.LatLng(info.lat, info.long),
                title: info.city
            });
            marker.content = '<div class="infoWindowContent">' + info.desc + '</div>';
            google.maps.event.addListener(marker, 'click', function () {
                alert("hello");
                infoWindow.setContent('<h2>' + marker.title + '</h2>' + marker.content);
                infoWindow.open($scope.map, marker);
            });
            $scope.markers.push(marker);
        }
        for (i = 0; i < cities.length; i++) {
            createMarker(cities[i]);
        }
        $scope.openInfoWindow = function (e, selectedMarker) {
            e.preventDefault();
            google.maps.event.trigger(selectedMarker, 'click');
        }
    }
//google_map(cities1);
    function initialize() {
        google.maps.event.addDomListener(window, 'load');
        var myLatlng = new google.maps.LatLng(43.07493, -89.381388);
        var mapOptions = {
            center: myLatlng,
            zoom: 16,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"),
                mapOptions);
        //Marker + infowindow + angularjs compiled ng-click
        var contentString = "<div><a ng-click='clickTest()'>Click me!</a></div>";
        var compiled = $compile(contentString)($scope);
        var infowindow = new google.maps.InfoWindow({
            content: compiled[0]
        });
        var marker = new google.maps.Marker({
            //your random marker generation code
        });
        google.maps.event.addListener(marker, 'click', function () {
            infowindow.open(map, marker);
        });
        $scope.map = map;
    }

}).controller('HappyhourmapCtrl', function ($scope, $cordovaGeolocation, RestaurantService, AddloveService, $ionicPopup, LatLongService, $timeout, $ionicHistory, LoaderService, $compile) {
// calculate distance
    function get_distance(lat1, lon1, lat2, lon2, unit) {
        var radlat1 = Math.PI * lat1 / 180
        var radlat2 = Math.PI * lat2 / 180
        var theta = lon1 - lon2
        var radtheta = Math.PI * theta / 180
        var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
        dist = Math.acos(dist)
        dist = dist * 180 / Math.PI
        dist = dist * 60 * 1.1515
        console.log(dist);
        if (unit == "K") {
            dist = dist * 1.609344
        }
        if (unit == "N") {
            dist = dist * 0.8684
        }
        return dist
    }
    LoaderService.show();
    $scope.showdetail = false;
    $scope.advertisement = {};
    function get_advertisement(ad_id) {
        RestaurantService.getsingle(ad_id, user_detail.id).success(function (response) {
            $scope.showdetail = true;
            LoaderService.hide();
            if (response.status == 1) {
                $scope.advertisement = response.data;
                if (response.data.comments) {
//                    setItems(response.data.comments);
                }
            } else {
                $scope.loader = false;
            }
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });
            ;
//            $ionicPopup.hide();
            $scope.$broadcast('scroll.refreshComplete');
        });
    }
//    $ionicHistory.clearCache();
    function google_map(cities, IconColor) {
        var mapOptions = {
            zoom: 6,
            center: new google.maps.LatLng(current_lat, current_long),
            mapTypeId: google.maps.MapTypeId.TERRAIN,
        }
        $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);
        $scope.markers = [];
        var infoWindow = new google.maps.InfoWindow();
        var createMarker = function (info) {
            var marker = new MarkerWithLabel({
                position: new google.maps.LatLng(info.lat, info.lng),
                map: $scope.map,
//    draggable: true,
                raiseOnDrag: true,
                labelClass: "labels", // the CSS class for the label
                labelContent: info.city,
                labelAnchor: new google.maps.Point(15, 20),
                labelInBackground: false,
                icon: IconColor
//    icon: pinSymbol(IconColor)
            });
            marker.content = '<div class="infoWindowContent">  </div>';
            google.maps.event.addListener(marker, 'click', function () {
                LoaderService.show();
                get_advertisement(info.id);
                infoWindow.setContent('<h2 class="my-map-add">' + info.city + '</h2>' + marker.content);
                infoWindow.open($scope.map, marker);
            });
            $scope.markers.push(marker);
        }
        for (i = 0; i < cities.length; i++) {
            var distance = get_distance(cities[i]["lat"], cities[i]["lng"], current_lat, current_long, "K");
//        if(parseInt(distance) < 11){
            createMarker(cities[i]);
//        }
        }
        google.maps.event.addDomListener(window, 'load');
        $timeout(function () {
            var el = document.getElementsByClassName('infoWindowContent');
            angular.element(el).triggerHandler('click');
        }, 100);
    }
    $scope.brunches = function () {

  
        $scope.activemap = "brunches";
        $scope.showdetail = false;
        LatLongService.get(2).success(function (response) {
            LoaderService.hide();
            if (response.status == 0) {
            } else {
                var posOptions = {timeout: 60000, enableHighAccuracy: false};
                $cordovaGeolocation
                        .getCurrentPosition(posOptions)
                        .then(function (position) {
                            current_lat = position.coords.latitude;
                            current_long = position.coords.longitude;
                            google_map(response.data, 'img/brunch.png')
                            console.log(current_lat, current_long);
                        }, function (err) {
                            // error
                        });
//                        if (response.data.comments) {
//                            setItems(response.data.comments);
//                        }
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.$broadcast('scroll.refreshComplete');
            }
//        localStorage.setItem('cities', JSON.stringify($scope.cities));
        }).error(function (data) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function (res) {
                $ionicHistory.getBackView();
            });
            ;
        });
   google_map(cities1,  "#007b8d" );
    }
    $scope.activemap = "happyhour";
    
    $scope.happyHours = function () {
        $scope.activemap = "happyhour";
        $scope.showdetail = false;
        LatLongService.get(1).success(function (response) {
            LoaderService.hide();
            if (response.status == 0) {
            } else {
                var posOptions = {timeout: 60000, enableHighAccuracy: false};
                $cordovaGeolocation
                        .getCurrentPosition(posOptions)
                        .then(function (position) {
                            current_lat = position.coords.latitude;
                            current_long = position.coords.longitude;
                            google_map(response.data, 'img/happy-hour.png');
                        }, function (err) {
                            // error
                        });
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.$broadcast('scroll.refreshComplete');
            }
        }).error(function (data) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function (res) {
                $ionicHistory.getBackView();
            });
            ;
        });
    }
    $scope.happyHours();
    function pinSymbol(color) {
        return {
            path: 'M 0,0 C 0,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z',
//    path: 'M 0,0 C -1,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z',
            fillColor: color,
            fillOpacity: 1,
            strokeColor: '#000',
            strokeWeight: 1,
            scale: 2
        };
    }
// search results
    $scope.Happyadd_love = function (id, key) {
        if ($scope.HappyHoursadvertisements[key]["love"] == false) {
            $scope.HappyHoursadvertisements[key]["love"] = true;
        } else {
            $scope.HappyHoursadvertisements[key]["love"] = false;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    $scope.Brunchadd_love = function (id, key) {
        if ($scope.Popadvertisements[key]["love"] == false) {
            $scope.Popadvertisements[key]["love"] = true;
        } else {
            $scope.Popadvertisements[key]["love"] = false;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    $scope.ShowDashboard = true;
    $scope.search = {};
    $scope.showadds = false;
    $scope.showsearch = false;
    // fired on search
    $scope.showadd = function () {
        if ($scope.search.value == '') {
            $scope.showadds = false;
            $scope.showsearch = false;
            $scope.ShowDashboard = true;
        } else {
            if ($scope.showadds == true) {
                return;
            }
            $scope.showadds = true;
            $scope.ShowDashboard = false;
            LoaderService.show();
        }
        // functions
        $scope.Popadvertisements = [];
        function setItems(items) {
            angular.forEach(items, function (task, index) {
                $scope.Popadvertisements.push(task)
            });
        }
        var offset = 0;
        var limit = 100;
        RestaurantService.get(offset, limit, 2).success(function (response) {
            $scope.showsearch = true;
            $scope.showPopUpData = true;
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
                //                       $ionicHistory.getBackView();
            });
            ;
        });
        $scope.showHappyHours = false;
        $scope.showBrunches = true;
        // get happy hours
        $scope.HappyHoursadvertisements = [];
        function setItemsHappy(items) {
            angular.forEach(items, function (task, index) {
                $scope.HappyHoursadvertisements.push(task)
            });
        }
        RestaurantService.get(offset, limit, 1).success(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                $scope.showsearch = true;
                setItemsHappy(response.data);
            } else {
                $scope.showsearch = true;
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
                //                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    // happy hour and brunch bottons click event
    $scope.showHappyHoursFunction = function () {
        $scope.showHappyHours = true;
        $scope.showBrunches = false;
    }
    $scope.showBrunchesFunction = function () {
        $scope.showHappyHours = false;
        $scope.showBrunches = true;
    }
    $scope.showadd = function () {
        if ($scope.search.value == '') {
            $scope.showadds = false;
            $scope.showsearch = false;
            $scope.ShowDashboard = true;
            if ($scope.activemap == "brunches") {
                $scope.brunches();
            } else {
                $scope.happyHours();
            }
        } else {
            if ($scope.showadds == true) {
                return;
            }
            $scope.showadds = true;
            $scope.ShowDashboard = false;
            LoaderService.show();
        }
        // functions
        $scope.Popadvertisements = [];
        function setItems(items) {
            angular.forEach(items, function (task, index) {
                $scope.Popadvertisements.push(task)
            });
        }
        var offset = 0;
        var limit = 100;
        RestaurantService.get(offset, limit, 2).success(function (response) {
            $scope.showsearch = true;
            $scope.showPopUpData = true;
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
                //                       $ionicHistory.getBackView();
            });
            ;
        });
        $scope.showHappyHours = false;
        $scope.showBrunches = true;
        // get happy hours
        $scope.HappyHoursadvertisements = [];
        function setItemsHappy(items) {
            angular.forEach(items, function (task, index) {
                $scope.HappyHoursadvertisements.push(task)
            });
        }
        RestaurantService.get(offset, limit, 1).success(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                $scope.showsearch = true;
                setItemsHappy(response.data);
            } else {
                $scope.showsearch = true;
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            $scope.showPopUpData = true;
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
                //                       $ionicHistory.getBackView();
            });
            ;
        });
    }
    // current location
    var watchOptions = {
        timeout: 3000,
        enableHighAccuracy: false // may cause errors if true
    };
    var watch = $cordovaGeolocation.watchPosition(watchOptions);
    watch.then(
            null,
            function (err) {
                // error
            },
            function (position) {
                var lat = position.coords.latitude
                var long = position.coords.longitude
            });
    watch.clearWatch();
    // OR
//  $cordovaGeolocation.clearWatch(watch)
//    .then(function(result) {
//      // success
//      }, function (error) {
//      // error
//    });
//console.log();
}).controller('BrunchlstCtrl', function ($scope, $rootScope, $location, $ionicHistory, $stateParams, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService) {
    var limit = 5;
    var offset = 0;
    if ($stateParams.cityId !== undefined) {
        var cityID = $stateParams.cityId;
    } else {
        var cityID = null;
    }
    var check_url = $location.url().split('/');
    switch (check_url[2]) {
        case 'dash-brunch-listing':
            $scope.tab_suffix = "dash-";
            break;
        case 'fav-brunch-listing':
            $scope.tab_suffix = "fav-";
            break;
        default:
            $scope.tab_suffix = '';
            break;
    }
    $scope.showdata = false;
    $rootScope.advertisements = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $rootScope.advertisements.push(task)
        });
    }
    function get_advertisement() {
        RestaurantService.get(offset, limit, 2, cityID).success(function (response) {
            $scope.showdata = true;
            LoaderService.hide();
            $scope.loader = true;
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            $scope.showdata = true;
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
//    LoaderService.show();
    get_advertisement(offset, limit);
    $scope.doRefresh = function () {
        LoaderService.show();
        offset = 0;
        $rootScope.advertisements = [];
        get_advertisement(offset, limit);
        $scope.$broadcast('scroll.refreshComplete');
    }
    $scope.loadMore = function () {
//        offset  = offset + limit;
        get_advertisement(offset, limit);
    }
    $scope.add_love = function (id, key) {
        if ($rootScope.advertisements[key]["love"] == false) {
            $rootScope.advertisements[key]["love"] = true;
        } else {
            $rootScope.advertisements[key]["love"] = false;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
}).controller('imageloader', function ($scope) {
    // don't be scared by the image value, its just datauri
    $scope.items = [
        {id: 1, name: 'Cat 1', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 2, name: 'Cat 2', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 3, name: 'Cat 3', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 4, name: 'Cat 4', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 5, name: 'Cat 5', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 6, name: 'Cat 6', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 7, name: 'Cat 7', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 8, name: 'Cat 8', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'},
        {id: 9, name: 'Cat 9', image: 'http://i.huffpost.com/gen/964776/images/o-CATS-KILL-BILLIONS-facebook.jpg'}
    ];
}).controller('BrunchlstCtrl', function ($scope, $rootScope, $location, $ionicHistory, $stateParams, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService, CountClickService) {
    var limit = 5;
    var offset = 0;
    $scope.loader = true;
    var cityID = $stateParams.cityID;
    if ($stateParams.cityID !== undefined) {
        var cities = JSON.parse(localStorage.getItem('cities'));
        angular.forEach(cities, function (value, key) {
            if (value['id'] == parseInt(cityID)) {
                $scope.city_name = value.city;
            }
        });
        $scope.cityID = "/" + cityID;
    } else {
        $scope.cityID = '';
    }
    var check_url = $location.url().split('/');
    switch (check_url[2]) {
        case 'dash-brunch-listing':
            $scope.tab_suffix = "dash-";
            break;
        case 'fav-brunch-listing':
            $scope.tab_suffix = "fav-";
            break;
        default:
            $scope.tab_suffix = '';
            break;
    }
    $rootScope.advertisements = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $rootScope.advertisements.push(task)
        });
    }
    $scope.focus = function (ad_id, key) {
        if ($rootScope.advertisements[key]["view"] === false) {
            return;
        }
        $rootScope.advertisements[key]["view"] = false;
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_detail.id;
        click_detail["type"] = "view";
        CountClickService.add(click_detail).success(function (response) {
        }).error(function (response) {
        });
    }
    $scope.showdata = false;
    function get_advertisement() {
        RestaurantService.get(offset, limit, 2, cityID, "alldata").success(function (response) {
            $scope.showdata = true;
            console.log(response);
            LoaderService.hide();
            if (response.status == 1) {
                offset = offset + limit;
                setItems(response.data);
            } else {
                $scope.loader = false;
            }
            if (offset >= response.count) {
                $scope.loader = false;
            } else {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
//    LoaderService.show();
    get_advertisement(offset, limit);
    $scope.doRefresh = function () {
        LoaderService.show();
        offset = 0;
        $rootScope.advertisements = [];
        $scope.loader = true;
        get_advertisement(offset, limit);
        $scope.$broadcast('scroll.refreshComplete');
    }
    $scope.loadMore = function () {
//        offset  = offset + limit;
        get_advertisement(offset, limit);
    }
    $scope.add_love = function (id, key) {
        if ($rootScope.advertisements[key]["love"] == false) {
            $rootScope.advertisements[key]["love"] = true;
        } else {
            $rootScope.advertisements[key]["love"] = false;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
}).controller("MapCtrl", function ($scope) {
    google.maps.event.addDomListener(window, "load", function () {
        var myLatLng = new google.maps.LatLng(37.00, -120.4833);
        var mapOptions = {
            center: myLatLng,
            zoom: 18,
            myTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
        $scope.map = map;
    })
}).controller('HappyhourdetailCtrl', function ($scope, $rootScope, CountClickService, $stateParams, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService, SubmitcommentService, $ionicModal) {
// google map
    function pinSymbol(color) {
        return {
            path: 'M 0,0 C 0,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z',
//    path: 'M 0,0 C -1,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z',
            fillColor: color,
            fillOpacity: 1,
            strokeColor: '#000',
            strokeWeight: 1,
            scale: 2
        };
    }
    function google_map(cities, IconColor) {
        var mapOptions = {
            zoom: 4,
            dragging: false,
            center: new google.maps.LatLng(cities[0]["lat"], cities[0]["long"]),
            mapTypeId: google.maps.MapTypeId.TERRAIN,
            scrollwheel: false
        }
        $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);
        $scope.markers = [];
        var infoWindow = new google.maps.InfoWindow();
        var createMarker = function (info) {
            var marker = new MarkerWithLabel({
                position: new google.maps.LatLng(info.lat, info.long),
                map: $scope.map,
                draggable: false,
                raiseOnDrag: false,
                labelClass: "labels", // the CSS class for the label
                labelContent: "<div>" + info.city + "</div>",
                labelAnchor: new google.maps.Point(15, 65),
                labelInBackground: false,
                icon: pinSymbol(IconColor)
            });
            marker.content = '<div class="infoWindowContent"></div>';
            google.maps.event.addListener(marker, 'click', function () {
                infoWindow.setContent('<h2 class="my-map-add">' + marker.title + '</h2>' + marker.content);
                infoWindow.open($scope.map, marker);
            });
            $scope.markers.push(marker);
        }
        for (i = 0; i < cities.length; i++) {
            createMarker(cities[i]);
        }
        $scope.openInfoWindow = function (e, selectedMarker) {
            e.preventDefault();
            google.setOnLoadCallback(selectedMarker);
//        google.maps.event.trigger(selectedMarker, 'click');
        }
    }
// #### end google map
    var ad_id = $stateParams.ad_id;
    if ($stateParams.key != undefined) {
        var ad_key = $stateParams.key;
    }
    $scope.advertisement = {};
    $scope.comments = {};
    if (localStorage.getItem('user_session') != null) {
        $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
        $scope.user_login = true;
    }
//            rating
    $scope.comments.rating = 3;
    $scope.commentmax = 5;
    $scope.get_comments = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $scope.get_comments.push(task)
        });
    }
    function add_click(ad_id, user_id, ad_time_id) {
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_id;
        click_detail["ad_time_id"] = ad_time_id;
        CountClickService.add(click_detail).success(function (response) {
            console.log(response);
            if (response.data.remove_add == true) {
                $rootScope.advertisements.splice(ad_key, 1)
                // delete  $rootScope.advertisements[ad_key];
            }
        }).error(function (response) {
        });
    }
    function get_advertisement(ad_id) {
        RestaurantService.getsingle(ad_id, $scope.user_detail.id).success(function (response) {
            console.dir(response);
            LoaderService.hide();
            if (response.status == 1) {
                add_click(ad_id, response.data.user_id, response.data.ad_time_id);
                $scope.advertisement = response.data;
                if (response.data.comments) {
                    setItems(response.data.comments);
                }
            } else {
                $scope.loader = false;
            }
            // call google map
            if ($scope.advertisement.lat) {
            } else {
                $scope.advertisement['lat'] = 33.58;
                $scope.advertisement['lng'] = 85.85;
            }
            console.log($scope.advertisement);
            var brunch = [
                {
                    city: $scope.advertisement.title,
                    desc: $scope.advertisement.detail,
                    lat: $scope.advertisement.lat,
                    long: $scope.advertisement.lng
                }
            ]
            google_map(brunch, "img/happy-hour.png");
            // end calling google map
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
            $ionicPopup.hide();
            $scope.$broadcast('scroll.refreshComplete');
        });
    }
    LoaderService.show();
    get_advertisement(ad_id);
    // add click
    $scope.doRefresh = function () {
        $scope.get_comments = [];
        get_advertisement(ad_id);
    }
    $scope.getAllComments = [];
    $scope.submitmessage = function () {
        $scope.comments.user_id = $scope.user_detail.id;
        $scope.comments.template = "advertisement";
        $scope.comments.template_id = ad_id;
        LoaderService.show();
        SubmitcommentService.register($scope.comments).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                $scope.comments.comment = "";
                $scope.advertisement.count_commnets = $scope.advertisement.count_commnets + 1;
                $scope.getAllComments.push(response.data);
                $scope.get_comments.push(response.data);
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                $scope.success = true;
            } else {
                LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Error while posting your comment!'
                });
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });
        });
    }
    // modal code
    // modal
    $ionicModal.fromTemplateUrl('templates/comment_modal.html', {
        scope: $scope,
        animation: 'slide-in-top'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.openModal = function () {
        LoaderService.show();
        RestaurantService.getComments(ad_id, "advertisement").success(function (response) {
            LoaderService.hide();
            $scope.getAllComments = response.data;
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });
        });
        $scope.modal.show();
    };
    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hidden', function () {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function () {
        // Execute action
    });
    $scope.add_love = function (id) {
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;
        }
        if ($scope.advertisement.love == false) {
            $scope.advertisement.love = true;
        } else {
            $scope.advertisement.love = false;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
}).controller('BrunchdetailCtrl', function ($scope, $rootScope, CountClickService, $ionicModal, $stateParams, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService, SubmitcommentService) {
//alert("hello");
    $scope.show = false;
    var ad_id = $stateParams.ad_id;
    $scope.advertisement = {};
    $scope.comments = {};
    if (localStorage.getItem('user_session') != null) {
        $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
        $scope.user_login = true;
    }
//            rating
    $scope.comments.rating = 3;
    $scope.commentmax = 5;
    function add_click(ad_id, user_id, ad_time_id) {
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_id;
        click_detail["ad_time_id"] = ad_time_id;
        CountClickService.add(click_detail).success(function (response) {
            console.log(response);
            if (response.data.remove_add == true) {
                $rootScope.advertisements.splice(ad_key, 1)
                // delete  $rootScope.advertisements[ad_key];
            }
        }).error(function (response) {
        });
    }
    // add_click(ad_id, user_detail.id);
    $scope.get_comments = [];
    function setItems(items) {
        angular.forEach(items, function (task, index) {
            $scope.get_comments.push(task)
        });
    }
    // google map
    function pinSymbol(color) {
        return {
            path: 'M 0,0 C 0,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z',
//    path: 'M 0,0 C -1,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z',
            fillColor: color,
            fillOpacity: 1,
            strokeColor: '#000',
            strokeWeight: 1,
            scale: 2
        };
    }
    function google_map(cities, IconColor) {
        var mapOptions = {
            zoom: 4,
            dragging: false,
            center: new google.maps.LatLng(cities[0]["lat"], cities[0]["long"]),
            mapTypeId: google.maps.MapTypeId.TERRAIN,
        }
        $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);
        $scope.markers = [];
        var infoWindow = new google.maps.InfoWindow();
        var createMarker = function (info) {
            var marker = new MarkerWithLabel({
                position: new google.maps.LatLng(info.lat, info.long),
                map: $scope.map,
                draggable: false,
                raiseOnDrag: false,
                labelClass: "labels", // the CSS class for the label
                labelContent: "<div>" + info.city + "</div>",
                labelAnchor: new google.maps.Point(15, 65),
                labelInBackground: false,
                icon: pinSymbol(IconColor)
            });
            marker.content = '<div class="infoWindowContent"></div>';
            google.maps.event.addListener(marker, 'click', function () {
                infoWindow.setContent('<h2 class="my-map-add">' + marker.title + '</h2>' + marker.content);
                infoWindow.open($scope.map, marker);
            });
            $scope.markers.push(marker);
        }
        for (i = 0; i < cities.length; i++) {
            createMarker(cities[i]);
        }
        $scope.openInfoWindow = function (e, selectedMarker) {
            e.preventDefault();
            google.setOnLoadCallback(selectedMarker);
//        google.maps.event.trigger(selectedMarker, 'click');
        }
    }
    function get_advertisement(ad_id) {
        RestaurantService.getsingle(ad_id, user_detail.id).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                $scope.show = true;
                $scope.advertisement = response.data;
                add_click(ad_id, response.data.user_id, response.data.ad_time_id);
                if ($scope.advertisement.lat) {
                } else {
                    $scope.advertisement['lat'] = 33.58;
                    $scope.advertisement['lng'] = 85.85;
                }
                var brunch = [
                    {
                        city: $scope.advertisement.title,
                        desc: $scope.advertisement.detail,
                        lat: $scope.advertisement.lat,
                        long: $scope.advertisement.lng
                    }
                ]
                google_map(brunch, "img/brunch.png");
                if (response.data.love == false) {
                    response.data.love = "2";
                } else {
                    response.data.love = "1";
                }
                if (response.data.comments) {
                    setItems(response.data.comments);
                }
            } else {
                $scope.loader = false;
            }
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
            $ionicPopup.hide();
            $scope.$broadcast('scroll.refreshComplete');
        });
    }
    LoaderService.show();
    get_advertisement(ad_id);
    $scope.doRefresh = function () {
        $scope.get_comments = [];
        get_advertisement(ad_id);
    }
    $scope.submitmessage = function () {
        $scope.comments.user_id = $scope.user_detail.id;
        $scope.comments.template = "advertisement";
        $scope.comments.template_id = ad_id;
        LoaderService.show();
        SubmitcommentService.register($scope.comments).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
                $scope.comments.comment = "";
                $scope.advertisement.count_commnets = $scope.advertisement.count_commnets + 1;
                $scope.getAllComments.push(response.data);
                $scope.get_comments.push(response.data);
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                $scope.success = true;
            } else {
                LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Error while posting your comment!'
                });
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });
        });
    }
    // modal code
    // modal
    $ionicModal.fromTemplateUrl('templates/comment_modal.html', {
        scope: $scope,
        animation: 'slide-in-top'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.getAllComments = [];
    $scope.openModal = function () {
        LoaderService.show();
        RestaurantService.getComments(ad_id, "advertisement").success(function (response) {
            LoaderService.hide();
            $scope.getAllComments = response.data;
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
            });
        });
        $scope.modal.show();
    };
    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hidden', function () {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function () {
        // Execute action
    });
    $scope.add_love = function (id) {
        if ($scope.advertisement.love == "2") {
            $scope.advertisement.love = "1";
        } else if ($scope.advertisement.love == "1") {
            $scope.advertisement.love = "2";
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }

}).controller('HappyhourCtrl', function ($location, $rootScope, $timeout, $q, $ionicScrollDelegate, CountClickService, $stateParams, $scope, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, $state, RestaurantService, AddloveService) {
//    if(user_detail == null){
//         
//    } else {
//        $location.path('tab/index');
//    }
    var check_url = $location.url().split('/');
    switch (check_url[2]) {
        case 'dash-happy-hour-listing':
            $scope.tab_suffix = "dash-";
            break;
        case 'fav-happy-hour-listing':
            $scope.tab_suffix = "fav-";
            break;
        default:
            $scope.tab_suffix = '';
            break;
    }
    // check key
    $scope.key = '';
    if ($stateParams.key !== undefined) {
        $scope.paramkey = $stateParams.key;
    }
    if ($stateParams.cityID !== undefined) {
        var cityID = $stateParams.cityID;
        var cities = JSON.parse(localStorage.getItem('cities'));
        angular.forEach(cities, function (value, key) {
            if (value['id'] == parseInt(cityID)) {
                $scope.city_name = value.city;
            }
        });
        $scope.cityID = "/" + cityID;
    } else {
        $scope.cityID = '';
    }
    var limit = 5;
    var offset = 0;
    $scope.loader = true;
    var isRefreshing = false;
    var dataFetcher = null;
    $rootScope.advertisements = [];
//    function setItems(items) {
//        angular.forEach(items, function (task, index) {
//            $scope.advertisements.push(task)
//        });
//    }
    // new code
    $scope.hasMore = true;
    $scope.showdata = false;
    /*
     isRefreshing flag.
     When set to true, on data arrive
     it first empties the list 
     then appends new data to the list.
     */
    var isRefreshing = false;
    /* 
     introduce a custom dataFetcher instance
     so that the old fetch process can be aborted
     when the user refreshes the page.
     */
    var dataFetcher = null;
    function fetchData(offset, limit) {
        var advertisements = [];
        //isAborted flag
        var isAborted = false;
        var deferred = $q.defer();
        //simulate async response
        $timeout(function () {
            if (!isAborted) {
                RestaurantService.get(offset, limit, 1, cityID, "happyhour").success(function (response) {
                    console.log(response);
                    $scope.total_records = response.count;
                    $scope.loader = true;
                    LoaderService.hide();
                    $scope.showdata = false;
                    if (response.status == 1) {
                        angular.forEach(response.data, function (task, index) {
                            advertisements.push(task);
                        });
                        LoaderService.hide()
                        deferred.resolve(advertisements);
                    } else {
                        $scope.loader = false;
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
//        
            } else {
                //when aborted, reject, and don't append the out-dated new data to the list
                deferred.reject();
            }
        }, 6000);
        return {
            promise: deferred.promise,
            abort: function () {
                //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                isAborted = true;
            }
        };
    }
    $scope.focus = function (ad_id, key) {
        if ($rootScope.advertisements[key]["view"] === false) {
            return;
        }
        $rootScope.advertisements[key]["view"] = false;
        var click_detail = {};
        click_detail["ad_id"] = ad_id;
        click_detail["user_id"] = user_detail.id;
        click_detail["type"] = "view";
        CountClickService.add(click_detail).success(function (response) {
        }).error(function (response) {
        });
    }
//    LoaderService.show();
    $scope.doRefresh = function () {
        //resets the flags and counters.
        $scope.hasMore = true;
        offset = 0;
        isRefreshing = true;
        //aborts previous data fetcher
        if (!!dataFetcher)
            dataFetcher.abort();
        //triggers loadMore()
        $scope.loadMore();
    }
    $scope.loadMore = function () {
        //aborts previous data fetcher
        if (!!dataFetcher)
            dataFetcher.abort();
        //fetch new data
        dataFetcher = fetchData(offset, limit);
        console.log(offset, limit);
        //fetch new data
        dataFetcher.promise.then(function (advertisements) {
            if (isRefreshing) {
                //clear isRefreshing flag
                isRefreshing = false;
                //empty the advertisements (delete old data) before appending new data to the end of the advertisements.
                $rootScope.advertisements.splice(0);
                //hide the spin
                $scope.$broadcast('scroll.refreshComplete');
            }
            //Check whether it has reached the end
            if ($scope.total_records < offset || $scope.total_records == offset)
                $scope.hasMore = false;
            //append new data to the advertisements
            $rootScope.advertisements = $rootScope.advertisements.concat(advertisements);
            //hides the spin
            $scope.$broadcast('scroll.infiniteScrollComplete');
            //notify ion-content to resize after inner height has changed.
            //so that it will trigger infinite scroll again if needed.
            $timeout(function () {
//        $ionicScrollDelegate.$getByHandle('mainScroll').resize();
            });
        });
        //update itemOffset
        offset += limit;
    };
    $scope.add_love = function (id, key) {
        var meta_value;
        if ($rootScope.advertisements[key]["love"] == false) {
            $rootScope.advertisements[key]["love"] = true;
            meta_value = 1;
        } else {
            $rootScope.advertisements[key]["love"] = false;
            meta_value = 0;
        }
        var data_obj = {};
        if (localStorage.getItem('user_session') != null) {
            $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
            $scope.user_login = true;
        }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
//        data_obj["meta_value"] = meta_value;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function (response) {
            LoaderService.hide();
            if (response.status == 1) {
            }
        }).error(function (response) {
            LoaderService.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
            }).then(function () {
//                       $ionicHistory.getBackView();
            });
            ;
        });
    }
})
        .controller('BlogCtrl', function ($scope, $rootScope, $cordovaSocialSharing, LikeService, $ionicHistory, $timeout, $q, $ionicScrollDelegate, LoaderService, $ionicHistory, FlashService, $ionicPopup, $state, BlogService) {
            var limit = 5;
            var offset = 0;
            var isRefreshing = false;
            var dataFetcher = null;
            $scope.advertisements = [];
            //    function setItems(items) {
            //        angular.forEach(items, function (task, index) {
            //            $scope.advertisements.push(task)
            //        });
            //    }
            // new code
            $scope.hasMore = true;
            /*
             isRefreshing flag.
             When set to true, on data arrive
             it first empties the list 
             then appends new data to the list.
             */
            var isRefreshing = false;
            /* 
             introduce a custom dataFetcher instance
             so that the old fetch process can be aborted
             when the user refreshes the page.
             */
            var dataFetcher = null;
            $rootScope.blogs = [];
            $scope.loader = true;
//            LoaderService.show({
////        template:"Loading..."
//            });
            $scope.all_likes = {};
            function get_likes() {
                LikeService.get_likes().success(function (response) {
                    if (response.status == 0) {
                    } else {
                        $scope.all_likes = response.data;
                    }
                    $scope.loadMore();
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            get_likes();
            // submit like
            $scope.submitLike = function (post_id, key) {
                LikeService.post(user_detail.id, post_id, "blogs").success(function (response) {
                    LoaderService.hide();
                    if ($rootScope.blogs[key]['like'] == true) {
                        $rootScope.blogs[key]['like'] = false;
                        $rootScope.blogs[key]['total'] = $scope.blogs[key]['total'] - 1;
                    } else {
                        $rootScope.blogs[key]['like'] = true;
                        $rootScope.blogs[key]['total'] = $rootScope.blogs[key]['total'] + 1;
                    }
                    if (response.status == 0) {
                    } else {
//                        $scope.counts  = response.count;
//                        $scope.blog = response.data;
//                    setItems(response.data);
                        $rootScope.$broadcast('scroll.infiniteScrollComplete');
                        $rootScope.$broadcast('scroll.refreshComplete');
                    }
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function (res) {
                        $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            function fetchData(offset, limit) {
                var blogs = [];
                //isAborted flag
                var isAborted = false;
                var deferred = $q.defer();
                //simulate async response
                $timeout(function () {
                    if (!isAborted) {
                        BlogService.get(offset, limit).success(function (response) {
                            $scope.total_records = response.count;
                            angular.forEach(response.data, function (task, index) {
                                if ($scope.all_likes[task['id']]) {
                                    if ($scope.all_likes[task['id']]["user_id"] == user_detail.id) {
                                        task["like"] = true;
                                    } else {
                                        task["like"] = false;
                                    }
                                    if ($scope.all_likes[task['id']]["total"]) {
                                        task["total"] = $scope.all_likes[task['id']]["total"];
                                    } else {
                                        task["total"] = 0;
                                    }
                                    if ($scope.all_likes[task['id']]["comments"]) {
                                        task["total_comments"] = $scope.all_likes[task['id']]["comments"];
                                    } else {
                                        task["total_comments"] = 0;
                                    }
                                } else {
                                    task["like"] = false;
                                    task["total"] = 0;
                                    task["total_comments"] = 0;
                                }
                                blogs.push(task);
                            });
                            LoaderService.hide();
                            deferred.resolve(blogs);
//        localStorage.setItem('cities', JSON.stringify($scope.cities));
                        }).error(function (data) {
                            LoaderService.hide();
                            var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Please check your network connection!'
                            }).then(function () {
//                       $ionicHistory.getBackView();
                            });
                            ;
                        });
                    } else {
                        //when aborted, reject, and don't append the out-dated new data to the list
                        deferred.reject();
                    }
                }, 6000);
                return {
                    promise: deferred.promise,
                    abort: function () {
                        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                        isAborted = true;
                    }
                };
            }
            // load more
            $scope.loadMore = function () {
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //fetch new data
                dataFetcher = fetchData(offset, limit);
                dataFetcher.promise.then(function (blogs) {
                    if (isRefreshing) {
                        //clear isRefreshing flag
                        isRefreshing = false;
                        //empty the blogs (delete old data) before appending new data to the end of the blogs.
                        $rootScope.blogs.splice(0);
                        //hide the spin
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                    //Check whether it has reached the end
                    if ($scope.total_records.length < blogs || $scope.total_records.length == blogs)
                        $scope.hasMore = false;
                    //append new data to the blogs
                    $rootScope.blogs = $rootScope.blogs.concat(blogs);
                    //hides the spin
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $timeout(function () {
//        $ionicScrollDelegate.$getByHandle('mainScroll').resize();
                    });
                });
                $scope.doShare = function (key) {
                    var link = $scope.blogs[key]["post_url"];
                    $cordovaSocialSharing
                            .share(null, null, null, link) // Share via native share sheet
                            .then(function (result) {
                                // Success!
                            }, function (err) {
                                alert()
                                // An error occured. Show a message to the user
                            });
                };
                //update itemOffset
                offset += limit;
            };
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                offset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
        })
        .controller('LoginCtrl', function ($scope, $location, $ionicHistory, LoaderService, $ionicHistory, FlashService, $ionicPopup, $state, LoginService, Auth, FacebookService, $cordovaOauth, $http) {
            if (localStorage.getItem('success') !== null) {
                $scope.success = true;
                localStorage.removeItem('success');
            }
            $scope.BackButton = function () {
//        $ionicHistory.getBackView();
                $ionicHistory.backView();
            }
            // login code
            $scope.data = {};
            $scope.login = function () {
                if ($scope.data.username === undefined) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Invalid username!'
                    });
                    return;
                }
                if ($scope.data.username == '') {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please enter your username!'
                    });
                    return;
                }
                if ($scope.data.password === undefined) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please enter your password!'
                    });
                    return;
                }
                LoaderService.show();
                LoginService.loginUser($scope.data.username, $scope.data.password).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {
//                console.log(response.data);
                        $ionicHistory.clearCache()
                        Auth.setUser(response.data);
                        window.localStorage.setItem('user_session', JSON.stringify(response.data));
                        user_detail = response.data;
                        var alertPopup = $ionicPopup.alert({
                            title: 'Success',
                            template: 'Successfully loged in!'
                        }).then(function () {
                            $state.go('tab.dashboard');
                        });
                        return response.data;
//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                        // success
                    } else if (response.status == 0) {
                        var alertPopup = $ionicPopup.alert({
                            title: 'Login failed!',
                            template: "Please check your credentials"
                        });
                    } else {
                        var alertPopup = $ionicPopup.alert({
                            title: 'Login failed!',
                            template: 'Something went wrong'
                        });
                    }
//            $state.go('tab.dash');
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
//                .error(function(data) {
//            var alertPopup = $ionicPopup.alert({
//                title: 'Login failed!',
//                template: 'Please check your credentials!'
//            });
//        });
            }
            $scope.successMessage = FlashService.getMessage();
            // facebook login
            $scope.loginFb = function () {
                LoaderService.show();
                $cordovaOauth.facebook("1048311051927168", ["email", "public_profile"]).then(function (result) {
                    console.log(angular.toJson(result, true));
                    $http.get("https://graph.facebook.com/v2.2/me", {params: {access_token: result.access_token, fields: "id,email,first_name,last_name,gender,picture", format: "json"}}).then(function (result) {
//                         console.log(angular.toJson(result, true));   
                        var fb_object = {};
                        fb_object["name"] = result.data.first_name + " " + result.data.last_name;
                        fb_object["gender"] = result.data.gender;
                        fb_object["fb_id"] = result.data.id;
                        fb_object["email"] = result.data.email;
                        fb_object["image"] = result.data.picture.data.url;
                        FacebookService.register(fb_object).success(function (response) {
                            Auth.setUser(response.data);
                            user_detail = response.data;
                            window.localStorage.setItem('user_session', JSON.stringify(response.data));
                            var alertPopup = $ionicPopup.alert({
                                title: 'Success',
                                template: 'Successfully loged in!'
                            }).then(function () {
                                $state.go('tab.dashboard');
                            });
                            return response.data;
                        }).error(function (response) {
                            LoaderService.hide();
                            var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Please check your network connection!'
                            }).then(function (res) {
                                $ionicHistory.getBackView();
                            });
                        });
                    }, function (error) {
                        alert("There was a problem getting your profile.  Check the logs for details.");
                        LoaderService.hide();
                    });
                    LoaderService.hide();
                    // results
                }, function (error) {
                    // error
                    LoaderService.hide();
                });
            };
//            $scope.loginFb = function () {
//                FB.login(function (response) {
//                    if (response.authResponse) {
//                        FB.api('/me', {
//                            fields: ["email", "first_name", "last_name", "gender", "picture"]
//                        }, function (response) {
//                            var fb_object = {};
//                            fb_object["name"] = response.first_name + " " + response.last_name;
//                            fb_object["gender"] = response.gender;
//                            fb_object["fb_id"] = response.id;
//                            fb_object["email"] = response.email;
//                            fb_object["image"] = response.picture.data.url;
//                            FacebookService.register(fb_object).success(function (response) {
//                                Auth.setUser(response.data);
//                                user_detail = response.data;
//                                window.localStorage.setItem('user_session', JSON.stringify(response.data));
//                                var alertPopup = $ionicPopup.alert({
//                                    title: 'Success',
//                                    template: 'Successfully loged in!'
//                                }).then(function () {
//                                    $state.go('tab.dashboard');
//                                });
//                                return response.data;
//
//                            }).error(function (response) {
//                                LoaderService.hide();
//                                var alertPopup = $ionicPopup.alert({
//                                    title: 'Error',
//                                    template: 'Please check your network connection!'
//                                }).then(function (res) {
//                                    $ionicHistory.getBackView();
//                                });
//                            });
//
//
//
//                            console.log('Good to see you ' + response.first_name + " " + response.last_name + '.');
//
//
//                            var token = FB.getAuthResponse();
//                            console.log(token);
//
//                        });
//                    } else {
//                        console.log('User cancelled login or did not fully authorize.');
//                    }
//                });
//            };
        })
        .controller('AccountCtrl', function ($scope) {
            $scope.settings = {
                enableFriends: true
            };
        })
        .controller("DashCtrl", function ($location, $timeout, $ionicPopover, $scope, Auth, $ionicHistory, LoaderService, $ionicHistory, $ionicPopup, DashboardService, $state, AddloveService, RestaurantService) {
            $scope.user_detail = user_detail;
            $scope.show = false;
            LoaderService.show();
            $scope.loader = true
            $scope.data = [];
            function setItems(items) {
                angular.forEach(items, function (task, index) {
                    $scope.advertisements.push(task)
                });
            }
            // action sheet
            // modal
            $ionicPopover.fromTemplateUrl('templates/popover.html', {
                scope: $scope
            }).then(function (popover) {
                $scope.popover = popover;
            });
            $scope.new_data = {};
// popover show search
            $scope.Dashadd_love = function (id, key) {
                if ($scope.Popadvertisements[key]["love"] == false) {
                    $scope.Popadvertisements[key]["love"] = true;
                } else {
                    $scope.Popadvertisements[key]["love"] = false;
                }
                var data_obj = {};
                if (localStorage.getItem('user_session') != null) {
                    $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                    $scope.user_login = true;
                }
                data_obj["user_id"] = $scope.user_detail.id;
                data_obj["ad_id"] = id;
                data_obj["meta_key"] = "love_advertisement";
                AddloveService.get(data_obj).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            function get_dashboard_data() {
                DashboardService.get(user_detail.id).success(function (response) {
                    LoaderService.hide();
                    $scope.show = true;
                    $scope.data = response.data;
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            $scope.doRefresh = function () {
                $scope.data = {};
                LoaderService.show();
                get_dashboard_data();
                $scope.$broadcast('scroll.refreshComplete');
            }
            LoaderService.show();
            get_dashboard_data();
            $scope.add_love = function (id, key, main_key) {
                if ($scope.data[main_key][key]["love"] == false) {
                    $scope.data[main_key][key]["love"] = true;
                } else {
                    $scope.data[main_key][key]["love"] = false;
                }
                var data_obj = {};
                if (localStorage.getItem('user_session') != null) {
//                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                    $scope.user_login = true;
                }
                data_obj["user_id"] = $scope.user_detail.id;
                data_obj["ad_id"] = id;
                data_obj["meta_key"] = "love_advertisement";
                AddloveService.get(data_obj).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            // add love
            $scope.Happyadd_love = function (id, key) {
                if ($scope.HappyHoursadvertisements[key]["love"] == false) {
                    $scope.HappyHoursadvertisements[key]["love"] = true;
                } else {
                    $scope.HappyHoursadvertisements[key]["love"] = false;
                }
                var data_obj = {};
                if (localStorage.getItem('user_session') != null) {
                    $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                    $scope.user_login = true;
                }
                data_obj["user_id"] = $scope.user_detail.id;
                data_obj["ad_id"] = id;
                data_obj["meta_key"] = "love_advertisement";
                AddloveService.get(data_obj).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            $scope.Brunchadd_love = function (id, key) {
                if ($scope.Popadvertisements[key]["love"] == false) {
                    $scope.Popadvertisements[key]["love"] = true;
                } else {
                    $scope.Popadvertisements[key]["love"] = false;
                }
                var data_obj = {};
                if (localStorage.getItem('user_session') != null) {
                    $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                    $scope.user_login = true;
                }
                data_obj["user_id"] = $scope.user_detail.id;
                data_obj["ad_id"] = id;
                data_obj["meta_key"] = "love_advertisement";
                AddloveService.get(data_obj).success(function (response) {
                    LoaderService.hide();
                    if (response.status == 1) {
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            $scope.ShowDashboard = true;
            $scope.search = {};
            $scope.showadds = false;
            $scope.showsearch = false;
            // fired on search
            $scope.showadd = function () {
                if ($scope.search.value == '') {
                    $scope.showadds = false;
                    $scope.showsearch = false;
                    $scope.ShowDashboard = true;
                } else {
                    if ($scope.showadds == true) {
                        return;
                    }
                    $scope.showadds = true;
                    $scope.ShowDashboard = false;
                    LoaderService.show();
                }
                // functions
                $scope.Popadvertisements = [];
                function setItems(items) {
                    angular.forEach(items, function (task, index) {
                        $scope.Popadvertisements.push(task)
                    });
                }
                var offset = 0;
                var limit = 100;
                RestaurantService.get(offset, limit, 2).success(function (response) {
                    $scope.showsearch = true;
                    $scope.showPopUpData = true;
                    LoaderService.hide();
                    if (response.status == 1) {
                        offset = offset + limit;
                        setItems(response.data);
                    } else {
                        $scope.loader = false;
                    }
                    if (offset >= response.count) {
                        $scope.loader = false;
                    } else {
                    }
                }).error(function (response) {
                    $scope.showPopUpData = true;
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
                        //                       $ionicHistory.getBackView();
                    });
                    ;
                });
                $scope.showHappyHours = false;
                $scope.showBrunches = true;
                // get happy hours
                $scope.HappyHoursadvertisements = [];
                function setItemsHappy(items) {
                    angular.forEach(items, function (task, index) {
                        $scope.HappyHoursadvertisements.push(task)
                    });
                }
                RestaurantService.get(offset, limit, 1).success(function (response) {
                    $scope.showPopUpData = true;
                    LoaderService.hide();
                    if (response.status == 1) {
                        offset = offset + limit;
                        $scope.showsearch = true;
                        setItemsHappy(response.data);
                    } else {
                        $scope.showsearch = true;
                        $scope.loader = false;
                    }
                    if (offset >= response.count) {
                        $scope.loader = false;
                    } else {
                    }
                }).error(function (response) {
                    $scope.showPopUpData = true;
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
                        //                       $ionicHistory.getBackView();
                    });
                    ;
                });
            }
            // happy hour and brunch bottons click event
            $scope.showHappyHoursFunction = function () {
                $scope.showHappyHours = true;
                $scope.showBrunches = false;
            }
            $scope.showBrunchesFunction = function () {
                $scope.showHappyHours = false;
                $scope.showBrunches = true;
            }
        }).controller('LoaderCtrl', function ($scope, LoaderService) {
    $scope.showLoadingProperTimes = function () {
        LoaderService.show({
            templateUrl: "templates/loading.html"
        });
    };
    $scope.hideLoadingProperTimes = function () {
        //LoaderService.hide();
    };
    $scope.showLoadingProperTimes();
})
        .controller("EdituserCtrl", function ($scope, Auth, $ionicHistory, $timeout, LoaderService, $ionicPopup, $state, $stateParams, $http, $location, RegisterService, FlashService, UserService, CityService, StateService, FileuploadService, GetUserService) {
            $scope.user = {};
            $scope.show = false;
            LoaderService.show();
            $timeout(function () {
                LoaderService.hide();
                $scope.show = true;
            }, 100);
            var user_id = user_detail.id;
            // get user
            GetUserService.get(user_id).success(function (response) {
                $scope.user = response.data;
            }).error(function (response) {
                var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'very Slow network!'
                });
            });
            $scope.FlashService = FlashService;
            $scope.successMessage = FlashService.getMessage();
            $scope.cities = {};
            if (localStorage.getItem('cities') == null) {
                CityService.get().success(function (response) {
                    $scope.cities = response.data;
                    localStorage.setItem('cities', JSON.stringify($scope.cities));
                });
            } else {
                $scope.cities = JSON.parse(localStorage.getItem('cities'));
            }
            $scope.states = {};
            if (localStorage.getItem('states') == null) {
                StateService.get().success(function (response) {
                    $scope.states = response.data;
                    localStorage.setItem('states', JSON.stringify($scope.states));
                });
            } else {
                $scope.states = JSON.parse(localStorage.getItem('states'));
            }
            $scope.success = false;
            $scope.error = false;
            $scope.register = function () {
                LoaderService.show();
                var post_user_array = null;
                angular.forEach($scope.user, function (task, index) {
                    if (post_user_array == null) {
                        post_user_array = index + "=" + task;
                    } else {
                        post_user_array = post_user_array + '&' + index + "=" + task;
                    }
                });
                RegisterService.update($scope.user).success(function (response) {
                    console.log(response);
                    if (response) {
                        $timeout(function () {
                            LoaderService.hide();
                            $scope.show = true;
                            user_detail.name = $scope.user.name;
                            if ($scope.user.image) {
                                user_detail.image = $scope.user.image;
                            }
                            LoaderService.hide();
                            if (response.status == 1) {
                                $ionicHistory.clearCache();
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
                                var alertPopup = $ionicPopup.alert({
                                    title: 'Success',
                                    template: 'Successfully Updated!'
                                }).then(function () {
                                    $state.go('tab.dashboard');
                                });
//                            $location.path("/login"); 
                                $scope.success = true;
                            } else {
//                            $scope.error = true;
                            }
                        }, 100);
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    } else {
                    }
                }).error(function (data) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Something went wrong!'
                    });
                    return;
                });
            }
            $scope.interests = {};
            if (localStorage.getItem('interests') == null) {
                UserinfoService.get(1).success(function (response) {
                    $scope.interests = response.data;
                    localStorage.setItem('interests', JSON.stringify($scope.interests));
                });
            } else {
                $scope.interests = JSON.parse(localStorage.getItem('interests'));
            }
            //
            $scope.occupations = {};
            if (localStorage.getItem('occupations') == null) {
                UserinfoService.get(2).success(function (response) {
                    $scope.occupations = response.data;
                    localStorage.setItem('occupations', JSON.stringify($scope.occupations));
                });
            } else {
                $scope.occupations = JSON.parse(localStorage.getItem('occupations'));
            }
            $scope.educations = {};
            if (localStorage.getItem('educations') == null) {
                UserinfoService.get(3).success(function (response) {
                    $scope.educations = response.data;
                    localStorage.setItem('educations', JSON.stringify($scope.educations));
                });
            } else {
                $scope.educations = JSON.parse(localStorage.getItem('educations'));
            }
            $scope.uploadResult = [];
            $scope.onFileSelect = function ($files) {
//             console.log($files);
                FileuploadService.uploadImage($files).success(function (response) {
                    if (response.data.status == 1) {
                        $scope.user.userfile = response.data.data;
                    } else {
                        console.log("error while uploading image");
                    }
                }).error(function (data) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Password',
                        template: 'very Slow network!'
                    });
                    return;
                });
//                     .success(function(response){
//                 console.log(response);
//             });
                //$files: an array of files selected, each file has name, size, and type.
            };
        })
        .controller("RegisterCtrl", function ($scope, $timeout, LoaderService, $ionicPopup, $state, $stateParams, $http, $location, RegisterService, FlashService, UserService, CityService, StateService, FileuploadService, UserinfoService) {
            $scope.show = false;
            LoaderService.show();
            $timeout(function () {
                LoaderService.hide();
                $scope.show = true;
            }, 100);
            $scope.user = {};
            $scope.FlashService = FlashService;
            $scope.successMessage = FlashService.getMessage();
            $scope.cities = {};
            if (localStorage.getItem('cities') == null) {
                CityService.get().success(function (response) {
                    $scope.cities = response.data;
                    localStorage.setItem('cities', JSON.stringify($scope.cities));
                });
            } else {
                $scope.cities = JSON.parse(localStorage.getItem('cities'));
            }
            $scope.states = {};
            if (localStorage.getItem('states') == null) {
                StateService.get().success(function (response) {
                    $scope.states = response.data;
                    localStorage.setItem('states', JSON.stringify($scope.states));
                });
            } else {
                $scope.states = JSON.parse(localStorage.getItem('states'));
            }
            $scope.interests = {};
            if (localStorage.getItem('interests') == null) {
                UserinfoService.get(1).success(function (response) {
                    $scope.interests = response.data;
                    localStorage.setItem('interests', JSON.stringify($scope.interests));
                });
            } else {
                $scope.interests = JSON.parse(localStorage.getItem('interests'));
            }
            //
            $scope.occupations = {};
            if (localStorage.getItem('occupations') == null) {
                UserinfoService.get(2).success(function (response) {
                    $scope.occupations = response.data;
                    localStorage.setItem('occupations', JSON.stringify($scope.occupations));
                });
            } else {
                $scope.occupations = JSON.parse(localStorage.getItem('occupations'));
            }
            $scope.educations = {};
            if (localStorage.getItem('educations') == null) {
                UserinfoService.get(3).success(function (response) {
                    $scope.educations = response.data;
                    localStorage.setItem('educations', JSON.stringify($scope.educations));
                });
            } else {
                $scope.educations = JSON.parse(localStorage.getItem('educations'));
            }
            $scope.success = false;
            $scope.error = false;
            $scope.register = function () {
                console.log($scope.user);
                LoaderService.show();
                RegisterService.register($scope.user).success(function (response) {
//                    $scope.response = response;
                    console.log(response);
                    if (response) {
                        LoaderService.hide();
                        if (response.status == 1) {
//                            $scope.user = {};
                            var alertPopup = $ionicPopup.alert({
                                title: 'Success',
                                template: 'Successfully Registered!'
                            }).then(function () {
                                $state.go('login');
                            });
//                            localStorage.setItem('success',"true");
//                            $location.path("/login");
//                            $scope.success = true;
                        } else {
//                            $scope.error = true;
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    } else {
                    }
                }).error(function (response) {
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: 'Error',
                        template: 'Please check your network connection!'
                    }).then(function () {
//                       $ionicHistory.getBackView();
                    });
                });
            }
            $scope.uploadResult = [];
            $scope.onFileSelect = function ($files) {
//             console.log($files);
                FileuploadService.uploadImage($files).success(function (response) {
                    if (response.data.status == 1) {
                        $scope.user.userfile = response.data.data;
                    } else {
                        console.log("error while uploading image");
                    }
                }).error(function (data) {
                    var alertPopup = $ionicPopup.alert({
                        title: 'Password',
                        template: 'very Slow network!'
                    });
                    return;
                });
//                     .success(function(response){
//                 console.log(response);
//             });
                //$files: an array of files selected, each file has name, size, and type.
            };
            LoaderService.hide();
        })
        .controller('TestingCtrl', function ($scope, $timeout, $q, $ionicScrollDelegate) {
            /*
             list of items, used by ng-repeat
             */
            $scope.list = [];
            var itemOffset = 0,
                    itemsPerPage = 5;
            /*
             used by ng-if on ion-infinite-scroll
             */
            $scope.hasMore = true;
            /*
             isRefreshing flag.
             When set to true, on data arrive
             it first empties the list 
             then appends new data to the list.
             */
            var isRefreshing = false;
            /* 
             introduce a custom dataFetcher instance
             so that the old fetch process can be aborted
             when the user refreshes the page.
             */
            var dataFetcher = null;
            /*
             returns a "dataFetcher" object
             with a promise and an abort() method
             
             when abort() is called, the promise will be rejected.
             */
            function fetchData(itemOffset, itemsPerPage) {
                var list = [];
                //isAborted flag
                var isAborted = false;
                var deferred = $q.defer();
                //simulate async response
                $timeout(function () {
                    if (!isAborted) {
                        //if not aborted
                        //assume there are 22 items in all
                        for (var i = itemOffset; i < itemOffset + itemsPerPage && i < 22; i++) {
                            list.push("Item " + (i + 1) + "/22");
                        }
                        deferred.resolve(list);
                    } else {
                        //when aborted, reject, and don't append the out-dated new data to the list
                        deferred.reject();
                    }
                }, 6000);
                return {
                    promise: deferred.promise,
                    abort: function () {
                        //set isAborted flag to true so that the promise will be rejected, and no out-dated data will be appended to the list
                        isAborted = true;
                    }
                };
            }
            fetchData(itemOffset, itemsPerPage);
            $scope.doRefresh = function () {
                //resets the flags and counters.
                $scope.hasMore = true;
                itemOffset = 0;
                isRefreshing = true;
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //triggers loadMore()
                $scope.loadMore();
            }
            $scope.loadMore = function () {
                //aborts previous data fetcher
                if (!!dataFetcher)
                    dataFetcher.abort();
                //fetch new data
                dataFetcher = fetchData(itemOffset, itemsPerPage);
                console.log(dataFetcher);
                dataFetcher.promise.then(function (list) {
                    console.log(list);
                    if (isRefreshing) {
                        //clear isRefreshing flag
                        isRefreshing = false;
                        //empty the list (delete old data) before appending new data to the end of the list.
                        $scope.list.splice(0);
                        //hide the spin
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                    //Check whether it has reached the end
                    if ($scope.total_records < itemsPerPage || $scope.total_records == itemsPerPage)
                        $scope.hasMore = false;
                    //append new data to the list
                    $scope.list = $scope.list.concat(list);
                    console.log($scope.list);
                    //hides the spin
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    //notify ion-content to resize after inner height has changed.
                    //so that it will trigger infinite scroll again if needed.
                    $timeout(function () {
//        $ionicScrollDelegate.$getByHandle('mainScroll').resize();
                    });
                });
                //update itemOffset
                itemOffset += itemsPerPage;
            };
        })
// social sharing
        