angular.module('starter.services', [])
        .constant('api','http://boozyadguru.com/webservices/')

.factory('Auth', ['$state', function($state) { 
   if (window.localStorage['user_session']) {
      var _user = JSON.parse(window.localStorage['user_session']);
   }
   var setUser = function (user_session1) {
      _user = user_session1;
      window.localStorage['user_session'] = JSON.stringify(_user);
      user_detail = JSON.stringify(_user);
   }
//die();
   return {
      setUser: setUser,
      isLoggedIn: function () {
         return _user ? true : false;
      },
      getUser: function () {
         return _user;
      },
      logout: function () {
         window.localStorage.removeItem("user_session"); 
         window.localStorage.removeItem("list_dependents");
         user_detail = {};
         _user = null;
         $state.go('index');
      }
   }
}]).service("FacebookService",['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
   return {
       register : function(user) {
//              var data = {
//                fName: 'firstName',
//                lName: 'lastName'
//            };
//              var data = {};
//              data["hello"] = ' asdsd';
             return $http({
                method: 'POST',
                url: api+'facebook_login',
                data: $httpParamSerializer(user),
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function(response) {
                return response;
            });
//            return nukeService.data;
         } 
     }
}]).service('LoaderService', ['$ionicLoading',function($ionicLoading){
        return {
            show : function(){
                $ionicLoading.show({
                        template:'\
                    <ion-spinner icon="lines" class="spinner spinner-ripple"></ion-spinner>\
                    <div style="margin:auto;text-align:center">Please wait!!!</div>\
                    ',
                content: 'Loading',
                animation: 'fade-in',
                showBackdrop: false,
                maxWidth: 200,
                showDelay: 0
              }); 
            },
            hide:function(){
                $ionicLoading.hide();
            }
        }
}]).service('LoaderService2', ['$ionicLoading',function($ionicLoading){
        return {
            show : function(){
                $ionicLoading.show({
                        template:'\
                     <ion-spinner icon="ripple" class="spinner spinner-ripple"></ion-spinner>\
                    <div style="margin:auto;text-align:center">Please wait!!!</div>\
                    ',
                content: 'Loading',
                animation: 'fade-in',
                showBackdrop: false,
                maxWidth: 200,
                showDelay: 0
              }); 
            },
            hide:function(){
                $ionicLoading.hide();
            }
        }
}]).service('LoginService', ['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
    
    return {
        loginUser: function(username, password) {
            var user = new Object();
//            user["username"] = username;
            user = {
                password: password,
                username: username
            }
//            user['password'] = password;
            return $http({
                method: 'get',
                url: api+'login?username='+username+"&password="+password,
                data: $httpParamSerializer(user),
                 headers: {
                    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
                }).success(function(response) {
                return response;
                if (response.data.status == 1) {
                    return response.data;
                } else {
                    return false;
                }
            });
        }
    }
}]).factory("UserService",['$http',function($http){
        var service = {};
 
        service.GetAll = GetAll;
        service.GetById = GetById;
        service.GetByUsername = GetByUsername;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;
        return service;
 
        function GetAll() {
            return $http.get('/api/users').then(handleSuccess, handleError('Error getting all users'));
        }
 
        function GetById(id) {
            return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
        }
 
        function GetByUsername(username) {
            return $http.get('/api/users/' + username).then(handleSuccess, handleError('Error getting user by username'));
        }
 
        function Create(user) {
            return $http.post('/api/users', user).then(handleSuccess, handleError('Error creating user'));
        }
 
        function Update(user) {
            return $http.put('/api/users/' + user.id, user).then(handleSuccess, handleError('Error updating user'));
        }
 
        function Delete(id) {
            return $http.delete('/api/users/' + id).then(handleSuccess, handleError('Error deleting user'));
        }
 
        // private functions
 
        function handleSuccess(res) {
            return res.data;
        }
 
        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }
}]).service('GetUserService', ['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
    
    return {
        get: function(user_id){
            return $http({ 
                method: 'get',
                url: api+'get_user?user_id='+user_id,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
        }
    }
}]).service('StateListingService', ['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
    
    return {
        get : function (offset,limit){
             return $http({ 
                method: 'get',
                url: api+'listing_by_state?offset='+offset+"&limit="+limit,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        }
    }
}]).service('LatLongService', ['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
    
    return {
        get : function (type){
             return $http({ 
                method: 'get',
                url: api+'get_lat_long/'+type,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        }
    }
}]).service('StateCityListingService', ['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
    return {
        get : function (state_id,offset,limit){
             return $http({ 
                method: 'get',
                url: api+'listing_by_state_city?offset='+offset+"&limit="+limit+"&state_id="+state_id,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            ;
        }
    }
}]).service('StateTownListingService', ['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
    
    return {
        get : function (state_id,offset,limit){
             return $http({ 
                method: 'get',
                url: api+'listing_by_state_town?offset='+offset+"&limit="+limit+"&state_id="+state_id,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        }
    }
}]).service('FavouriteService', ['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {
    
    return {
        get : function (user_id,offset,limit){
             return $http({ 
                method: 'get',
                url: api+'favourites?user_id='+user_id+'&offset='+offset+"&limit="+limit,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        }
    }
}]).factory('RestaurantService',['$http',"$timeout","$location","UserService","api", function($http,$timeout,$location,UserService, api) {
return {
    get : function (offset,limit,option,cityID,alldata){
        if(cityID && alldata == undefined){
            var url = api+'favourites_bycity?offset='+offset+"&limit="+limit+"&option="+option+"&cityID="+cityID;
        } else if(cityID){
            var url = api+'get_restaurants?offset='+offset+"&limit="+limit+"&option="+option+"&cityID="+cityID;
        } else {
            var url = api+'get_restaurants?offset='+offset+"&limit="+limit+"&option="+option;
        }
        var user = '';
        if(user_detail != null){
            user = "&user_id="+user_detail.id
        }
             return $http({
                method: 'get',
                url: url+user,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        },
        getsingle : function (ad_id,user_id){
             return $http({
                method: 'get',
                url: api+'get_restaurants?ad_id='+ad_id+"&user_id="+user_id,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        },
        getComments : function (ad_id,user_id){
             return $http({
                method: 'get',
                url: api+'get_comments/'+ad_id+"/"+user_id,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        }
}
}]).factory('AddloveService',['$http',"$timeout","$location","UserService","$httpParamSerializer","api", function($http,$timeout,$location,UserService,$httpParamSerializer, api) {
return {
    get : function (data){
             return $http({
                method: 'get', 
                url: api+'restaurant_meta1',
                params : data,
//                data: $httpParamSerializer(data),
                headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        },
}
}]).factory('GetCommentsService',['$http',"$timeout","$location","UserService","$httpParamSerializer","api", function($http,$timeout,$location,UserService,$httpParamSerializer, api) {
return {
    get : function (type,postId,limit){
        if(limit){
            
        } else {
            limit = '';
        }
             return $http({
                method: 'get', 
                url: api+'get_comments/'+postId+"/"+type+"/"+limit,
//                params : data,
//                data: $httpParamSerializer(data),
                headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
            return;
        },
}
}]).factory('LikeService',['$http',"$timeout","$location","UserService","$httpParamSerializer","api", function($http,$timeout,$location,UserService,$httpParamSerializer, api) {
return {
    get_likes : function (type,postId,limit){
        if(limit){
            
        } else {
            limit = '';
        }
             return $http({
                method: 'get', 
                url: api+'all_likes',
//                params : data,
//                data: $httpParamSerializer(data),
                headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
        },
        post: function(user_id,PostId,Type){
            return $http({
                method: 'get', 
                url: api+'postlike/'+user_id+"/"+PostId+"/"+Type,
//                params : data,
//                data: $httpParamSerializer(data),
                headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
        }
}
}]).factory('DashboardService',['$http',"$timeout","$location","UserService","api", function($http,$timeout,$location,UserService, api) {
    
return {
        get: function (user_id){ 
             return $http({
                method: 'get',
                url: api+'dashboard?user_id='+user_id,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                return response;
            }).error(function(response){
                return response;
            });
        }
    }
    
}]).factory('BlogService',['$http',"$timeout","$location","UserService","api", function($http,$timeout,$location,UserService, api) {
    var nukeService = {};
nukeService.data = {};
return {
        get: function (offset,limit){ 
             return $http({
                method: 'get',
                url: 'http://iamboozin.com/api.php?offset='+offset+"&limit="+limit,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                if (response.status == 1) {
                    nukeService.data  = response.data.data;
                    return nukeService;
                } 
            }).error(function(data){
                return false;
            });
            return nukeService.data;
        },
        getsingleBlog : function (blogId){ 
             return $http({
                method: 'get',
                url: 'http://iamboozin.com/api.php?post_id='+blogId,
                headers: {
                'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='},
                timeout : 60000
            }).success(function(response) {
                if (response.status == 1) {
                    nukeService.data  = response.data.data;
                    return nukeService;
                } 
            }).error(function(data){
                return false;
            });
            return nukeService.data;
        }
    }
    
}]).factory('CityService',['$http',"$timeout","$location","UserService","api", function($http,$timeout,$location,UserService, api) {
    var nukeService = {};
nukeService.data = {};
return {
        get: function (){ 
             return $http({
                method: 'get',
                url: api+'get_city',
//                data: 'username=' + username + '&password=' + password + '&email=' + email,
                headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
            }).success(function(response) {
                if (response.data.status == 1) {
                    nukeService.data  = response.data.data;
                    return nukeService;
                } else {
                    return false;
                }
            });
            return nukeService.data;
        }
    }
    
}]).factory('StateService',['$http',"$location","$timeout","$location","UserService","api", function($http,$location,$timeout,$location,UserService, api) {
    var nukeService = {};
nukeService.data = {};
return {
        get: function (){ 
             return $http({
                method: 'get',
                url: api+'get_state',
//                data: 'username=' + username + '&password=' + password + '&email=' + email,
                headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
            }).success(function(response) {
                if (response.data.status == 1) {
                    nukeService.data  = response.data.data;
                    return nukeService;
                } else {
                    return false;
                }
            });
            return nukeService.data;
        }
    }
    
}]).factory('UserinfoService',['$http',"$location","$timeout","$location","UserService","api", function($http,$location,$timeout,$location,UserService, api) {
    var nukeService = {};
nukeService.data = {};
return {
        get: function ($type){ 
             return $http({
                method: 'get',
                url: api+'user_info/'+$type,
//                data: 'username=' + username + '&password=' + password + '&email=' + email,
                headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
            }).success(function(response) {
                return response;
                
            }).error(function(response){
                return response;
            });
            
        }
    }
    
}]).factory("FlashService2",['$http',"$timeout","$rootScope",function($http,$timeout,$rootScope){
    return {
        Success: function (message, keepAfterLocationChange) {
            $rootScope.flash = {
                message: message,
                type: 'success', 
                keepAfterLocationChange: keepAfterLocationChange
            };
        },
    
    Error: function (message, keepAfterLocationChange) {
            $rootScope.flash = {
                message: message,
                type: 'error',
                keepAfterLocationChange: keepAfterLocationChange
            };
        },
        
        }
}]).factory("FlashService", ['$http',"$timeout","$rootScope",function($http,$timeout,$rootScope) {
  var queue = [];
  var currentMessage = "";

  $rootScope.$on("$routeChangeSuccess", function() {
    currentMessage = queue.shift() || "";
  });

  return {
    setMessage: function(message) {
      queue.push(message);
    },
    getMessage: function() {
      return queue[0];
    }
  };
}]).factory("FileuploadService",['$http',"$timeout","$location","$upload","api", function($http,$timeout,$location,$upload,api){

 return {
     uploadImage : function($files){
//         for (var i = 0; i < $files.length; i++) {
      var $file = $files[0];
     return $upload.upload({
        url: api+'upload_image',
        file: $file,
        progress: function(e){}
      }).success(function(response) {
          return response;
        // file is uploaded successfully
		$timeout(function() {
                    
//            $scope.uploadResult.push(response.data);
//            $scope.image = response.data;
//            $scope.user.image = response.data;
				});

      });
//  }
         
     }
 }
}])
.factory('CountClickService',['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {

         
    return {
        add : function(detail) {
//              var data = {
//                fName: 'firstName',
//                lName: 'lastName'
//            };
//              var data = {};
//              data["hello"] = ' asdsd';
             return $http({
                method: 'get',
                url: api+'click_history',
                            params: detail,
//                data: $httpParamSerializer(detail),
               headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function(response) {
                return response;
            });
//            return nukeService.data;
         },
         update : function(user) {
//              var data = {
//                fName: 'firstName',
//                lName: 'lastName'
//            };
//              var data = {};
//              data["hello"] = ' asdsd';
             return $http({
                method: 'POST',
                url: api+'update_user',
                data: $httpParamSerializer(user),
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function(response) {
                return response;
            });
//            return nukeService.data;
         },
        get: function (user_detail){
            return user_detail;
        }
    }
}])

        .factory('RegisterService',['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {

         
    return {
        register : function(user) {
             return $http({
                method: 'get',
                url: api+'register',
                params : user, 
                 headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
            }).success(function(response) {
                return response;
            });
         },
         update : function(user) {
             return $http({
                method: 'get',
                url: api+'update_user',
                params : user, 
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function(response) {
                return response;
            });
//            return nukeService.data;
         },
        get: function (user_detail){
            return user_detail;
        }
    }
}]).factory('SubmitcommentService',['$http',"$timeout","$location","UserService","api","$httpParamSerializer", function($http,$timeout,$location,UserService, api,$httpParamSerializer) {

         
    return {
        register : function(comment) {
             return $http({
                method: 'POST',
                url: api+'addcomment',
                data: $httpParamSerializer(comment),
                timeout : 60000,
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function(response) {
                return response;
            }).error(function(data){
                return false;
            });;
         }
    }
}])

