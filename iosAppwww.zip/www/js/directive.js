angularmodule.directive('ngCompare', function () {
    return {
        require: 'ngModel',
        link: function (scope, currentEl, attrs, ctrl) {
            var comparefield = document.getElementsByName(attrs.ngCompare)[0]; //getting first element
            compareEl = angular.element(comparefield);

            //current field key up
            currentEl.on('keyup', function () {
//                alert(compareEl.val());
                if (compareEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });

            //Element to compare field key up
            compareEl.on('keyup', function () {
                if (currentEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });
        }
    }
}).directive("ngUnique", ['$http',"api", function($http,api) {
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function (scope, element, attrs, ngModel) {
      element.bind('keyup', function (e) {
//console.log(attrs.userId);
//console.log("dfdf");
          if(!ngModel || !element.val())ngModel.$setValidity('unique', true);
        if (!ngModel || !element.val()) return;
        var keyProperty = scope.$eval(attrs.ngUnique);
        var currentValue = element.val();
        currentValue = currentValue.trim();
      
       if(currentValue.trim()){
           if(attrs.userId != undefined){
               
               var user_id =attrs.userId;
               var url = api+'check_email?email='+currentValue+'&user_id='+user_id;
           } else {
              var url =  api+'check_email?email='+currentValue;
           }
          
       $http({
        method: 'get',
        url: url,
        data: {email:currentValue},
//        params: 'limit=10, sort_by=created:desc',
        headers: {
    'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
     }).success(function(data){
        // With the data succesfully returned, call our callback
        if(data.status == "0"){
            ngModel.$setValidity('unique', false);
        } else {
            ngModel.$setValidity('unique', true);
        }
         return data;
//        callbackFunc(data);
    }).error(function(){
//        alert("error");
    });
       }else {
          ngModel.$setValidity('unique', false); 
       }
   
      });
    }
  }
}]).directive('myMap', function() {
    // directive link function
    var link = function(scope, element, attrs) {
        var map, infoWindow;
        var markers = [];
        
        // map config
        var mapOptions = {
            center: new google.maps.LatLng(50, 2),
            zoom: 4,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            scrollwheel: false
        };
        
        // init the map
        function initMap() {
            if (map === void 0) {
                map = new google.maps.Map(element[0], mapOptions);
            }
        }    
        
        // place a marker
        function setMarker(map, position, title, content) {
            var marker;
            var markerOptions = {
                position: position,
                map: map,
                title: title,
                icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
            };

            marker = new google.maps.Marker(markerOptions);
            markers.push(marker); // add marker to array
            
            google.maps.event.addListener(marker, 'click', function () {
                // close window if not undefined
                if (infoWindow !== void 0) {
                    infoWindow.close();
                }
                // create new window
                var infoWindowOptions = {
                    content: content
                };
                infoWindow = new google.maps.InfoWindow(infoWindowOptions);
                infoWindow.open(map, marker);
            });
        }
        
        // show the map and place some markers
        initMap();
        
        setMarker(map, new google.maps.LatLng(51.508515, -0.125487), 'London', 'Just some content');
        setMarker(map, new google.maps.LatLng(52.370216, 4.895168), 'Amsterdam', 'More content');
        setMarker(map, new google.maps.LatLng(48.856614, 2.352222), 'Paris', 'Text here');
    };
    
    return {
        restrict: 'A',
        template: '<div id="gmaps"></div>',
        replace: true,
        link: link
    };
}).directive("markable", function() {
    return {
        link: function(scope, elem, attrs) {
            elem.on("click", function() {
                if(angular.element(elem).hasClass('active')){
                    elem.removeClass("active");
                } else {
                elem.addClass("active");
            }
            });
        }
    };
});;