

angularmodule = angular.module('starter.controllers', ["angularFileUpload","ionic.rating"]);

angularmodule.constant('api','http://amboff.indiit.com/boozy/webservices/').run(function($ionicHistory,$location,$rootScope,$state){
   user_detail = {};
    if(localStorage.getItem('user_session') !=  null){
                 user_detail = JSON.parse(localStorage.getItem('user_session')); 
            }  else {
               
            }
            
             $rootScope.myGoBack = function() {
                console.log("back");
                $ionicHistory.goBack();
              };
              $rootScope.setItemsGlobal = function (items){
                var get_comments = [];
          angular.forEach(items, function (task, index) {
              get_comments.push(task)
          });
          return get_comments;
      }
})

.controller("LogoutCtrl",function($state,Auth){
    Auth.logout();
            $state.go('index');
})
.controller("FavouritesdetailCtrl",function($scope,$ionicHistory,$stateParams,LoaderService,$ionicPopup, $state,RestaurantService,AddloveService){
   
   
    var limit = 1; 
    var offset = 0;
    var cityID = $stateParams.cityID
    $scope.loader = true
    $scope.myGoBack = function() {
        alert("dfdf");
    $ionicHistory.goBack();
  };
    $scope.advertisements = [];
    function setItems (items){
          angular.forEach(items, function (task, index) {
              $scope.advertisements.push(task)
          });
      }
    function get_advertisement(){
        RestaurantService.get(offset,limit,2,cityID).success(function(response){
            console.log(response);
            LoaderService.hide();
            if(response.status == 1){
                offset  = offset + limit;
                setItems (response.data);
            } else {
                $scope.loader = false;
            }
            if(offset  >= response.count){
                $scope.loader = false;
            } else {
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
    LoaderService.show();
    get_advertisement(offset,limit);
    
    $scope.doRefresh = function(){
        LoaderService.show();
        offset = 0;
        $scope.advertisements = [];
        $scope.loader = true;
        get_advertisement(offset,limit);
        $scope.$broadcast('scroll.refreshComplete');
    }
    $scope.loadMore  = function(){
//        offset  = offset + limit;
             get_advertisement(offset,limit);
         }
    $scope.add_love = function(id,key){
        if($scope.advertisements[key]["love"] == false){
            $scope.advertisements[key]["love"] = true;
        } else {
            $scope.advertisements[key]["love"] = false;
        }
        var data_obj = {};
        if(localStorage.getItem('user_session') !=  null){
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
                
            } 
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        console.log(data_obj);
        AddloveService.get(data_obj).success(function(response){
            LoaderService.hide();
            console.log(response);
            if(response.status == 1){
                
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
})
.controller('FavouritesCtrl', function(LoaderService,$scope,$ionicHistory,LoaderService,$ionicHistory,$ionicPopup, $state,FavouriteService) {
    var limit = 2;
    $scope.loader = true;
    var offset = 0;
    $scope.favouries = [];
    function setItems (items){
        var return_data = [];
          angular.forEach(items, function (task, index) {
              $scope.favouries.push(task)
          });
      }
    function favourites(){
//        user_detail.id= 1;
        FavouriteService.get(user_detail.id,offset,limit).success(function(response){
            LoaderService.hide();
            if(response.status == 1){
                offset  = offset + limit;
               setItems(response.data);
//               console.log(response.data);
               console.log(response.data);
            }
            if(offset  >= response.count){
                $scope.loader = false;
            }
            
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function(){
            LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(res) {
                $ionicHistory.getBackView();
            });
        });
    }
    $scope.loadMore  = function(){
//        offset  = offset + limit;
             favourites();
         }
         $scope.doRefresh = function(){
            LoaderService.show();
            offset = 0;
            $scope.favouries = [];
            $scope.loader = true;
            favourites();
            $scope.$broadcast('scroll.refreshComplete');
        }
        LoaderService.show();
//        LoaderService.hide();
       
        favourites();
})
.controller("BlogdetailCtrl",function($scope,$ionicHistory,LoaderService,$location,$ionicHistory,FlashService,$ionicPopup, $state,$stateParams,BlogService,SubmitcommentService){
    $scope.loader = true;
    $scope.user_login = false;
    $scope.comments = {};
    $scope.user_detail = {};
    
            if(localStorage.getItem('user_session') !=  null){
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
                
            } 
    var blogId = $stateParams.blogId
    LoaderService.show({
//        template:"Loading..."
    });
    $scope.get_comments = [];
    function setItems (items){
          angular.forEach(items, function (task, index) {
              $scope.get_comments.push(task)
          });
      }
    $scope.blog = {};
    function get_blogs(){
    BlogService.getsingleBlog(blogId).success(function(response){
        LoaderService.hide();
        if(response.status == 0){
        
        } else {
            $scope.blog = response.data;
        if(response.data.comments){
            setItems(response.data.comments);
        }
            $scope.$broadcast('scroll.infiniteScrollComplete');
            $scope.$broadcast('scroll.refreshComplete');
        } 
//        localStorage.setItem('cities', JSON.stringify($scope.cities));
    }).error(function(data){
                LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(res) {
                    $ionicHistory.getBackView();
          });;
             });
             
         }
         get_blogs();
         $scope.doRefresh = function(){
             $scope.get_comments = [];
             get_blogs();
//             $scope.$broadcast('scroll.refreshComplete');
         }
         // submit form
//         $ionicPopup.alert({
//            title: 'Password Check',
//            template: 'Enter your secret password',
////            inputType: 'password',
////            inputPlaceholder: 'Your password'
//          }).then(function(res) {
//              $ionicHistory.getBackView();
//            console.log('Your password is', res);
//          });
          
         $scope.submitmessage = function(){
             $scope.comments.user_id = $scope.user_detail.id;
             $scope.comments.template = "blogs";
             $scope.comments.template_id = blogId;
             LoaderService.show();
                SubmitcommentService.register($scope.comments).success(function(response){
                        LoaderService.hide();
                        if(response.status == 1){
                            $scope.comments.comment = "";
                            $scope.get_comments.push(response.data) ;
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                            $scope.success = true;
                        } else {
                            LoaderService.hide();
                                var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Error while posting your comment!'
                               });
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    
                    
                }).error(function(response){
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Please check your network connection!'
                   }).then(function(){
                   });
             
                });
         }
}).controller('GooglemapCtrl', function($scope, LoaderService, $compile) {
      function initialize() {
        var myLatlng = new google.maps.LatLng(43.07493,-89.381388);
        
        var mapOptions = {
          center: myLatlng,
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"),
            mapOptions);
        
        //Marker + infowindow + angularjs compiled ng-click
        var contentString = "<div><a ng-click='clickTest()'>Click me!</a></div>";
        var compiled = $compile(contentString)($scope);

        var infowindow = new google.maps.InfoWindow({
          content: compiled[0]
        });

        var marker = new google.maps.Marker({
          position: myLatlng,
          map: map,
          title: 'Uluru (Ayers Rock)'
        });

        google.maps.event.addListener(marker, 'click', function() {
          infowindow.open(map,marker);
        });

        $scope.map = map;
      }
      google.maps.event.addDomListener(window, 'load', initialize);
      
      $scope.centerOnMe = function() {
        if(!$scope.map) {
          return;
        }

        $scope.loading = LoaderService.show({
          content: 'Getting current location...',
          showBackdrop: false
        });

        navigator.geolocation.getCurrentPosition(function(pos) {
          $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
          $scope.loading.hide();
        }, function(error) {
          alert('Unable to get location: ' + error.message);
        });
      };
      
      $scope.clickTest = function() {
        alert('Example of infowindow with ng-click')
      };
      
    }).controller('BrunchlstCtrl', function($scope,$ionicHistory,LoaderService,$ionicHistory,$ionicPopup, $state,RestaurantService,AddloveService) {
    var limit = 3;
    var offset = 0;
    $scope.loader = true
    $scope.advertisements = [];
    function setItems (items){
          angular.forEach(items, function (task, index) {
              $scope.advertisements.push(task)
          });
      }
    function get_advertisement(){
        RestaurantService.get(offset,limit,2).success(function(response){
            LoaderService.hide();
            console.log(response);
            if(response.status == 1){
                offset  = offset + limit;
                setItems (response.data);
            } else {
                $scope.loader = false;
            }
            if(offset  >= response.count){
                $scope.loader = false;
            } else {
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
    LoaderService.show();
    get_advertisement(offset,limit);
    
    $scope.doRefresh = function(){
        LoaderService.show();
        offset = 0;
        $scope.advertisements = [];
        $scope.loader = true;
        get_advertisement(offset,limit);
        $scope.$broadcast('scroll.refreshComplete');
    }
    $scope.loadMore  = function(){
//        offset  = offset + limit;
             get_advertisement(offset,limit);
         }
    $scope.add_love = function(id,key){
        if($scope.advertisements[key]["love"] == false){
            $scope.advertisements[key]["love"] = true;
        } else {
            $scope.advertisements[key]["love"] = false;
        }
        var data_obj = {};
        if(localStorage.getItem('user_session') !=  null){
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
                
            } 
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        console.log(data_obj);
        AddloveService.get(data_obj).success(function(response){
            LoaderService.hide();
            console.log(response);
            if(response.status == 1){
                
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
}).controller('HappyhourdetailCtrl', function($scope,$stateParams,$ionicHistory,LoaderService,$ionicHistory,$ionicPopup, $state,RestaurantService,AddloveService,SubmitcommentService) {
   var ad_id = $stateParams.ad_id;
   $scope.advertisement  = {};
   $scope.comments = {};
   if(localStorage.getItem('user_session') !=  null){
        $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
        $scope.user_login = true;
    }
//            rating
            
    $scope.comments.rating = 3;
    $scope.commentmax = 5;
    
    $scope.get_comments = [];
    function setItems (items){
          angular.forEach(items, function (task, index) {
              $scope.get_comments.push(task)
          });
      }
    function get_advertisement(ad_id){
        RestaurantService.getsingle(ad_id,$scope.user_detail.id).success(function(response){
            LoaderService.hide();
            if(response.status == 1){
                $scope.advertisement = response.data;
                console.log(response.data);
                
                if(response.data.comments){
                    setItems(response.data.comments);
                }
            } else {
                $scope.loader = false;
            }
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
                $ionicPopup.hide();
                $scope.$broadcast('scroll.refreshComplete');
        });
    }
    LoaderService.show();
    get_advertisement(ad_id);
    $scope.doRefresh = function(){
        $scope.get_comments = [];
        get_advertisement(ad_id);
    }
    $scope.submitmessage = function(){
             $scope.comments.user_id = $scope.user_detail.id;
             $scope.comments.template = "advertisement";
//             $scope.comments.rating = "advertisement";
             console.log($scope.comments);
             $scope.comments.template_id = ad_id;
             LoaderService.show();
                SubmitcommentService.register($scope.comments).success(function(response){
                        LoaderService.hide();
                        if(response.status == 1){
                            $scope.comments.comment = "";
                            $scope.get_comments.push(response.data) ;
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                            $scope.success = true;
                        } else {
                            LoaderService.hide();
                                var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Error while posting your comment!'
                               });
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    
                    
                }).error(function(response){
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Please check your network connection!'
                   }).then(function(){
                   });
             
                });
         }
        $scope.add_love = function(id){
        var data_obj = {};
        if(localStorage.getItem('user_session') !=  null){
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
                
            }
            if($scope.response.love == false){
                    $scope.response.love = true;
                } else {
                    $scope.response.love = false;
                }
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function(response){
            LoaderService.hide();
            console.log(response);
            if(response.status == 1){
                
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
    
//    google map
function initialize() {
        var myLatlng = new google.maps.LatLng(43.07493,-89.381388);
        
        var mapOptions = {
          center: myLatlng,
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"),
            mapOptions);
        
        //Marker + infowindow + angularjs compiled ng-click
        var contentString = "<div><a ng-click='clickTest()'>Click me!</a></div>";
        var compiled = $compile(contentString)($scope);

        var infowindow = new google.maps.InfoWindow({
          content: compiled[0]
        });

        var marker = new google.maps.Marker({
          position: myLatlng,
          map: map,
          title: 'Uluru (Ayers Rock)'
        });

        google.maps.event.addListener(marker, 'click', function() {
          infowindow.open(map,marker);
        });

        $scope.map = map;
      }
      google.maps.event.addDomListener(window, 'load', initialize);
      
      $scope.centerOnMe = function() {
        if(!$scope.map) {
          return;
        }

        $scope.loading = LoaderService.show({
          content: 'Getting current location...',
          showBackdrop: false
        });

        navigator.geolocation.getCurrentPosition(function(pos) {
          $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
          $scope.loading.hide();
        }, function(error) {
          alert('Unable to get location: ' + error.message);
        });
      };
      
      $scope.clickTest = function() {
        alert('Example of infowindow with ng-click')
      };
    
    
    
    
    
}).controller('BrunchdetailCtrl', function($scope,$stateParams,$ionicHistory,LoaderService,$ionicHistory,$ionicPopup, $state,RestaurantService,AddloveService,SubmitcommentService) {
   var ad_id = $stateParams.ad_id;
   console.log(ad_id);
   $scope.advertisement  = {};
   $scope.comments = {};
   if(localStorage.getItem('user_session') !=  null){
        $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
        $scope.user_login = true;
    }
//            rating
            
    $scope.comments.rating = 3;
    $scope.commentmax = 5;
    
    $scope.get_comments = [];
    function setItems (items){
          angular.forEach(items, function (task, index) {
              $scope.get_comments.push(task)
          });
      }
    function get_advertisement(ad_id){
        RestaurantService.getsingle(ad_id,user_detail.id).success(function(response){
            console.log(ad_id);
            LoaderService.hide();
            console.log(response.data);
            if(response.status == 1){
                $scope.advertisement = response.data;
                console.log(response.data);
                if(response.data.love == false){
                    response.data.love = "2";
                } else {
                    response.data.love = "1";
                }
                if(response.data.comments){
                    setItems(response.data.comments);
                }
            } else {
                $scope.loader = false; 
            }
            $scope.$broadcast('scroll.refreshComplete');
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
                $ionicPopup.hide();
                $scope.$broadcast('scroll.refreshComplete');
        });
    }
    LoaderService.show();
    get_advertisement(ad_id);
    $scope.doRefresh = function(){
        $scope.get_comments = [];
        get_advertisement(ad_id);
    }
    $scope.submitmessage = function(){
             $scope.comments.user_id = $scope.user_detail.id;
             $scope.comments.template = "advertisement";
//             $scope.comments.rating = "advertisement";
             console.log($scope.comments);
             $scope.comments.template_id = ad_id;
             LoaderService.show();
                SubmitcommentService.register($scope.comments).success(function(response){
                        LoaderService.hide();
                        if(response.status == 1){
                            $scope.comments.comment = "";
                            $scope.get_comments.push(response.data) ;
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
//                            $location.path("/tab/login");
                            $scope.success = true;
                        } else {
                            LoaderService.hide();
                                var alertPopup = $ionicPopup.alert({
                                title: 'Error',
                                template: 'Error while posting your comment!'
                               });
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    
                    
                }).error(function(response){
                    LoaderService.hide();
                    var alertPopup = $ionicPopup.alert({
                    title: 'Error',
                    template: 'Please check your network connection!'
                   }).then(function(){
                   });
             
                });
         }
         $scope.add_love = function(id){
             if($scope.advertisement.love == "2"){
                 $scope.advertisement.love = "1";
                
             } else if($scope.advertisement.love == "1"){
                 $scope.advertisement.love = "2";
             }
             
        var data_obj = {};
        if(localStorage.getItem('user_session') !=  null){
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
                
            } 
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function(response){
            LoaderService.hide();
            console.log(response);
            if(response.status == 1){
                
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
//    google map
function initialize() {
        var myLatlng = new google.maps.LatLng(43.07493,-89.381388);
        
        var mapOptions = {
          center: myLatlng,
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"),
            mapOptions);
        
        //Marker + infowindow + angularjs compiled ng-click
        var contentString = "<div><a ng-click='clickTest()'>Click me!</a></div>";
        var compiled = $compile(contentString)($scope);

        var infowindow = new google.maps.InfoWindow({
          content: compiled[0]
        });

        var marker = new google.maps.Marker({
          position: myLatlng,
          map: map,
          title: 'Uluru (Ayers Rock)'
        });

        google.maps.event.addListener(marker, 'click', function() {
          infowindow.open(map,marker);
        });

        $scope.map = map;
      }
      google.maps.event.addDomListener(window, 'load', initialize);
      
      $scope.centerOnMe = function() {
        if(!$scope.map) {
          return;
        }

        $scope.loading = LoaderService.show({
          content: 'Getting current location...',
          showBackdrop: false
        });

        navigator.geolocation.getCurrentPosition(function(pos) {
          $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
          $scope.loading.hide();
        }, function(error) {
          alert('Unable to get location: ' + error.message);
        });
      };
      
      $scope.clickTest = function() {
        alert('Example of infowindow with ng-click')
      };
    
}).controller('HappyhourCtrl', function($location,$scope,$ionicHistory,LoaderService,$ionicHistory,$ionicPopup, $state,RestaurantService,AddloveService) {
//    if(user_detail == null){
//         
//    } else {
//        $location.path('tab/index');
//    }
    var limit = 3;
    var offset = 0;
    $scope.loader = true
    $scope.advertisements = [];
    function setItems (items){
          angular.forEach(items, function (task, index) {
              $scope.advertisements.push(task)
          });
      }
    function get_advertisement(){
        RestaurantService.get(offset,limit,1).success(function(response){
            console.log(response);
            LoaderService.hide();
            if(response.status == 1){
                offset  = offset + limit;
                setItems (response.data);
            } else {
                $scope.loader = false;
            }
            if(offset  >= response.count){
                $scope.loader = false;
            } else {
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
    LoaderService.show();
//    LoaderService.show();
    get_advertisement(offset,limit);
    
    $scope.doRefresh = function(){
        LoaderService.show();
        offset = 0;
        $scope.advertisements = [];
        $scope.loader = true;
        get_advertisement(offset,limit);
        $scope.$broadcast('scroll.refreshComplete');
    }
    $scope.loadMore  = function(){
//        offset  = offset + limit;
             get_advertisement(offset,limit);
         }
    $scope.add_love = function(id,key){
        if($scope.advertisements[key]["love"] == false){
            $scope.advertisements[key]["love"] = true;
        } else {
            $scope.advertisements[key]["love"] = false;
        }
        var data_obj = {};
        if(localStorage.getItem('user_session') !=  null){
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
                
            } 
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        console.log(data_obj);
        AddloveService.get(data_obj).success(function(response){
            LoaderService.hide();
            console.log(response);
            if(response.status == 1){
                
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
})
.controller('BlogCtrl', function($scope,$ionicHistory,LoaderService,$ionicHistory,FlashService,$ionicPopup, $state,BlogService) {
    
    var limit = 3;
    var offset = 0;
    $scope.blogs = [];
    function setItems (items){
        angular.forEach(items, function (task, index) {
            $scope.blogs.push(task)
        });
    }
    $scope.loader = true;
    LoaderService.show({
//        template:"Loading..."
    });
    function get_blogs(){
    BlogService.get(offset,limit).success(function(response){
        offset = offset + limit;
        LoaderService.hide();
        if(response.status == 0){
        $scope.loader = false;
        } else {
            setItems(response.data)
            if(offset  >= response.count){
                $scope.loader = false;
            }
            
            $scope.$broadcast('scroll.infiniteScrollComplete');
            
        } 
//        localStorage.setItem('cities', JSON.stringify($scope.cities));
    }).error(function(data){
                LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                   });;
             });
             
         }
         $scope.load_blogs  = function(){
             get_blogs(limit, offset);
         }
         $scope.$on('$stateChangeSuccess', function() {
                get_blogs(limit, offset);
              });
              $scope.doRefresh = function(){
                  offset = 0;
                $scope.blogs = [];
                $scope.loader = true;
                get_blogs(limit, offset);
                $scope.$broadcast('scroll.refreshComplete');
              }
         
    
    
})
.controller('LoginCtrl', function($scope,$ionicHistory,LoaderService,$ionicHistory,FlashService,$ionicPopup, $state,LoginService) {
    
    if(localStorage.getItem('success') !== null){
        $scope.success = true;
        localStorage.removeItem('success');
        
    }
    $scope.myGoBack = function() {
    $ionicHistory.goBack();
  };
    $scope.BackButton = function(){
//        $ionicHistory.getBackView();
        $ionicHistory.backView();
    }
    // login code
    $scope.data = {};
    $scope.login = function() {
        if($scope.data.username === undefined ){
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please enter your username!'
            });
            return;
        }
        if($scope.data.password === undefined ){
            var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please enter your password!'
            });
            return;
        }
        LoaderService.show();
        LoginService.loginUser($scope.data.username, $scope.data.password).success(function(response) {
            
            LoaderService.hide();
            if (response.status == 1) {
                    JSON.stringify($scope.states)
                    localStorage.setItem('user_session',JSON.stringify(response.data));
                    var alertPopup = $ionicPopup.alert({
                        title: 'Success',
                        template: 'Successfully loged in!'
                    }).then(function(){
                        $state.go('tab.dashboard');
                    });
                    
                    return response.data;
//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                    // success
                } else {
                    var alertPopup = $ionicPopup.alert({
                title: 'Login failed!',
                template: 'Please check your credentials!'
            });
                }
//            $state.go('tab.dash');
        });
//                .error(function(data) {
//            var alertPopup = $ionicPopup.alert({
//                title: 'Login failed!',
//                template: 'Please check your credentials!'
//            });
//        });
    }
    
    
    
    
    $scope.successMessage = FlashService.getMessage();
})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})


.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
})
.controller("DashCtrl",function($location,$scope,$ionicHistory,LoaderService,$ionicHistory,$ionicPopup,DashboardService, $state,AddloveService){
            $scope.user_detail = user_detail;
    $scope.loader = true
    $scope.data = [];
    function setItems (items){
          angular.forEach(items, function (task, index) {
              $scope.advertisements.push(task)
          });
      }
    function get_dashboard_data(){
        DashboardService.get(user_detail.id).success(function(response){
            console.log(response);
            LoaderService.hide();
            $scope.data = response.data;
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
    $scope.doRefresh = function(){
        $scope.data = {};
        LoaderService.show();
        get_dashboard_data();
        $scope.$broadcast('scroll.refreshComplete');
    }
    LoaderService.show();
    get_dashboard_data();
    $scope.add_love = function(id,key,main_key){
        console.log(main_key);
        if($scope.data[main_key][key]["love"] == false){
            $scope.data[main_key][key]["love"] = true;
        } else {
            $scope.data[main_key][key]["love"] = false;
        }
        var data_obj = {};
        if(localStorage.getItem('user_session') !=  null){
                $scope.user_detail = JSON.parse(localStorage.getItem('user_session'));
                $scope.user_login = true;
                
            } 
        data_obj["user_id"] = $scope.user_detail.id;
        data_obj["ad_id"] = id;
        data_obj["meta_key"] = "love_advertisement";
        AddloveService.get(data_obj).success(function(response){
            LoaderService.hide();
            if(response.status == 1){
                
            }
        }).error(function(response){
            LoaderService.hide();
                 var alertPopup = $ionicPopup.alert({
                title: 'Error',
                template: 'Please check your network connection!'
                }).then(function(){
//                       $ionicHistory.getBackView();
                });;
        });
    }
    
}).controller('LoaderCtrl', function($scope,LoaderService) {
  $scope.showLoadingProperTimes = function() {
    LoaderService.show({
      templateUrl:"templates/loading.html"
    });
  };

  $scope.hideLoadingProperTimes = function() {
    //LoaderService.hide();
  };

  $scope.showLoadingProperTimes();
})

.controller("EdituserCtrl",function($scope,LoaderService,$ionicPopup,$state,$stateParams,$http,$location,RegisterService,FlashService,UserService,CityService,StateService,FileuploadService,GetUserService){
            
    $scope.user = {};
    var user_id = user_detail.id;
    // get user
    GetUserService.get(user_id).success(function(response){
        $scope.user = response.data;
    }).error(function(response){
        var alertPopup = $ionicPopup.alert({
        title: 'Error',
        template: 'very Slow network!'
        });
    });
    $scope.FlashService = FlashService;
    $scope.successMessage = FlashService.getMessage();
    $scope.cities = {};
    if(localStorage.getItem('cities') == null){
             CityService.get().success(function(response){
        $scope.cities = response.data;
        localStorage.setItem('cities', JSON.stringify($scope.cities));
    });
    } else {
        $scope.cities = JSON.parse(localStorage.getItem('cities'));
    }
    
    $scope.states = {};
    if(localStorage.getItem('states') == null){
             StateService.get().success(function(response){
        $scope.states = response.data;
        localStorage.setItem('states', JSON.stringify($scope.states));
    });
    } else {
        $scope.states = JSON.parse(localStorage.getItem('states'));
    }
    
    $scope.success = false;
    $scope.error = false; 
            $scope.register =  function () {
                    LoaderService.show();
                    console.log($scope.user); 
                RegisterService.update($scope.user).success(function(response){
                    if(response){
                        LoaderService.hide();
                        if(response.status == 1){
//                            $scope.user = {};
//                            localStorage.setItem('success',"true");
                            var alertPopup = $ionicPopup.alert({
                                title: 'Success',
                                template: 'Successfully Updated!'
                            }).then(function(){
                                $state.go('tab.edituser');
                            });
//                            $location.path("/login"); 
                            $scope.success = true;
                        } else {
//                            $scope.error = true;
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    } else {
                        
                    }
                    
                });
        }
        $scope.uploadResult = [];
	 $scope.onFileSelect = function($files) {
//             console.log($files);
             FileuploadService.uploadImage($files).success(function(response){
                 if(response.data.status == 1){
                     $scope.user.userfile = response.data.data;
                 } else {
                     console.log("error while uploading image");
                 }
             }).error(function(data){
                 var alertPopup = $ionicPopup.alert({
                title: 'Password',
                template: 'very Slow network!'
                });
                return ;
             });
//                     .success(function(response){
//                 console.log(response);
//             });
    //$files: an array of files selected, each file has name, size, and type.
    
         };
})
.controller("RegisterCtrl",function($scope,LoaderService,$ionicPopup,$state,$stateParams,$http,$location,RegisterService,FlashService,UserService,CityService,StateService,FileuploadService){
            


    $scope.user = {};
    $scope.FlashService = FlashService;
    $scope.successMessage = FlashService.getMessage();
    $scope.cities = {};
    if(localStorage.getItem('cities') == null){
             CityService.get().success(function(response){
        $scope.cities = response.data;
        localStorage.setItem('cities', JSON.stringify($scope.cities));
    });
    } else {
        $scope.cities = JSON.parse(localStorage.getItem('cities'));
    }
    
    $scope.states = {};
    if(localStorage.getItem('states') == null){
             StateService.get().success(function(response){
        $scope.states = response.data;
        localStorage.setItem('states', JSON.stringify($scope.states));
    });
    } else {
        $scope.states = JSON.parse(localStorage.getItem('states'));
    }
    
    $scope.success = false;
    $scope.error = false; 
            $scope.register =  function () {
//                console.log($scope.user);
                
                    LoaderService.show();
                RegisterService.register($scope.user).success(function(response){
                    if(response){
                        LoaderService.hide();
                        if(response.status == 1){
//                            $scope.user = {};
                            localStorage.setItem('success',"true");
                            $location.path("/login");
                            $scope.success = true;
                        } else {
//                            $scope.error = true;
                        }
//                        $location.path("/tab/register");
//                        console.log(FlashService.getMessage());
                    } else {
                        
                    }
                    
                });
        }
        $scope.uploadResult = [];
	 $scope.onFileSelect = function($files) {
//             console.log($files);
             FileuploadService.uploadImage($files).success(function(response){
                 if(response.data.status == 1){
                     $scope.user.userfile = response.data.data;
                 } else {
                     console.log("error while uploading image");
                 }
             }).error(function(data){
                 var alertPopup = $ionicPopup.alert({
                title: 'Password',
                template: 'very Slow network!'
                });
                return ;
             });
//                     .success(function(response){
//                 console.log(response);
//             });
    //$files: an array of files selected, each file has name, size, and type.
    
         };
})