// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
  
})

.config(function($stateProvider, $urlRouterProvider) {
//    $scope.GoBack = function() {
//    $ionicHistory.goBack();
//  },

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider.state('login', {
      url: '/login',
      templateUrl: 'templates/login.html',
      controller: 'LoginCtrl'
  }).state('registration', {
    url: '/registration',
    
        templateUrl: 'templates/registration.html',
        controller: 'RegisterCtrl'
  })

  // setup an abstract state for the tabs directive
    .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
  })

  // Each tab has its own nav history stack:

  .state('tab.index', {
    url: '/index',
    views: {
      'tab-dash': {
        templateUrl: 'templates/index.html',
        controller: 'DashCtrl'
      }
    }
  })
  .state('index', {
    url: '/index',
        templateUrl: 'templates/index.html',
        controller: 'DashCtrl'
    
  })
  .state('tab.login', {
    url: '/login',
    views: {
      'tab-dash': {
        templateUrl: 'templates/login.html',
        controller: 'LoginCtrl'
      }
    }
  }).state('tab.edituser', {
    url: '/edituser',
    views: {
      'tab-dash': {
        templateUrl: 'templates/edituser.html',
        controller: 'EdituserCtrl'
      }
    }
  }).state('tab.share', {
    url: '/share',
    views: {
      'tab-dash': {
        templateUrl: 'templates/share-listing.html',
        controller: 'DashCtrl'
      }
    }
  })
    
  .state('tab.listing', {
    url: '/listing',
    views: {
      'tab-dash': {
        templateUrl: 'templates/listing.html',
        controller: 'DashCtrl'
      }
    },onEnter: function($state, Auth){
        if(!Auth.isLoggedIn()){
           $state.go('index');
        }
    }
  })
  .state('tab.dashboard', {
    url: '/dashboard',
    views: {
      'tab-dash': {
        templateUrl: 'templates/dashboard.html',
        controller: 'DashCtrl'
      }
    },onEnter: function($state, Auth){
        if(!Auth.isLoggedIn()){
           $state.go('index');
        }
    }
  }).state('tab.favourites', {
    url: '/favourites',
    views: {
      'tab-favourites': {
        templateUrl: 'templates/favourites.html',
        controller: 'FavouritesCtrl'
      }
    },onEnter: function($state, Auth){
        if(!Auth.isLoggedIn()){
           $state.go('index');
        }
    }
  })
  .state('tab.favourites-detail', {
    url: '/favourites-detail/:cityID',
    views: {
      'tab-favourites': {
        templateUrl: 'templates/favorites-detail.html',
        controller: 'FavouritesdetailCtrl'
      }
    }
  }).state('tab.map', {
    url: '/map',
    views: {
      'tab-map': {
        templateUrl: 'templates/map.html',
        controller: 'DashCtrl'
      }
    },onEnter: function($state, Auth){
        if(!Auth.isLoggedIn()){
           $state.go('index');
        }
    }
  }).state('tab.logout', {
    url: '/logout',
    views: {
      'tab-map': {
//        templateUrl: 'templates/log.html',
        controller: 'LogoutCtrl'
      }
    },onEnter: function($state, Auth){
        if(!Auth.isLoggedIn()){
           $state.go('index');
        }
    }
  })
  .state('tab.location', {
    url: '/location',
    views: {
      'tab-map': {
        templateUrl: 'templates/location.html',
        controller: 'DashCtrl'
      }
    }
  }) 
  .state('tab.googlemap', {
    url: '/googlemap',
    views: {
      'tab-map': {
        templateUrl: 'templates/googlemap.html',
        controller: 'GooglemapCtrl'
      }
    }
  })
 .state('tab.location-detail', {
    url: '/location-detail',
    views: {
      'tab-map': {
        templateUrl: 'templates/location-detail.html',
        controller: 'DashCtrl'
      }
    }
  })
  .state('tab.blog-detail', {
    url: '/blog-detail/:blogId',
    views: {
      'tab-blog': {
        templateUrl: 'templates/blog-detail.html',
        controller: 'BlogdetailCtrl'
      }
    }
  })
  .state('tab.happy-hour-listing', {
    url: '/happy-hour-listing',
    views: {
      'tab-listing': {
        templateUrl: 'templates/happy-hour-listing.html',
        controller: 'HappyhourCtrl'
      }
    }
  })
  .state('tab.happy-hour-listing-detail', {
    url: '/happy-hour-listing-detail/:ad_id',
    views: {
      'tab-listing': {
        templateUrl: 'templates/happy-hour-listing-detail.html',
        controller: 'HappyhourdetailCtrl'
      }
    }
  }).state('tab.fav-happy-hour-listing-detail', {
    url: '/fav-happy-hour-listing-detail/:ad_id',
    views: {
      'tab-favourites': {
        templateUrl: 'templates/happy-hour-listing-detail.html',
        controller: 'HappyhourdetailCtrl'
      }
    }
  })
  .state('tab.brunch-listing', {
    url: '/brunch-listing',
    views: {
      'tab-favourites': {
        templateUrl: 'templates/brunch-listing.html',
        controller: 'BrunchlstCtrl'
      }
    },onEnter: function($state, Auth){
        if(!Auth.isLoggedIn()){
           $state.go('index');
        }
    }
  })
  .state('tab.brunch-listing-detail', {
    url: '/brunch-listing-detail/:ad_id',
    views: {
      'tab-dash': {
        templateUrl: 'templates/brunch-listing-detail.html',
        controller: 'BrunchdetailCtrl'
      }
    }
  })
  
  
   .state('tab.favorites-detail', {
    url: '/favorites-detail/:restaurantsId',
    views: {
      'tab-dash': {
        templateUrl: 'templates/favorites-detail.html',
        controller: 'FavouritedetailCtrl'
      }
    }
  })
  .state('tab.chat-detail', {
      url: '/chats/:chatId',
      views: {
        'tab-chats': {
          templateUrl: 'templates/chat-detail.html',
          controller: 'ChatDetailCtrl'
        }
      }
    })
	.state('tab.blog', {
      url: '/blog',
      views: {
        'tab-blog': {
          templateUrl: 'templates/blog.html',
          controller: "BlogCtrl"
        }
      },onEnter: function($state, Auth){
        if(!Auth.isLoggedIn()){
           $state.go('index');
        }
    }
    })

  .state('tab.account', {
    url: '/account',
    views: {
      'tab-account': {
        templateUrl: 'templates/tab-account.html',
        controller: 'AccountCtrl'
      }
    }
  }).state('tab.loader', {
    url: '/loader',
    views: {
      'tab-dash': {
        templateUrl: 'templates/loading.html',
        controller: 'LoginCtrl'
      }
    }
  })

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/tab/index');

});
