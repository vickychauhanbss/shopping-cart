angularmodule.directive('ngCompare', function () {
    return {
        require: 'ngModel',
        link: function (scope, currentEl, attrs, ctrl) {
            var comparefield = document.getElementsByName(attrs.ngCompare)[0]; //getting first element
            compareEl = angular.element(comparefield);

            //current field key up
            currentEl.on('keyup', function () {
//                alert(compareEl.val());
                if (compareEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });

            //Element to compare field key up
            compareEl.on('keyup', function () {
                if (currentEl.val() != "") {
                    var isMatch = currentEl.val() === compareEl.val();
                    ctrl.$setValidity('compare', isMatch);
                    scope.$digest();
                }
            });
        }
    }
}).directive("ngUnique", ['$http',"api", function($http,api) {
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function (scope, element, attrs, ngModel) {
      element.bind('keyup', function (e) {
//console.log(attrs.userId);
//console.log("dfdf");
          if(!ngModel || !element.val())ngModel.$setValidity('unique', true);
        if (!ngModel || !element.val()) return;
        var keyProperty = scope.$eval(attrs.ngUnique);
        var currentValue = element.val();
        currentValue = currentValue.trim();
      
       if(currentValue.trim()){
           if(attrs.userId != undefined){
               
               var user_id =attrs.userId;
               var url = api+'check_email?email='+currentValue+'&user_id='+user_id;
           } else {
              var url =  api+'check_email?email='+currentValue;
           }
          
       $http({
        method: 'get',
        url: url,
        data: {email:currentValue},
        params: 'limit=10, sort_by=created:desc',
        headers: {'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
     }).success(function(data){
        // With the data succesfully returned, call our callback
        if(data.status == "0"){
            ngModel.$setValidity('unique', false);
        } else {
            ngModel.$setValidity('unique', true);
        }
         return data;
//        callbackFunc(data);
    }).error(function(){
//        alert("error");
    });
       }else {
          ngModel.$setValidity('unique', false); 
       }
   
      });
    }
  }
}]).directive("scroll", function ($window) {
    return function(scope, element, attrs) {
        angular.element($window).bind("scroll", function() {
            console.log(this.pageYOffset);
             if (this.pageYOffset >= 100) {
                 scope.boolChangeClass = true;
                 console.log('Scrolled below header.');
             } else {
                 scope.boolChangeClass = false;
                 console.log('Header is in view.');
             }
            scope.$apply();
        });
    };
});;