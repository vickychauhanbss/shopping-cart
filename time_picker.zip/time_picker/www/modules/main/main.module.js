angular.module('starter', [
  'ionic',
  'starter.controllers',
  'ionic-timepicker'
])